import os
import logging
import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from db import Base
from models import User, Transaction, CreditUsage, SERVICE_COSTS

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Получаем URL базы данных из переменной окружения или используем SQLite по умолчанию
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///faceform_bot.db")

# Создаем движок SQLAlchemy
engine = create_engine(DATABASE_URL)

# Создаем фабрику сессий
session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)

def init_db():
    """Инициализировать базу данных (создать таблицы)"""
    try:
        # Создаем все таблицы, которые определены в models.py
        Base.metadata.create_all(engine)
        logger.info("База данных успешно инициализирована")
    except Exception as e:
        logger.error(f"Ошибка при инициализации базы данных: {e}")
        raise

def get_or_create_user(telegram_id, username=None, first_name=None, last_name=None):
    """
    Получить существующего пользователя или создать нового
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        username (str, optional): Имя пользователя в Telegram
        first_name (str, optional): Имя пользователя
        last_name (str, optional): Фамилия пользователя
        
    Returns:
        User: Объект пользователя
    """
    session = Session()
    try:
        # Ищем пользователя по ID в Telegram
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        
        if user is None:
            # Если пользователь не найден, создаем нового
            user = User(
                telegram_id=telegram_id,
                username=username,
                first_name=first_name,
                last_name=last_name,
                credits=0  # Новый пользователь получает 0 кредитов
            )
            session.add(user)
            session.commit()
            logger.info(f"Создан новый пользователь с ID {telegram_id}")
        
        return user
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при работе с пользователем {telegram_id}: {e}")
        raise
    finally:
        session.close()

def get_user_credits(user_id_or_telegram_id):
    """
    Получить количество кредитов у пользователя.
    Функция поддерживает как ID из базы данных, так и Telegram ID.
    
    Args:
        user_id_or_telegram_id (int): ID пользователя в базе или Telegram ID
        
    Returns:
        int: Количество кредитов у пользователя
    """
    session = Session()
    try:
        # Сначала пытаемся найти по id
        user = session.query(User).filter(
            (User.id == user_id_or_telegram_id) | 
            (User.telegram_id == user_id_or_telegram_id)
        ).first()
        
        if user:
            logger.debug(f"Найден пользователь с ID={user.id}, telegram_id={user.telegram_id}, кредиты={user.credits}")
            return user.credits
        
        logger.warning(f"Пользователь с ID/telegram_id {user_id_or_telegram_id} не найден")
        return 0
    except Exception as e:
        logger.error(f"Ошибка при получении кредитов пользователя {user_id_or_telegram_id}: {e}")
        return 0
    finally:
        session.close()

def update_user_credits(telegram_id, credits_change):
    """
    Изменить количество кредитов у пользователя
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        credits_change (int): Изменение количества кредитов (положительное - добавление, отрицательное - списание)
        
    Returns:
        int: Новое количество кредитов у пользователя
    """
    session = Session()
    try:
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        if user:
            # Обновляем количество кредитов
            user.credits += credits_change
            # Проверяем, что количество кредитов не стало отрицательным
            if user.credits < 0:
                user.credits = 0
            session.commit()
            return user.credits
        return 0
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при обновлении кредитов пользователя {telegram_id}: {e}")
        return 0
    finally:
        session.close()

def use_credit(telegram_id, feature, credits_amount=None):
    """
    Использовать кредиты для определенной функции
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        feature (str): Название функции, для которой используются кредиты
        credits_amount (int, optional): Количество кредитов для списания. Если не указано, 
                                       берется из карты соответствия функций.
        
    Returns:
        bool: True, если кредиты успешно использованы, False в противном случае
    """
    from models import SERVICE_COSTS
    
    # Получаем стоимость функции в кредитах из модели SERVICE_COSTS
    # Если передано явное количество кредитов, используем его, иначе берем из словаря
    base_credit_cost = SERVICE_COSTS.get(feature, 1)
    credit_cost = credits_amount if credits_amount is not None else base_credit_cost
    
    session = Session()
    try:
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        if not user:
            logger.error(f"Пользователь {telegram_id} не найден")
            return False
        
        # Специальная обработка для анализа формы лица (первые 5 раз бесплатно)
        if feature in ['face_shape', 'face_shape_analysis'] and credit_cost > 0:
            # Получаем количество предыдущих использований
            face_shape_usages = session.query(CreditUsage).filter_by(
                user_id=user.id, 
                feature=feature
            ).count()
            
            # Если меньше 5 использований, делаем бесплатно
            if face_shape_usages < 5:
                credit_cost = 0
                logger.info(f"Бесплатное использование формы лица для пользователя {telegram_id}. Использовано: {face_shape_usages+1}/5")
        
        # Проверяем, есть ли у пользователя достаточно кредитов (только если функция платная)
        if credit_cost > 0 and user.credits < credit_cost:
            logger.warning(f"У пользователя {telegram_id} недостаточно кредитов (есть {user.credits}, нужно {credit_cost})")
            return False
        
        # Списываем кредиты (только если не бесплатно)
        if credit_cost > 0:
            user.credits -= credit_cost
        
        # Записываем использование кредитов, даже если бесплатно (для статистики)
        credit_usage = CreditUsage(
            user_id=user.id,
            amount=credit_cost,
            feature=feature,
            description=f"Использование функции {feature}"
        )
        session.add(credit_usage)
        session.commit()
        
        if credit_cost > 0:
            logger.info(f"Пользователь {telegram_id} использовал {credit_cost} кредита(ов) для функции {feature}. Осталось: {user.credits}")
        else:
            logger.info(f"Пользователь {telegram_id} бесплатно использовал функцию {feature}")
        
        return True
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при использовании кредита пользователем {telegram_id}: {e}")
        return False
    finally:
        session.close()

def create_transaction(telegram_id, amount, credits, payment_id=None):
    """
    Создать новую транзакцию покупки кредитов
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        amount (float): Сумма в долларах
        credits (int): Количество приобретаемых кредитов
        payment_id (str, optional): ID платежа в платежной системе
        
    Returns:
        Transaction: Объект транзакции
    """
    session = Session()
    try:
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        if not user:
            logger.error(f"Пользователь {telegram_id} не найден")
            return None
            
        # Создаем транзакцию
        transaction = Transaction(
            user_id=user.id,
            amount=amount,
            credits=credits,
            status='pending',
            payment_id=payment_id
        )
        session.add(transaction)
        session.commit()
        
        logger.info(f"Создана новая транзакция для пользователя {telegram_id}: {amount}$ за {credits} кредитов")
        return transaction
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при создании транзакции для пользователя {telegram_id}: {e}")
        return None
    finally:
        session.close()
        
def deduct_user_credits(user_id_or_telegram_id, credits_amount, feature=None):
    """
    Списать кредиты с баланса пользователя (веб-приложение).
    Функция поддерживает как ID из базы данных, так и Telegram ID.
    
    Args:
        user_id_or_telegram_id (int): ID пользователя в базе или Telegram ID
        credits_amount (int): Количество кредитов для списания
        feature (str, optional): Название функции, для которой списываются кредиты
        
    Returns:
        bool: True, если операция прошла успешно, False в случае ошибки
    """
    from models import SERVICE_COSTS
    
    session = Session()
    try:
        # Получаем пользователя
        user = session.query(User).filter(
            (User.id == user_id_or_telegram_id) | 
            (User.telegram_id == user_id_or_telegram_id)
        ).first()
        
        if not user:
            logger.error(f"Пользователь с ID/telegram_id {user_id_or_telegram_id} не найден при списании кредитов")
            return False
            
        # Получаем или создаем запись о кредитах
        credit = user.get_or_create_credit()
        actual_credits_amount = credits_amount
        
        # Специальная обработка для анализа формы лица (первые 5 раз бесплатно)
        if feature in ['face_shape', 'face_shape_analysis'] and credits_amount > 0:
            # Получаем количество предыдущих использований
            face_shape_usages = session.query(CreditUsage).filter_by(
                user_id=user.id, 
                feature=feature
            ).count()
            
            # Если меньше 5 использований, делаем бесплатно
            if face_shape_usages < 5:
                actual_credits_amount = 0
                logger.info(f"Бесплатное использование формы лица для пользователя {user.id}. Использовано: {face_shape_usages+1}/5")
                
        # Проверяем наличие достаточного количества кредитов (если требуется списание)
        if actual_credits_amount > 0:
            if user.get_credits_balance() < actual_credits_amount:
                logger.warning(f"У пользователя {user.id} недостаточно кредитов: {user.get_credits_balance()}/{actual_credits_amount}")
                return False
                
            # Списываем кредиты
            if not credit.deduct_credits(actual_credits_amount):
                logger.warning(f"Ошибка при списании кредитов у пользователя {user.id}")
                return False
        
        # Создаем запись об использовании кредитов
        description = f"Использование функции {feature}" if feature else f"Списание {actual_credits_amount} кредитов через веб-приложение"
        usage = CreditUsage(
            user_id=user.id,
            amount=actual_credits_amount,
            feature=feature,
            description=description
        )
        session.add(usage)
        
        session.commit()
        
        if actual_credits_amount > 0:
            logger.info(f"У пользователя {user.id} списано {actual_credits_amount} кредитов. Осталось: {credit.balance}")
        else:
            logger.info(f"Пользователь {user.id} бесплатно использовал функцию {feature}")
            
        return True
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при списании кредитов у пользователя {user_id_or_telegram_id}: {e}")
        return False
    finally:
        session.close()
        
def get_credit_price_for_feature(feature_name):
    """
    Получить стоимость функции в кредитах
    
    Args:
        feature_name (str): Название функции
        
    Returns:
        int: Стоимость функции в кредитах
    """
    return SERVICE_COSTS.get(feature_name, 1)

def complete_transaction(transaction_id, status='completed'):
    """
    Завершить транзакцию и начислить кредиты пользователю
    
    Args:
        transaction_id (str): ID транзакции (например, session_id из Stripe)
        status (str): Статус транзакции ('completed', 'canceled', 'failed')
        
    Returns:
        bool: True, если транзакция успешно завершена, False в противном случае
    """
    session = Session()
    try:
        # Ищем по payment_id, а не по id
        transaction = session.query(Transaction).filter_by(payment_id=transaction_id).first()
        if not transaction:
            logger.error(f"Транзакция с payment_id={transaction_id} не найдена")
            return False
            
        # Проверяем, что транзакция еще не завершена
        if transaction.status == status and status == 'completed':
            logger.warning(f"Транзакция {transaction_id} уже имеет статус {status}")
            return True
            
        # Получаем пользователя
        user = session.query(User).filter_by(id=transaction.user_id).first()
        if not user:
            logger.error(f"Пользователь для транзакции {transaction_id} не найден")
            return False
            
        # Обновляем статус транзакции
        transaction.status = status
        transaction.completed_at = datetime.datetime.utcnow()
        transaction.updated_at = datetime.datetime.utcnow()
        
        # Начисляем кредиты пользователю только если статус completed
        if status == 'completed':
            user.credits += transaction.credits
            logger.info(f"Транзакция {transaction_id} успешно завершена. Пользователь {user.telegram_id} получил {transaction.credits} кредитов")
        else:
            logger.info(f"Транзакция {transaction_id} отмечена как {status}. Пользователь {user.telegram_id} не получил кредитов.")
        
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при завершении транзакции {transaction_id}: {e}")
        return False
    finally:
        session.close()

# Инициализируем базу данных при импорте модуля
init_db()