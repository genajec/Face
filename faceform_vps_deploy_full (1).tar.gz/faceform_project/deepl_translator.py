import os
import requests
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DeepLTranslator:
    def __init__(self):
        self.api_key = os.environ.get('DEEPL_API_KEY', '')
        self.api_url = "https://api-free.deepl.com/v2/translate"
        
        # Если ключ не установлен в переменных окружения, предупреждаем
        if not self.api_key:
            logger.warning("DEEPL_API_KEY не задан. Перевод будет работать в режиме прямого отображения.")
    
    def translate(self, text, source_lang="RU", target_lang="EN-US"):
        """
        Переводит текст с одного языка на другой
        
        Args:
            text (str): Текст для перевода
            source_lang (str): Исходный язык (например, "RU")
            target_lang (str): Целевой язык (например, "EN-US")
            
        Returns:
            str: Переведенный текст или исходный текст в случае ошибки
        """
        # Если нет ключа API или текст пустой, возвращаем исходный текст
        if not self.api_key or not text:
            return text
            
        try:
            payload = {
                "auth_key": self.api_key,
                "text": text,
                "source_lang": source_lang,
                "target_lang": target_lang
            }
            
            logger.info(f"Отправка запроса на перевод текста: '{text}'")
            response = requests.post(self.api_url, data=payload)
            
            if response.status_code == 200:
                data = response.json()
                translated_text = data['translations'][0]['text']
                logger.info(f"Текст успешно переведен: '{text}' -> '{translated_text}'")
                return translated_text
            else:
                logger.error(f"Ошибка при переводе: {response.status_code} - {response.text}")
                return text
                
        except Exception as e:
            logger.error(f"Исключение при переводе с DeepL: {e}")
            return text  # В случае ошибки возвращаем исходный текст
            
# Создаем синглтон для использования в других модулях
translator = DeepLTranslator()