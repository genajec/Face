import os
import logging
import requests
import random
import time
from datetime import datetime, timedelta

# Глобальный экземпляр менеджера ключей
_key_manager_instance = None

def get_key_manager(force_new=False):
    """
    Возвращает глобальный экземпляр менеджера ключей.
    Если экземпляр еще не создан или указан параметр force_new=True, создает новый.
    
    Args:
        force_new (bool): Если True, принудительно создает новый экземпляр
        
    Returns:
        LightXKeyManager: Экземпляр менеджера ключей
    """
    global _key_manager_instance
    if _key_manager_instance is None or force_new:
        _key_manager_instance = LightXKeyManager()
    return _key_manager_instance

# Сбрасываем экземпляр при перезагрузке модуля,
# чтобы использовались новые ключи
_key_manager_instance = None

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LightXKeyManager:
    """
    Менеджер API ключей LightX с поддержкой ротации ключей при ошибках.
    Позволяет автоматически переключаться между ключами при исчерпании лимитов.
    """
    
    def __init__(self, initial_key=None):
        """
        Инициализация менеджера ключей.
        
        Args:
            initial_key (str, optional): Начальный ключ API. Если None, берется из переменных окружения.
        """
        # Получаем API ключи из переменной окружения (приоритет)
        api_keys_env = os.environ.get("LIGHTX_API_KEYS", "")
        if api_keys_env:
            self.api_keys = [k.strip() for k in api_keys_env.split(",") if k.strip()]
        else:
            # Резервные ключи (если не указаны в переменной окружения)
            self.api_keys = [
                "af1fde5432114291a383375683bcc71c_14d92606d73c4a8b963e904660ccbf0b_andoraitools",
                "d4bd48c9745b430bab23cdc402cc9075_a98c0b1169d44acf8c27baa66988b2b4_andoraitools",
                "4d2c3274369547c9b255808021675b4c_77b787acfd27404d894c3989d0ae9632_andoraitools",
                "a271d490b6b74106b05f458bf191c512_956b50c83ea941c9a1adbb4b0b2d4680_andoraitools",
                "eeee6d2bf8504b80b16f7dacd3743266_3c1a8e677c5b4185a3644584a1140d8c_andoraitools"
            ]
        
        # Сохраняем текущий ключ и историю использования
        self.current_key = initial_key or os.environ.get("LIGHTX_API_KEY")
        if not self.current_key or self.current_key not in self.api_keys:
            # Если текущий ключ не задан или не из списка, используем первый из списка
            self.current_key = self.api_keys[0]
        
        # Мапа для отслеживания статуса ключей (ключ -> {последняя ошибка, счетчик ошибок, время блокировки})
        self.key_status = {}
        for key in self.api_keys:
            self.key_status[key] = {
                "error_count": 0,  # счетчик последовательных ошибок
                "last_error": None,  # последний код ошибки
                "blocked_until": None,  # время блокировки ключа
                "success_count": 0,  # счетчик успешных вызовов
                "total_requests": 0  # общее количество запросов
            }
        
        # Добавляем более детальный лог с первыми символами каждого ключа
        keys_log = ', '.join([f"{k[:8]}..." for k in self.api_keys])
        logger.info(f"LightX Key Manager инициализирован с {len(self.api_keys)} ключами: {keys_log}")
        
    def rotate_key(self):
        """
        Ротация ключа API - переключение на следующий доступный ключ
        
        Returns:
            str: Новый ключ API
        """
        # Текущий индекс ключа
        current_key = self.current_key or ""
        try:
            current_index = self.api_keys.index(current_key) if current_key in self.api_keys else 0
        except ValueError:
            current_index = 0
            
        # Пробуем ключи по порядку, начиная со следующего
        for i in range(1, len(self.api_keys) + 1):
            index = (current_index + i) % len(self.api_keys)
            new_key = self.api_keys[index]
            status = self.key_status.get(new_key, {})
            
            # Проверяем, не заблокирован ли ключ
            if status.get("blocked_until") and status["blocked_until"] > datetime.now():
                continue  # ключ заблокирован, пропускаем
            
            # Нашли рабочий ключ
            self.current_key = new_key
            # Безопасное отображение ключа для логов
            key_display = new_key[:8] + "..." if new_key and len(new_key) > 8 else str(new_key)
            logger.info(f"Ротация ключа API. Новый ключ: {key_display}")
            return new_key
            
        # Если все ключи заблокированы, используем текущий
        logger.warning("Все ключи API заблокированы, используем текущий")
        return self.current_key
        
    def get_current_key(self):
        """
        Возвращает текущий активный API ключ.
        
        Returns:
            str: Текущий API ключ
        """
        return self.current_key
    
    def mark_request_success(self, key=None):
        """
        Отмечает успешный запрос для указанного ключа.
        
        Args:
            key (str, optional): API ключ. Если None, используется текущий.
        """
        key = key or self.current_key
        if key in self.key_status:
            self.key_status[key]["error_count"] = 0  # сбрасываем счетчик ошибок
            self.key_status[key]["success_count"] += 1
            self.key_status[key]["total_requests"] += 1
    
    def mark_request_error(self, error_code, key=None):
        """
        Отмечает ошибку запроса для указанного ключа.
        
        Args:
            error_code (int): Код ошибки HTTP
            key (str, optional): API ключ. Если None, используется текущий.
            
        Returns:
            bool: True если ключ нужно сменить, False если можно продолжать использовать
        """
        key = key or self.current_key
        if key not in self.key_status:
            return True  # неизвестный ключ, лучше заменить
        
        status = self.key_status[key]
        status["last_error"] = error_code
        status["error_count"] += 1
        status["total_requests"] += 1
        
        # Определяем, нужно ли блокировать ключ и на какое время
        if error_code == 403:  # Forbidden - ключ, скорее всего, истек или исчерпал лимит
            # Блокируем надолго (8 часов)
            status["blocked_until"] = datetime.now() + timedelta(hours=8)
            # Безопасное отображение ключа
            try:
                key_str = str(key)
                key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
            except:
                key_display = "[недоступен]"
            logger.warning(f"Ключ {key_display} заблокирован на 8 часов из-за ошибки 403 Forbidden")
            return True
        elif error_code == 429:  # Too Many Requests - превышен лимит запросов
            # Блокируем на 15 минут
            status["blocked_until"] = datetime.now() + timedelta(minutes=15)
            # Безопасное отображение ключа
            try:
                key_str = str(key)
                key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
            except:
                key_display = "[недоступен]"
            logger.warning(f"Ключ {key_display} заблокирован на 15 минут из-за ошибки 429 Too Many Requests")
            return True
        elif error_code >= 500:  # Серверные ошибки
            # Блокируем на короткое время (2 минуты)
            if status["error_count"] >= 3:  # если это третья подряд ошибка для этого ключа
                status["blocked_until"] = datetime.now() + timedelta(minutes=2)
                # Безопасное отображение ключа
                try:
                    key_str = str(key)
                    key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
                except:
                    key_display = "[недоступен]"
                logger.warning(f"Ключ {key_display} заблокирован на 2 минуты из-за повторяющихся серверных ошибок")
                return True
        
        # Для остальных ошибок, если их много подряд, тоже меняем ключ
        if status["error_count"] >= 5:
            status["blocked_until"] = datetime.now() + timedelta(minutes=5)
            # Безопасное отображение ключа
            try:
                key_str = str(key)
                key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
            except:
                key_display = "[недоступен]"
            logger.warning(f"Ключ {key_display} заблокирован на 5 минут из-за {status['error_count']} последовательных ошибок")
            return True
        
        return False  # можно продолжать использовать ключ
    
    def is_key_blocked(self, key=None):
        """
        Проверяет, заблокирован ли ключ.
        
        Args:
            key (str, optional): API ключ. Если None, используется текущий.
            
        Returns:
            bool: True если ключ заблокирован, False если можно использовать
        """
        key = key or self.current_key
        if key not in self.key_status:
            return False
        
        blocked_until = self.key_status[key]["blocked_until"]
        if blocked_until and datetime.now() < blocked_until:
            return True
        
        # Если время блокировки прошло, сбрасываем его
        if blocked_until:
            self.key_status[key]["blocked_until"] = None
        
        return False
    
    def switch_to_next_key(self):
        """
        Переключается на следующий доступный ключ.
        
        Returns:
            str: Новый API ключ или None если все ключи заблокированы
        """
        # Перемешиваем ключи для равномерности использования
        available_keys = [k for k in self.api_keys if not self.is_key_blocked(k)]
        
        if not available_keys:
            # Если все ключи заблокированы, выбираем тот, который скоро разблокируется
            soon_available = []
            for k in self.api_keys:
                blocked_until = self.key_status.get(k, {}).get("blocked_until")
                if blocked_until:
                    soon_available.append((k, blocked_until))
            
            # Сортируем по времени разблокировки
            if soon_available:
                soon_available.sort(key=lambda x: x[1])
                next_key = soon_available[0][0]
                wait_time = (soon_available[0][1] - datetime.now()).total_seconds()
                logger.warning(f"Все ключи заблокированы. Выбран ключ, который разблокируется через {int(wait_time)} секунд")
                # Пытаемся использовать ключ с наименьшим временем ожидания
                self.current_key = next_key
                return next_key
            
            logger.error("Все API ключи заблокированы и нет информации о времени разблокировки!")
            return None
        
        # Выбираем случайный ключ из доступных, исключая текущий
        available_keys = [k for k in available_keys if k != self.current_key]
        if not available_keys:
            # Если доступен только текущий ключ, продолжаем его использовать
            return self.current_key
        
        # Выбираем случайный ключ
        next_key = random.choice(available_keys)
        # Безопасное отображение ключа
        try:
            key_str = str(next_key)
            key_display = key_str[:8] + "..." if next_key and len(key_str) > 8 else key_str
        except:
            key_display = "[недоступен]"
        logger.info(f"Переключение на новый API ключ: {key_display}")
        self.current_key = next_key
        return next_key
    
    def handle_response(self, response, key=None):
        """
        Обрабатывает ответ API и решает, нужна ли смена ключа.
        
        Args:
            response (requests.Response): Ответ API
            key (str, optional): API ключ. Если None, используется текущий.
            
        Returns:
            tuple: (нужна ли смена ключа, новый ключ)
        """
        key = key or self.current_key
        
        # Проверяем ответ на содержание ошибки API_CREDITS_CONSUMED
        api_credits_consumed = False
        try:
            # Проверяем текст ответа на наличие строки API_CREDITS_CONSUMED
            if "API_CREDITS_CONSUMED" in response.text:
                api_credits_consumed = True
                safe_key = str(key) if key else ""
                key_display = safe_key[:8] + "..." if safe_key and len(safe_key) > 8 else safe_key
                logger.warning(f"Обнаружено исчерпание кредитов API в ответе для ключа {key_display}")
            
            # Дополнительно проверяем JSON на наличие соответствующего кода ошибки
            if response.status_code == 200:
                json_data = response.json()
                if isinstance(json_data, dict):
                    status_code = json_data.get("statusCode")
                    message = str(json_data.get("message", ""))
                    
                    if status_code == 5040 or "API_CREDITS_CONSUMED" in message:
                        api_credits_consumed = True
                        logger.warning(f"Обнаружено исчерпание кредитов API в JSON ответе для ключа {key[:8]}...")
        except Exception as e:
            logger.error(f"Ошибка при проверке JSON ответа: {e}")
        
        # Если обнаружено исчерпание кредитов API, блокируем ключ на длительное время
        if api_credits_consumed:
            # Используем код 403 для длительной блокировки
            self.mark_request_error(403, key)
            # Пытаемся переключиться на следующий ключ
            new_key = self.switch_to_next_key()
            if new_key is None:
                # Если не удалось получить новый ключ, используем текущий
                return False, key
            return True, new_key
        
        # Стандартная проверка на основе кода ответа HTTP
        if response.status_code == 200:
            # Запрос успешен (и нет ошибки исчерпания кредитов в JSON)
            self.mark_request_success(key)
            return False, key
        else:
            # Произошла ошибка HTTP
            needs_switch = self.mark_request_error(response.status_code, key)
            if needs_switch:
                # Пытаемся переключиться на следующий ключ
                new_key = self.switch_to_next_key()
                if new_key is None:
                    # Если не удалось получить новый ключ, используем текущий
                    return False, key
                return True, new_key
            return False, key
    
    def test_current_key(self):
        """
        Проверяет работоспособность текущего ключа через простой API запрос.
        
        Returns:
            bool: True если ключ работает, False если нет
        """
        # Тестовый запрос к API (простой эндпоинт, не потребляющий много ресурсов)
        try:
            if not self.current_key:
                logger.error("Текущий ключ не установлен")
                return False
                
            url = "https://api.lightxeditor.com/external/api/v1/order-status"
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.current_key
            }
            data = {"orderId": "test-order-id"}  # Несуществующий ID для проверки аутентификации
            
            response = requests.post(url, headers=headers, json=data, timeout=5)
            
            # Коротка версия ключа для логов
            try:
                key_str = str(self.current_key)
                key_display = key_str[:8] + "..." if self.current_key and len(key_str) > 8 else key_str
            except:
                key_display = "[недоступен]"
            
            # Если код 401 или 404, это нормально для неправильного orderId,
            # главное, что нет 403 (Forbidden) из-за проблем с ключом
            if response.status_code not in [403, 429, 500, 502, 503, 504]:
                logger.info(f"Тест ключа API успешен: {key_display}")
                return True
            else:
                logger.warning(f"Тест ключа API не пройден: {response.status_code} - {response.text}")
                # Отмечаем ошибку и переключаемся на другой ключ
                self.mark_request_error(response.status_code)
                self.switch_to_next_key()
                return False
                
        except Exception as e:
            logger.error(f"Ошибка при тестировании ключа API: {e}")
            return False
    
    def get_next_unlock_time(self):
        """
        Возвращает время в секундах до разблокировки ближайшего ключа.
        
        Returns:
            int: Количество секунд до разблокировки или 0, если есть доступные ключи
        """
        # Проверяем, есть ли доступные ключи
        available_keys = [k for k in self.api_keys if not self.is_key_blocked(k)]
        if available_keys:
            return 0  # есть доступные ключи
        
        # Проверяем время разблокировки для всех ключей
        now = datetime.now()
        min_time = None
        
        for k in self.api_keys:
            blocked_until = self.key_status.get(k, {}).get("blocked_until")
            if blocked_until:
                time_left = (blocked_until - now).total_seconds()
                if time_left > 0 and (min_time is None or time_left < min_time):
                    min_time = time_left
        
        # Если нет информации о времени разблокировки, возвращаем значение по умолчанию
        return int(min_time) if min_time is not None else 3600  # 1 час по умолчанию
    
    def get_key_stats(self):
        """
        Возвращает статистику использования ключей.
        
        Returns:
            dict: Статистика использования ключей
        """
        stats = {}
        for key, status in self.key_status.items():
            try:
                key_str = str(key)
                key_short = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
            except:
                key_short = "None"
            success_count = status.get("success_count", 0)
            total_requests = status.get("total_requests", 0)
            blocked_until = status.get("blocked_until")
            
            stats[key_short] = {
                "success_rate": round(success_count / max(1, total_requests) * 100, 2),
                "total_requests": total_requests,
                "blocked": blocked_until is not None,
                "blocked_until": blocked_until.strftime("%Y-%m-%d %H:%M:%S") if blocked_until else None,
                "active": key == self.current_key
            }
        return stats
        
    def test_all_keys(self):
        """
        Тестирует все доступные ключи и возвращает их статус.
        
        Returns:
            dict: Статус каждого ключа (True - работает, False - не работает)
        """
        results = {}
        for key in self.api_keys:
            try:
                # Сохраняем текущий ключ
                current_key = self.current_key
                
                # Временно устанавливаем тестируемый ключ
                self.current_key = key
                
                # Выполняем тест
                result = self.test_current_key()
                
                # Безопасное отображение ключа
                try:
                    key_str = str(key)
                    key_display = key_str[:8] + "..." if key and len(key_str) > 8 else key_str
                except:
                    key_display = "[недоступен]"
                
                results[key_display] = result
                
                # Восстанавливаем исходный ключ
                self.current_key = current_key
                
            except Exception as e:
                logger.error(f"Ошибка при тестировании ключа: {e}")
                results[key_display] = False
                
        return results