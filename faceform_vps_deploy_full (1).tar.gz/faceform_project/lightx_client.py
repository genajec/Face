import os
import requests
import json
import logging
import time
import base64
from io import BytesIO
from config import LIGHTX_HAIRSTYLE_STYLES  # Импортируем стили причесок из конфига
import traceback  # Для детального логирования ошибок
from lightx_key_manager import get_key_manager

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LightXClient:
    """Client for LightX API for hairstyle generation"""
    
    def __init__(self):
        """Initialize the LightX client with API key from environment variables"""
        # Инициализируем менеджер ключей с принудительным обновлением
        self.key_manager = get_key_manager(force_new=True)
        self.api_key = self.key_manager.get_current_key()
        if not self.api_key:
            logger.error("LightX API key not found in environment variables")
            raise ValueError("Missing LightX API key")
        
        # Тестируем ключ при создании клиента
        self.key_manager.test_current_key()
        
        # Словарь резервных переводов для часто используемых слов (особенно для цветов)
        self.backup_translations = {
            # Цвета волос
            'черный': 'black hair',
            'черн': 'black hair',
            'черные волосы': 'black hair',
            'черного цвета': 'black color',
            'темный': 'dark',
            'каштановый': 'chestnut brown',
            'коричневый': 'brown',
            'русый': 'blonde',
            'блонд': 'blonde',
            'светлый': 'light blonde',
            'рыжий': 'red',
            'красный': 'red',
            'седой': 'gray',
            # Базовые фразы для причесок
            'волосы': 'hair',
            'прическа': 'hairstyle',
            'стрижка': 'haircut',
            'длинные': 'long',
            'короткие': 'short',
            'средней длины': 'medium length',
            'кудрявые': 'curly',
            'прямые': 'straight',
            'волнистые': 'wavy',
            # Базовые слова для фонов
            'фон': 'background',
            'задний план': 'background',
            'пляж': 'beach',
            'офис': 'office',
            'природа': 'nature',
            'город': 'city',
            'студия': 'studio'
        }
        
        # API endpoints
        self.upload_image_url = "https://api.lightxeditor.com/external/api/v2/uploadImageUrl"
        self.hairstyle_api_url = "https://api.lightxeditor.com/external/api/v1/hairstyle"
        self.order_status_url = "https://api.lightxeditor.com/external/api/v1/order-status"
        self.beautify_url = "https://api.lightxeditor.com/external/api/v2/beautify"  # Обновлено на v2
        self.inpainting_url = "https://api.lightxeditor.com/external/api/v1/inpainting"
        self.remove_bg_url = "https://api.lightxeditor.com/external/api/v1/remove-background"
        self.sketch2image_url = "https://api.lightxeditor.com/external/api/v1/sketch2image"
        self.text2image_url = "https://api.lightxeditor.com/external/api/v1/text2image"
        self.emotion_url = "https://api.lightxeditor.com/external/api/v1/emotion"
        self.replace_url = "https://api.lightxeditor.com/external/api/v1/replace"  # URL для Replace API
        
        # Headers for API requests
        self.headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key
        }
        
        # DeepL API key для перевода
        self.deepl_api_key = os.environ.get("DEEPL_API_KEY", "7fe9dd7a-990a-4bf1-86af-a216b1b993a1:fx")
        self.deepl_api_url = "https://api-free.deepl.com/v2/translate"
        
    def translate_with_deepl(self, text, source_lang="RU", target_lang="EN"):
        """
        Переводит текст с помощью DeepL API
        
        Args:
            text (str): Исходный текст для перевода
            source_lang (str): Язык исходного текста (по умолчанию "RU" - русский)
            target_lang (str): Язык, на который нужно перевести (по умолчанию "EN" - английский)
            
        Returns:
            str: Переведенный текст или резервный перевод на основе словаря при ошибке
        """
        # Проверяем, не является ли текст пустым или None
        if not text:
            logger.warning("Attempted to translate empty text")
            return text
            
        # Если текст уже на английском языке, просто возвращаем его
        if text.strip().isascii():
            logger.info(f"Text already appears to be in English, skipping translation: '{text}'")
            return text
            
        # Сначала проверяем, есть ли точное совпадение в нашем словаре резервных переводов
        text_lower = text.lower().strip()
        if text_lower in self.backup_translations:
            translated = self.backup_translations[text_lower]
            logger.info(f"Found exact match in backup dictionary: '{text}' -> '{translated}'")
            return translated
        
        # Проверяем наличие ключевых слов о цвете волос
        for key_word in ['черный', 'черные', 'черн']:
            if key_word in text_lower and ('волосы' in text_lower or 'цвет' in text_lower):
                logger.info(f"Found 'black' keyword in text: '{text}'")
                result = text_lower.replace(key_word, 'black')
                result = result.replace('волосы', 'hair')
                result = result.replace('цвет', 'color')
                logger.info(f"Basic translation: '{text}' -> '{result}'")
                return result
        
        try:
            # Заголовки с ключом API
            headers = {
                "Authorization": f"DeepL-Auth-Key {self.deepl_api_key}",
                "Content-Type": "application/json"
            }
            
            # Данные для запроса
            data = {
                "text": [text],
                "source_lang": source_lang,
                "target_lang": target_lang
            }
            
            logger.info(f"Sending translation request to DeepL API for text: '{text}'")
            
            # Отправляем запрос
            response = requests.post(self.deepl_api_url, json=data, headers=headers)
            
            # Проверяем успешность запроса
            if response.status_code == 200:
                result = response.json()
                logger.info(f"DeepL API response: {result}")
                
                if "translations" in result and len(result["translations"]) > 0:
                    translated_text = result["translations"][0]["text"]
                    logger.info(f"DeepL translation successful: '{text}' -> '{translated_text}'")
                    
                    # Проверяем результат перевода на наличие ключевых слов для чёрного цвета
                    if ('черный' in text_lower or 'черные' in text_lower or 'черного' in text_lower) and 'black' not in translated_text.lower():
                        logger.warning(f"DeepL did not translate 'черный' to 'black'. Original: '{text}', Translation: '{translated_text}'")
                        # Принудительно добавляем 'black' в перевод
                        if 'hair' in translated_text.lower():
                            translated_text = translated_text.lower().replace('hair', 'black hair')
                        else:
                            translated_text = f"black {translated_text}"
                        logger.info(f"Corrected translation for black color: '{translated_text}'")
                    
                    return translated_text
                else:
                    logger.warning(f"DeepL API returned 200 but no translations found in response: {result}")
            else:
                # Если запрос неуспешен, логируем ошибку и используем резервный перевод
                logger.warning(f"DeepL API error: {response.status_code} - {response.text}")
        except Exception as e:
            logger.error(f"Error in DeepL API: {e}")
            logger.error(f"Stack trace: {traceback.format_exc()}")
        
        # Если дошли до этого места, значит перевод через API не удался,
        # пробуем использовать базовые замены для русских слов
        logger.info(f"Using backup dictionary translation for: '{text}'")
        
        result = text_lower
        for rus_word, eng_word in self.backup_translations.items():
            if rus_word in result:
                result = result.replace(rus_word, eng_word)
        
        if result != text_lower:
            logger.info(f"Backup translation: '{text}' -> '{result}'")
            return result
            
        # Если ничего не сработало, возвращаем исходный текст
        logger.warning(f"No translation available for: '{text}', returning original")
        return text
        
    def get_image_upload_url(self, image_size, content_type="image/jpeg", max_retries=3):
        """
        Get a URL for uploading an image to LightX service
        
        Args:
            image_size (int): Size of the image in bytes
            content_type (str): Content type of the image
            max_retries (int): Максимальное количество попыток с разными ключами
            
        Returns:
            tuple: (upload_url, image_url) or (None, None) if there's an error
        """
        retries = 0
        while retries <= max_retries:
            try:
                # Проверяем текущий ключ и обновляем заголовки
                current_key = self.key_manager.get_current_key()
                if current_key != self.api_key:
                    self.api_key = current_key
                    self.headers = {
                        "Content-Type": "application/json",
                        "x-api-key": self.api_key
                    }
                    # Безопасное отображение ключа для логов
                    key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                    logger.info(f"Обновлен API ключ в заголовках: {key_display}")
                
                # Prepare request data
                data = {
                    "uploadType": "imageUrl",
                    "size": image_size,
                    "contentType": content_type
                }
                
                # Безопасное отображение ключа для логов
                key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                # Make the request
                logger.info(f"Requesting image upload URL from LightX API (try {retries+1}/{max_retries+1}) с ключом {key_display}")
                response = requests.post(self.upload_image_url, headers=self.headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                # Check response
                if response.status_code == 200:
                    # Parse response
                    result = response.json()
                    if result.get("statusCode") != 2000 or "body" not in result:
                        logger.error(f"Invalid response from upload URL API: {result}")
                        retries += 1
                        continue
                        
                    # Extract URLs
                    upload_image = result["body"].get("uploadImage")
                    image_url = result["body"].get("imageUrl")
                    
                    if not upload_image or not image_url:
                        logger.error("Missing upload URLs in response")
                        retries += 1
                        continue
                        
                    logger.info(f"Successfully obtained upload URL: {image_url}")
                    return upload_image, image_url
                else:
                    # Если ключ нужно заменить
                    if needs_key_switch:
                        logger.warning(f"Смена API ключа из-за ошибки {response.status_code}")
                        self.api_key = new_key
                        self.headers["x-api-key"] = self.api_key
                    
                    logger.error(f"Failed to get upload URL: {response.status_code} - {response.text}")
                    retries += 1
                    continue
            
            except Exception as e:
                logger.error(f"Error getting image upload URL: {e}")
                retries += 1
                # Пробуем следующий ключ
                self.api_key = self.key_manager.switch_to_next_key()
                if self.api_key:
                    self.headers["x-api-key"] = self.api_key
        
        # Если дошли сюда, значит все попытки неудачны
        logger.error(f"All {max_retries+1} attempts to get upload URL failed")
        return None, None
            
    def upload_image(self, image_data):
        """
        Upload an image to LightX service
        
        Args:
            image_data (bytes): Image data
            
        Returns:
            str: URL of the uploaded image or None if there's an error
        """
        try:
            # Get image size
            image_size = len(image_data)
            
            # Get upload URL
            upload_url, image_url = self.get_image_upload_url(image_size)
            if not upload_url or not image_url:
                return None
                
            # Prepare headers for PUT request
            put_headers = {
                "Content-Type": "image/jpeg"
            }
            
            # Upload the image
            logger.info(f"Uploading image to {upload_url}")
            put_response = requests.put(upload_url, headers=put_headers, data=image_data)
            
            # Check response
            if put_response.status_code != 200:
                logger.error(f"Failed to upload image: {put_response.status_code} - {put_response.text}")
                return None
                
            logger.info(f"Successfully uploaded image. Image URL: {image_url}")
            return image_url
            
        except Exception as e:
            logger.error(f"Error uploading image: {e}")
            return None
            
    def remove_background(self, image_url, bg_color="#FFFFFF", max_retries=3):
        """
        Remove background from an image and replace with specified color
        
        Args:
            image_url (str): URL of the image to process
            bg_color (str): Background color in HEX format (default: white)
            max_retries (int): Maximum number of retries on failure
            
        Returns:
            str: URL of the processed image or None if there's an error
        """
        # Initialize retry counter
        retries = 0
        
        # Try to remove background with retries
        while retries <= max_retries:
            try:
                # Replace background API endpoint
                replace_bg_url = "https://api.lightxeditor.com/external/api/v1/remove-background"
                
                # Get current API key from key manager
                self.api_key = self.key_manager.get_current_key()
                
                # Prepare headers
                headers = {
                    "Content-Type": "application/json",
                    "x-api-key": self.api_key
                }
                
                # Безопасное отображение ключа для логов
                key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                
                # Prepare request data - обновлено в соответствии с документацией API
                data = {
                    "imageUrl": image_url,
                    "background": bg_color
                }
                
                # Log request details for debugging
                logger.info(f"Sending request to remove background (try {retries+1}/{max_retries+1}) с ключом {key_display}")
                logger.info(f"Request data: {data}")
                
                # Send request
                response = requests.post(replace_bg_url, headers=headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                # Check response
                if response.status_code == 200:
                    # Parse response
                    try:
                        result = response.json()
                        logger.info(f"API response: {result}")
                        
                        # Проверка наличия orderId в ответе
                        if ((result.get("status") == "SUCCESS" or result.get("message") == "SUCCESS") and 
                            "body" in result and "orderId" in result.get("body", {})):
                            
                            # Получаем ID заказа
                            order_id = result.get("body", {}).get("orderId")
                            if not order_id:
                                logger.error("Missing order ID in response")
                                retries += 1
                                continue
                            
                            # Получаем результат обработки с ожиданием
                            logger.info(f"Got order ID: {order_id}, waiting for processing to complete")
                            output_url = self._wait_for_background_removal_result(order_id)
                            
                            if not output_url:
                                logger.error("Failed to get result from order")
                                retries += 1
                                continue
                            
                            logger.info(f"Successfully removed background. Output URL: {output_url}")
                            return output_url
                            
                        # Проверка ответа с готовым URL
                        elif result.get("status") == "SUCCESS" and "body" in result and "outputUrl" in result.get("body", {}):
                            output_url = result.get("body", {}).get("outputUrl")
                            logger.info(f"Got direct output URL: {output_url}")
                            return output_url
                            
                        # Проверяем альтернативный формат ответа
                        elif "outputImage" in result:
                            output_url = result.get("outputImage")
                            logger.info(f"Found output URL in alternative format: {output_url}")
                            return output_url
                            
                        else:
                            logger.error(f"Unsupported response format: {result}")
                            retries += 1
                            # Пробуем следующий ключ
                            self.api_key = self.key_manager.switch_to_next_key()
                            if self.api_key:
                                self.headers["x-api-key"] = self.api_key
                            continue
                    except Exception as e:
                        logger.error(f"Error parsing response: {e}")
                        retries += 1
                        continue
                else:
                    # Если ключ нужно заменить
                    if needs_key_switch:
                        logger.warning(f"Смена API ключа из-за ошибки {response.status_code}")
                        self.api_key = new_key
                        self.headers["x-api-key"] = self.api_key
                    
                    logger.error(f"Failed to remove background: {response.status_code} - {response.text}")
                    retries += 1
                    continue
                
            except Exception as e:
                logger.error(f"Error removing background: {e}")
                retries += 1
                # Пробуем следующий ключ
                self.api_key = self.key_manager.switch_to_next_key()
                if self.api_key:
                    self.headers["x-api-key"] = self.api_key
        
        # Если дошли сюда, значит все попытки неудачны
        logger.error(f"All {max_retries+1} attempts to remove background failed")
        return None
    
    def _wait_for_background_removal_result(self, order_id, max_attempts=10, delay=2):
        """
        Ожидает результата обработки заказа на удаление фона
        
        Args:
            order_id (str): ID заказа
            max_attempts (int): Максимальное количество попыток проверки
            delay (int): Задержка между попытками в секундах
            
        Returns:
            str: URL обработанного изображения или None в случае ошибки
        """
        # Правильный способ проверки статуса с использованием order-status API в соответствии с документацией
        status_url = "https://api.lightxeditor.com/external/api/v1/order-status"
        
        # Итерации проверки статуса
        for attempt in range(max_attempts):
            try:
                logger.info(f"Checking order status for ID: {order_id}, attempt {attempt+1}/{max_attempts}")
                
                # Получаем текущий API ключ из менеджера ключей
                self.api_key = self.key_manager.get_current_key()
                
                # Заголовки запроса
                headers = {
                    "Content-Type": "application/json",
                    "x-api-key": self.api_key
                }
                
                # Данные запроса
                data = {
                    "orderId": order_id
                }
                
                # Делаем запрос на проверку статуса
                response = requests.post(status_url, headers=headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                # Проверка статуса
                if response.status_code == 200:
                    # Парсим ответ
                    result = response.json()
                    logger.info(f"Status API response: {result}")
                    
                    # Проверка формата ответа
                    if result.get("statusCode") == 2000 and "body" in result:
                        status = result["body"].get("status")
                        
                        # Проверяем, активен ли заказ (т.е. результат готов)
                        if status == "active":
                            output_url = result["body"].get("output")
                            if output_url:
                                logger.info(f"Background removal completed. Output URL: {output_url}")
                                return output_url
                                
                        # Если заказ не активен, проверяем на ошибку
                        elif status == "failed":
                            logger.error(f"Order processing failed: {result}")
                            return None
                            
                        # Иначе заказ еще обрабатывается, ждем
                        logger.info(f"Order status: {status}, waiting {delay} seconds...")
                        time.sleep(delay)
                        continue
                else:
                    # Если ключ нужно заменить
                    if needs_key_switch:
                        logger.warning(f"Switching API key due to error {response.status_code}")
                        self.api_key = new_key
                        self.headers["x-api-key"] = self.api_key
                    
                    logger.error(f"Status check failed: {response.status_code} - {response.text}")
                    time.sleep(delay)
                    continue
                    
            except Exception as e:
                logger.error(f"Error checking order status: {e}")
                time.sleep(delay)
                continue
        
        # Резервный механизм - попробуем прямой запрос результата через CDN для совместимости
        output_url = f"https://d3aa3s3yhl0emm.cloudfront.net/output/lx/rm-bg/{order_id}.jpg"
        logger.info(f"Trying direct CDN URL: {output_url}")
        
        try:
            response = requests.head(output_url)
            if response.status_code == 200:
                logger.info(f"Found direct CDN URL: {output_url}")
                return output_url
        except Exception as e:
            logger.error(f"Error checking direct CDN URL: {e}")
        
        # Попробуем альтернативный формат URL
        alt_output_url = f"https://d3aa3s3yhl0emm.cloudfront.net/output/lx/aifilter/{order_id}.jpg"
        logger.info(f"Trying alternative URL format: {alt_output_url}")
        
        try:
            response = requests.head(alt_output_url)
            if response.status_code == 200:
                logger.info(f"Found alternative CDN URL: {alt_output_url}")
                return alt_output_url
        except Exception as e:
            logger.error(f"Error checking alternative URL: {e}")
        
        logger.error(f"Timed out waiting for background removal result after {max_attempts} attempts")
        return None
            
    def download_image(self, image_url):
        """
        Download image from URL
        
        Args:
            image_url (str): URL of the image to download
            
        Returns:
            bytes: Image data or None if there's an error
        """
        try:
            # Download the image
            response = requests.get(image_url)
            
            # Check response
            if response.status_code != 200:
                logger.error(f"Failed to download image: {response.status_code}")
                return None
                
            # Return image data
            return response.content
            
        except Exception as e:
            logger.error(f"Error downloading image: {e}")
            return None
            
    def generate_from_text(self, text_prompt, max_retries=3):
        """
        Генерирует изображение из текстового запроса, используя LightX AI Image Generator API V2
        
        Args:
            text_prompt (str): Текстовое описание изображения для генерации
            max_retries (int): Максимальное количество попыток при неудаче
            
        Returns:
            bytes: Данные сгенерированного изображения или None при ошибке
        """
        # Initialize retry counter
        retries = 0
        
        # Try to generate image with retries
        while retries <= max_retries:
            try:
                # Text to image API endpoint - обновлено для API V2
                text_to_image_url = "https://api.lightxeditor.com/external/api/v1/text2image"
                
                # Get current API key from key manager
                self.api_key = self.key_manager.get_current_key()
                
                # Prepare headers
                headers = {
                    "Content-Type": "application/json",
                    "x-api-key": self.api_key
                }
                
                # Безопасное отображение ключа для логов
                key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                
                # Переводим запрос с русского на английский
                translated_prompt = self.translate_with_deepl(text_prompt)
                logger.info(f"Translated prompt: '{text_prompt}' -> '{translated_prompt}'")
                
                # Prepare request data - обновлено согласно API V2
                data = {
                    "textPrompt": translated_prompt # Обновлено поле с "prompt" на "textPrompt"
                }
                
                # Log request details for debugging
                logger.info(f"Sending request to generate image (try {retries+1}/{max_retries+1}) с ключом {key_display}")
                
                # Send request
                response = requests.post(text_to_image_url, headers=headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                # Check response
                if response.status_code == 200:
                    # Parse response
                    try:
                        result = response.json()
                        logger.info(f"Text2img response: {result}")
                        
                        # Проверка V2 API ответа со статусом 2000
                        if (result.get("statusCode") == 2000 and 
                            "body" in result and "orderId" in result.get("body", {})):
                            
                            # Получаем ID заказа
                            order_id = result.get("body", {}).get("orderId")
                            if not order_id:
                                logger.error("Missing order ID in response")
                                retries += 1
                                continue
                            
                            # Получаем метаданные из ответа
                            max_retries_allowed = result.get("body", {}).get("maxRetriesAllowed", 5)
                            avg_time = result.get("body", {}).get("avgResponseTimeInSec", 15)
                            
                            # Получаем результат обработки с ожиданием
                            logger.info(f"Got order ID: {order_id}, avg time: {avg_time}s, waiting for processing to complete")
                            output_url = self._wait_for_text_to_image_result(order_id, max_attempts=max_retries_allowed)
                            
                            if not output_url:
                                logger.error("Failed to get result from order")
                                retries += 1
                                continue
                            
                            # Download the generated image
                            logger.info(f"Downloading generated image from URL: {output_url}")
                            image_data = self.download_image(output_url)
                            
                            if not image_data:
                                logger.error("Failed to download generated image")
                                retries += 1
                                continue
                                
                            logger.info(f"Successfully generated image from text")
                            return image_data
                                
                        # Поддержка старых форматов для обратной совместимости    
                        elif ((result.get("status") == "SUCCESS" or result.get("message") == "SUCCESS") and 
                            "body" in result and "orderId" in result.get("body", {})):
                            
                            # Получаем ID заказа
                            order_id = result.get("body", {}).get("orderId")
                            if not order_id:
                                logger.error("Missing order ID in response")
                                retries += 1
                                continue
                            
                            # Получаем результат обработки с ожиданием
                            logger.info(f"Got order ID: {order_id}, waiting for processing to complete")
                            output_url = self._wait_for_text_to_image_result(order_id)
                            
                            if not output_url:
                                logger.error("Failed to get result from order")
                                retries += 1
                                continue
                            
                            # Download the generated image
                            logger.info(f"Downloading generated image from URL: {output_url}")
                            image_data = self.download_image(output_url)
                            
                            if not image_data:
                                logger.error("Failed to download generated image")
                                retries += 1
                                continue
                                
                            logger.info(f"Successfully generated image from text")
                            return image_data
                        
                        # Проверяем старый формат ответа
                        elif "outputImage" in result or "outputUrl" in result:
                            output_url = result.get("outputImage") or result.get("outputUrl")
                            
                            if output_url:
                                # Download the generated image
                                logger.info(f"Downloading generated image from URL (old format): {output_url}")
                                image_data = self.download_image(output_url)
                                
                                if not image_data:
                                    logger.error("Failed to download generated image")
                                    retries += 1
                                    continue
                                    
                                logger.info(f"Successfully generated image from text")
                                return image_data
                                
                        else:
                            logger.error(f"Unsupported response format: {result}")
                            retries += 1
                            # Пробуем следующий ключ
                            self.api_key = self.key_manager.switch_to_next_key()
                            if self.api_key:
                                self.headers["x-api-key"] = self.api_key
                            continue
                            
                    except Exception as e:
                        logger.error(f"Error parsing response: {e}")
                        retries += 1
                        # Пробуем следующий ключ
                        self.api_key = self.key_manager.switch_to_next_key()
                        if self.api_key:
                            self.headers["x-api-key"] = self.api_key
                        continue
                else:
                    # Если ключ нужно заменить
                    if needs_key_switch:
                        logger.warning(f"Смена API ключа из-за ошибки {response.status_code}")
                        self.api_key = new_key
                        self.headers["x-api-key"] = self.api_key
                    
                    logger.error(f"Failed to generate image: {response.status_code} - {response.text}")
                    retries += 1
                    # Пауза перед следующей попыткой
                    time.sleep(1)
                    continue
                    
            except Exception as e:
                logger.error(f"Error generating image (attempt {retries+1}): {e}")
                retries += 1
                # Пробуем следующий ключ
                self.api_key = self.key_manager.switch_to_next_key()
                if self.api_key:
                    self.headers["x-api-key"] = self.api_key
                # Пауза перед следующей попыткой
                time.sleep(1)
        
        # Если дошли сюда, значит все попытки неудачны
        logger.error(f"All {max_retries+1} attempts to generate image failed")
        return None
        
    def _wait_for_text_to_image_result(self, order_id, max_attempts=5, delay=3):
        """
        Ожидает результата обработки заказа на генерацию изображения по тексту
        согласно документации API V2
        
        Args:
            order_id (str): ID заказа
            max_attempts (int): Максимальное количество попыток проверки (по документации до 5)
            delay (int): Задержка между попытками в секундах (по документации 3 секунды)
            
        Returns:
            str: URL сгенерированного изображения или None в случае ошибки
        """
        # API для проверки статуса заказа
        status_url = "https://api.lightxeditor.com/external/api/v1/order-status"
        
        # Итерации проверки статуса
        for attempt in range(max_attempts):
            try:
                # Получаем текущий API ключ
                current_key = self.key_manager.get_current_key()
                if current_key != self.api_key:
                    self.api_key = current_key
                
                # Подготавливаем заголовки
                headers = {
                    "Content-Type": "application/json",
                    "x-api-key": self.api_key
                }
                
                # Подготавливаем данные запроса
                data = {
                    "orderId": order_id
                }
                
                logger.info(f"Проверка статуса генерации изображения, попытка {attempt+1}/{max_attempts}")
                
                # Отправляем запрос
                response = requests.post(status_url, headers=headers, json=data)
                
                # Проверяем ответ
                if response.status_code == 200:
                    try:
                        result = response.json()
                        logger.info(f"Ответ API статуса: {result}")
                        
                        # Проверяем статус согласно API V2
                        if (result.get("statusCode") == 2000 and 
                            "body" in result and "status" in result.get("body", {})):
                            
                            status = result["body"]["status"]
                            
                            # Проверяем готовность результата
                            if status == "active":
                                output_url = result["body"].get("output")
                                if output_url:
                                    logger.info(f"Генерация изображения завершена. URL результата: {output_url}")
                                    return output_url
                                else:
                                    logger.warning("Статус активен, но URL результата отсутствует")
                            
                            # Проверяем ошибку обработки
                            elif status == "failed":
                                logger.error(f"Ошибка обработки заказа: {result}")
                                return None
                            
                            # Иначе заказ еще в обработке
                            logger.info(f"Статус заказа: {status}, ожидание {delay} секунд...")
                        else:
                            logger.warning(f"Неожиданный формат ответа API статуса: {result}")
                    except Exception as e:
                        logger.error(f"Ошибка при обработке ответа API статуса: {e}")
                else:
                    logger.error(f"Ошибка запроса статуса заказа: {response.status_code} - {response.text}")
            
            except Exception as e:
                logger.error(f"Ошибка при проверке статуса заказа: {e}")
            
            # Задержка перед следующей попыткой
            time.sleep(delay)
        
        # Если не удалось получить результат через API, попробуем прямой запрос через CDN
        # Это запасной вариант
        logger.warning(f"Не удалось получить результат через API, пробуем прямой запрос к CDN")
        output_url = f"https://d3aa3s3yhl0emm.cloudfront.net/output/lx/text2img/{order_id}.jpg"
        
        try:
            response = requests.head(output_url)
            if response.status_code == 200:
                logger.info(f"Генерация изображения завершена (через прямой CDN). URL: {output_url}")
                return output_url
        except Exception as e:
            logger.error(f"Ошибка при прямой проверке доступности результата: {e}")
        
        logger.error(f"Превышено время ожидания результата после {max_attempts} попыток")
        return None
            
    def generate_hairstyle(self, image_url, text_prompt, max_retries=3):
        """
        Generate a hairstyle using LightX API
        
        Args:
            image_url (str): URL of the uploaded image
            text_prompt (str): Text prompt describing the hairstyle
            max_retries (int): Максимальное количество попыток с разными ключами
            
        Returns:
            str: Order ID for checking status or None if there's an error
        """
        retries = 0
        while retries <= max_retries:
            try:
                # Проверяем текущий ключ и обновляем заголовки
                current_key = self.key_manager.get_current_key()
                if current_key != self.api_key:
                    self.api_key = current_key
                    self.headers = {
                        "Content-Type": "application/json",
                        "x-api-key": self.api_key
                    }
                    # Безопасное отображение ключа для логов
                    key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                    logger.info(f"Обновлен API ключ в заголовках: {key_display}")
                
                # Переводим запрос с русского на английский
                translated_prompt = self.translate_with_deepl(text_prompt)
                logger.info(f"Translated hairstyle prompt: '{text_prompt}' -> '{translated_prompt}'")
                
                # Добавляем глобальные инструкции для сохранения лица и фона
                preserve_instructions = "preserve facial features exactly, do not change face shape or characteristics, maintain same facial expression, keep original background unchanged, same face same person, only change hairstyle"
                
                # Комбинируем основной запрос с инструкциями сохранения
                enhanced_prompt = f"{translated_prompt}, {preserve_instructions}"
                
                # Prepare request data
                data = {
                    "imageUrl": image_url,
                    "textPrompt": enhanced_prompt
                }
                
                # Безопасное отображение ключа для логов
                key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                # Make the request
                logger.info(f"Requesting hairstyle generation with prompt (try {retries+1}/{max_retries+1}) с ключом {key_display}")
                response = requests.post(self.hairstyle_api_url, headers=self.headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                # Check response
                if response.status_code == 200:
                    # Parse response
                    result = response.json()
                    if result.get("statusCode") != 2000 or "body" not in result:
                        logger.error(f"Invalid response from hairstyle API: {result}")
                        retries += 1
                        continue
                        
                    # Extract order ID
                    order_id = result["body"].get("orderId")
                    if not order_id:
                        logger.error("Missing order ID in response")
                        retries += 1
                        continue
                        
                    logger.info(f"Successfully requested hairstyle generation. Order ID: {order_id}")
                    return order_id
                else:
                    # Если ключ нужно заменить
                    if needs_key_switch:
                        logger.warning(f"Смена API ключа из-за ошибки {response.status_code}")
                        self.api_key = new_key
                        self.headers["x-api-key"] = self.api_key
                    
                    logger.error(f"Failed to request hairstyle generation: {response.status_code} - {response.text}")
                    retries += 1
                    continue
                
            except Exception as e:
                logger.error(f"Error requesting hairstyle generation: {e}")
                retries += 1
                # Пробуем следующий ключ
                self.api_key = self.key_manager.switch_to_next_key()
                if self.api_key:
                    self.headers["x-api-key"] = self.api_key
        
        # Если дошли сюда, значит все попытки неудачны
        logger.error(f"All {max_retries+1} attempts to generate hairstyle failed")
        return None
            
    def check_order_status(self, order_id, max_retries=2):
        """
        Check the status of an order (hairstyle, background, etc.)
        
        Args:
            order_id (str): Order ID
            max_retries (int): Максимальное количество попыток с разными ключами
            
        Returns:
            tuple: (status, output_url) or (None, None) if there's an error
        """
        retries = 0
        while retries <= max_retries:
            try:
                # Проверяем текущий ключ и обновляем заголовки
                current_key = self.key_manager.get_current_key()
                if current_key and current_key != self.api_key:
                    self.api_key = current_key
                    self.headers = {
                        "Content-Type": "application/json",
                        "x-api-key": self.api_key
                    }
                    # Безопасное отображение ключа для логов
                    key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                    logger.info(f"Обновлен API ключ в заголовках: {key_display}")
                
                # Проверяем, что у нас есть валидный ключ API
                if not self.api_key:
                    logger.error("API ключ не установлен или недействителен")
                    return None, None
                
                # Prepare request data - используем строго формат из документации API
                data = {
                    "orderId": order_id  # Точно так же, как в документации
                }
                
                # Безопасное отображение ключа для логов
                key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                # Make the request
                logger.info(f"Проверка статуса заказа {order_id} в LightX API (try {retries+1}/{max_retries+1}) с ключом {key_display}")
                response = requests.post(self.order_status_url, headers=self.headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                # Check response
                if response.status_code == 200:
                    # Parse response
                    result = response.json()
                    if result.get("statusCode") != 2000 or "body" not in result:
                        logger.error(f"Invalid response from order status API: {result}")
                        retries += 1
                        continue
                        
                    # Extract status and output URL
                    status = result["body"].get("status")
                    output_url = result["body"].get("output")
                    
                    logger.info(f"Статус заказа: {status}, URL результата: {output_url if output_url else 'еще не готов'}")
                    return status, output_url
                else:
                    # Если ключ нужно заменить
                    if needs_key_switch:
                        logger.warning(f"Смена API ключа из-за ошибки {response.status_code}")
                        self.api_key = new_key
                        self.headers["x-api-key"] = self.api_key
                    
                    logger.error(f"Failed to check order status: {response.status_code} - {response.text}")
                    retries += 1
                    continue
                
            except Exception as e:
                logger.error(f"Error checking order status: {e}")
                retries += 1
                # Пробуем следующий ключ
                self.api_key = self.key_manager.switch_to_next_key()
                if self.api_key:
                    self.headers["x-api-key"] = self.api_key
        
        # Если дошли сюда, значит все попытки неудачны
        logger.error(f"All {max_retries+1} attempts to check order status failed")
        return None, None
            
    def wait_for_result(self, order_id, max_retries=5, retry_interval=3):
        """
        Wait for the result of a hairstyle generation order
        
        Args:
            order_id (str): Order ID
            max_retries (int): Maximum number of retry attempts
            retry_interval (int): Time between retries in seconds
            
        Returns:
            str: URL of the generated image or None if there's an error
        """
        try:
            for attempt in range(max_retries):
                logger.info(f"Waiting for result, attempt {attempt+1}/{max_retries}")
                
                # Wait before checking
                time.sleep(retry_interval)
                
                # Check status
                status, output_url = self.check_order_status(order_id)
                
                # If active and output is available, return it
                if status == "active" and output_url:
                    logger.info(f"Order completed successfully. Output URL: {output_url}")
                    return output_url
                    
                # If still in progress, continue waiting
                elif status == "init":
                    logger.info("Order is still being processed")
                    continue
                    
                # If failed, stop waiting
                elif status == "failed":
                    logger.error("Order processing failed")
                    return None
                    
                # Unknown status
                else:
                    logger.warning(f"Unknown order status: {status}")
                    
            logger.error(f"Maximum retries ({max_retries}) reached while waiting for result")
            return None
            
        except Exception as e:
            logger.error(f"Error waiting for result: {e}")
            return None
            
    def apply_hairstyle(self, image_data, hairstyle_prompt, max_retries=3):
        """
        Apply a hairstyle to an image using LightX API
        
        Args:
            image_data (bytes): Image data
            hairstyle_prompt (str): Text prompt describing the hairstyle
            max_retries (int): Максимальное количество попыток с разными ключами
            
        Returns:
            bytes: Generated image with the hairstyle applied or None if there's an error
        """
        retries = 0
        while retries <= max_retries:
            try:
                # Проверяем текущий ключ и обновляем заголовки
                current_key = self.key_manager.get_current_key()
                if current_key and current_key != self.api_key:
                    self.api_key = current_key
                    self.headers = {
                        "Content-Type": "application/json",
                        "x-api-key": self.api_key
                    }
                    # Безопасное отображение ключа для логов
                    key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                    logger.info(f"Обновлен API ключ в заголовках для apply_hairstyle: {key_display}")
                
                logger.info(f"Starting hairstyle generation process with LightX API (попытка {retries+1}/{max_retries+1})")
                logger.info(f"Original hairstyle prompt: {hairstyle_prompt}")
                logger.info(f"Image data size: {len(image_data)} bytes")
                
                # Особая обработка для "Wolf Cut" - сохраняем стиль без перевода
                if "wolf cut" in hairstyle_prompt.lower():
                    logger.info("ВАЖНО: Обнаружен стиль Wolf Cut, сохраняем оригинальный промпт без перевода")
                    translated_prompt = hairstyle_prompt
                else:
                    # Обычный перевод для других стилей
                    translated_prompt = self.translate_with_deepl(hairstyle_prompt)
                    
                logger.info(f"Финальный hairstyle prompt: '{hairstyle_prompt}' -> '{translated_prompt}'")
                
                # Проверяем, содержит ли запрос упоминание черного цвета
                prompt_lower = translated_prompt.lower()
                original_lower = hairstyle_prompt.lower()
                
                # Проверка на ключевые слова черного цвета на английском и русском
                is_black_color = any(word in original_lower for word in ['черные волосы', 'черный', 'черные']) or 'black' in prompt_lower
                
                # Если черный цвет присутствовал в запросе, но нет слова "black", добавим его явно
                if is_black_color and 'black' not in prompt_lower:
                    logger.info(f"Обнаружены ключевые слова для черного цвета волос, но слово 'black' отсутствует в запросе")
                    if 'hair' in prompt_lower:
                        # Заменяем "hair" на "black hair" 
                        translated_prompt = translated_prompt.replace('hair', 'black hair')
                        logger.info(f"Заменили 'hair' на 'black hair': {translated_prompt}")
                    else:
                        # Если hair отсутствует, добавляем "black hair" в запрос
                        translated_prompt = f"black hair, {translated_prompt}"
                        logger.info(f"Добавили 'black hair' в запрос: {translated_prompt}")
                
                # Добавляем инструкции для сохранения черт лица и фона
                preserve_instructions = "preserve exact facial features, do not change face, maintain facial expression, keep original background unchanged, same face same person, only modify hairstyle"
                
                # Комбинируем основной запрос с инструкциями сохранения
                enhanced_prompt = f"{translated_prompt}, {preserve_instructions}"
                
                # Для запросов с черным цветом, добавляем явные инструкции
                if is_black_color:
                    enhanced_prompt = f"{enhanced_prompt}, deep black hair color, solid black, no highlights"
                    logger.info(f"Добавлены специальные инструкции для черного цвета волос: {enhanced_prompt}")
                
                # Upload the image
                logger.info("Step 1: Uploading image to LightX API...")
                image_url = self.upload_image(image_data)
                if not image_url:
                    logger.error("Failed to upload image")
                    # Пробуем следующий ключ
                    self.api_key = self.key_manager.switch_to_next_key()
                    if not self.api_key:
                        logger.error("Все ключи исчерпаны или недоступны")
                        return None
                    self.headers["x-api-key"] = self.api_key
                    retries += 1
                    continue
                    
                # Generate hairstyle
                logger.info(f"Step 2: Generating hairstyle with prompt: {enhanced_prompt}")
                order_id = self.generate_hairstyle(image_url, enhanced_prompt)
                if not order_id:
                    logger.error("Failed to generate hairstyle - no order ID received")
                    # Пробуем следующий ключ
                    self.api_key = self.key_manager.switch_to_next_key()
                    if not self.api_key:
                        logger.error("Все ключи исчерпаны или недоступны")
                        return None
                    self.headers["x-api-key"] = self.api_key
                    retries += 1
                    continue
                    
                # Wait for the result
                logger.info(f"Step 3: Waiting for processing to complete. Order ID: {order_id}")
                output_url = self.wait_for_result(order_id, max_retries=10, retry_interval=2)
                if not output_url:
                    logger.error("Failed to get result URL after waiting")
                    # Пробуем следующий ключ
                    self.api_key = self.key_manager.switch_to_next_key()
                    if not self.api_key:
                        logger.error("Все ключи исчерпаны или недоступны")
                        return None
                    self.headers["x-api-key"] = self.api_key
                    retries += 1
                    continue
                    
                # Download the result
                logger.info(f"Step 4: Downloading result from {output_url}")
                response = requests.get(output_url)
                
                # Check response
                if response.status_code != 200:
                    logger.error(f"Failed to download result: {response.status_code}")
                    retries += 1
                    continue
                    
                logger.info(f"Successfully completed hairstyle generation! Result size: {len(response.content)} bytes")
                return response.content
                
            except Exception as e:
                logger.error(f"Error applying hairstyle: {e}")
                # Log более подробную информацию об ошибке
                import traceback
                logger.error(f"Stack trace: {traceback.format_exc()}")
                
                # Пробуем следующий ключ
                self.api_key = self.key_manager.switch_to_next_key()
                if not self.api_key:
                    logger.error("Все ключи исчерпаны или недоступны")
                    return None
                self.headers["x-api-key"] = self.api_key
                retries += 1
                
        # Если дошли сюда, значит все попытки неудачны
        logger.error(f"All {max_retries+1} attempts to apply hairstyle failed")
        return None
            
    def get_hairstyle_prompts_by_face_shape(self, face_shape_param, gender_param=None):
        """
        Get hairstyle prompts recommended for a specific face shape and gender
        
        Args:
            face_shape_param (str): Face shape (OVAL, ROUND, SQUARE, HEART, OBLONG, DIAMOND)
            gender_param (str, optional): Gender for filtering hairstyles (male, female)
            
        Returns:
            list: List of hairstyle prompts
        """
        # Для обратной совместимости с кодом, который ожидает имена face_shape и gender
        face_shape = face_shape_param
        gender = gender_param
        # Преобразуем данные из конфига в формат, который ожидает метод
        hairstyle_prompts = []
        
        # Проверяем, не является ли face_shape None
        if face_shape is None:
            logger.error("Face shape is None, using OVAL as default")
            face_shape = "OVAL"
            
        # Получаем стили для указанной формы лица
        face_shape_styles = LIGHTX_HAIRSTYLE_STYLES.get(face_shape, LIGHTX_HAIRSTYLE_STYLES.get("OVAL", []))
        
        # Логгируем полученные стили для отладки
        logger.info(f"Getting hairstyle prompts for {face_shape} from config: {len(face_shape_styles)} styles available")
        
        # Фильтрация по полу, если указан
        if gender:
            gender_marker = "(M)" if gender == "male" else "(Ж)"
            opposite_marker = "(Ж)" if gender == "male" else "(M)"
            
            # Находим прически с нужной меткой пола
            gender_specific_styles = []
            universal_styles = []
            
            for style in face_shape_styles:
                style_name = style.get("name", "")
                # Проверяем, соответствует ли стиль указанному полу
                if gender_marker in style_name:
                    gender_specific_styles.append(style)
                # Проверяем, это универсальная прическа (без пометок пола)
                elif opposite_marker not in style_name:
                    universal_styles.append(style)
            
            # Объединяем специфичные для пола и универсальные стили
            face_shape_styles = gender_specific_styles + universal_styles
            
            logger.info(f"Filtered styles by gender ({gender}): {len(gender_specific_styles)} gender-specific + {len(universal_styles)} universal styles = {len(face_shape_styles)} total")
        
        # Преобразуем формат
        for i, style in enumerate(face_shape_styles):
            style_name = style.get("name", f"Стиль {i+1}")
            style_prompt = style.get("style", "elegant hairstyle")
            
            # Особая логика для Wolf Cut - логируем подробнее для отладки
            if "Wolf Cut" in style_name:
                logger.info(f"Found Wolf Cut style: '{style_name}' for face shape: {face_shape}")
                logger.info(f"Wolf Cut prompt: {style_prompt[:50]}...")
            
            # Сохраняем и "style" и "prompt" для обратной совместимости
            hairstyle_prompt = {
                "id": f"{face_shape.lower()}_{i+1}",
                "name": style_name,
                "prompt": style_prompt,
                "style": style_prompt
            }
            
            logger.debug(f"Created hairstyle prompt: {hairstyle_prompt['name']}")
            hairstyle_prompts.append(hairstyle_prompt)
        
        # Если список пуст (что неожиданно), используем значения по умолчанию
        if not hairstyle_prompts:
            logger.warning(f"No hairstyle prompts found for {face_shape} and gender {gender}, using defaults")
            if gender == "male":
                hairstyle_prompts = [
                    {
                        "id": "default_male_1", 
                        "name": "Классическая мужская стрижка", 
                        "prompt": "classic men's haircut, short sides, clean professional look",
                        "style": "classic men's haircut, short sides, clean professional look"
                    },
                    {
                        "id": "default_male_2", 
                        "name": "Современный мужской стиль", 
                        "prompt": "modern men's hairstyle, textured top",
                        "style": "modern men's hairstyle, textured top"
                    }
                ]
            else:
                hairstyle_prompts = [
                    {
                        "id": "default_female_1", 
                        "name": "Классический боб", 
                        "prompt": "classic bob haircut, shoulder length, straight hair",
                        "style": "classic bob haircut, shoulder length, straight hair"
                    },
                    {
                        "id": "default_female_2", 
                        "name": "Элегантный женский стиль", 
                        "prompt": "elegant women's hairstyle, professional looking",
                        "style": "elegant women's hairstyle, professional looking"
                    }
                ]
        
        logger.info(f"Returning {len(hairstyle_prompts)} hairstyle prompts for {face_shape} with gender {gender}")
        return hairstyle_prompts
        
    # Добавленные методы для дополнительных функций меню 4-9
    
    def retouch_photo(self, image_data):
        """
        Ретуширует фотографию, улучшая ее качество
        
        Args:
            image_data (bytes): Исходная фотография
            
        Returns:
            bytes: Ретушированная фотография или None, если ошибка
        """
        try:
            # Загружаем изображение
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload image for retouching")
                return None
                
            # Создаем запрос для ретуши фото (используем специальный API LightX)
            data = {
                "imageUrl": image_url,
                "options": {
                    "skinSmoothing": True,
                    "enhanceFeatures": True,
                    "removeImperfections": True,
                    "improveContrast": True,
                    "level": 0.75  # Уровень ретуши (0-1)
                }
            }
            
            # Проверяем заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            # Отправляем запрос
            logger.info(f"Requesting photo retouching with image URL: {image_url}")
            response = requests.post(self.beautify_url, headers=headers, json=data)
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request photo retouching: {response.status_code} - {response.text}")
                return None
                
            # Анализируем ответ
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from beautify API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            # Ждем результат
            output_url = self.wait_for_result(order_id)
            if not output_url:
                return None
                
            # Загружаем результат
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download retouched photo: {response.status_code}")
                return None
                
            return response.content
            
        except Exception as e:
            logger.error(f"Error retouching photo: {e}")
            return None
            
    
    def change_background(self, image_data, background_prompt, style_image_data=None, max_retries=3):
        """
        Меняет фон на фотографии используя API удаления фона с последующей установкой нового фона
        
        Args:
            image_data (bytes): Исходная фотография
            background_prompt (str): Текстовое описание или цвет нового фона (например, "#FFFFFF" для белого)
            style_image_data (bytes, optional): Изображение стиля для применения к фону
            max_retries (int): Максимальное количество попыток с разными ключами
            
        Returns:
            bytes: Фотография с новым фоном или None, если ошибка
        """
        retries = 0
        while retries <= max_retries:
            # Проверяем текущий ключ и обновляем заголовки
            current_key = self.key_manager.get_current_key()
            if current_key != self.api_key:
                self.api_key = current_key
                # Безопасное отображение ключа для логов
                key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                logger.info(f"Обновлен API ключ для удаления фона: {key_display}")
                
            # Проверка наличия API ключа LightX перед отправкой запроса
            if not self.api_key:
                logger.error("CRITICAL ERROR: API ключ LightX недоступен!")
                if retries < max_retries:
                    # Пытаемся получить следующий ключ
                    self.api_key = self.key_manager.switch_to_next_key()
                    if self.api_key:
                        logger.info(f"Переключение на следующий ключ (попытка {retries+1}/{max_retries+1})")
                        retries += 1
                        continue
                # Если ключи закончились или это последняя попытка
                return None
                
            try:
                # Переводим текстовый запрос с русского на английский, если это не HEX-код цвета
                if background_prompt and not background_prompt.startswith('#') and len(background_prompt) > 2:
                    original_prompt = background_prompt
                    background_prompt = self.translate_with_deepl(background_prompt)
                    logger.info(f"Translated background prompt: '{original_prompt}' -> '{background_prompt}'")
                
                # Подготовка цвета фона или URL изображения фона
                bg_value = background_prompt
                
                # Проверяем, является ли фон цветом в формате HEX
                import re
                is_hex_color = re.match(r'^#(?:[0-9a-fA-F]{3}){1,2}$', str(bg_value)) is not None
                
                # Если это не HEX-цвет и не URL изображения, используем белый цвет по умолчанию
                if not is_hex_color and not (isinstance(bg_value, str) and bg_value.startswith('http')):
                    logger.info(f"Промпт '{bg_value}' не является цветом HEX или URL изображения, используем белый цвет #FFFFFF")
                    bg_value = "#FFFFFF"
                    
                # Шаг 1: Загружаем основное изображение
                logger.info(f"Шаг 1: Загрузка оригинального изображения на сервер LightX (попытка {retries+1}/{max_retries+1})")
                image_url = self.upload_image(image_data)
                if not image_url:
                    logger.error("Failed to upload image for background change")
                    retries += 1
                    # Пытаемся сменить ключ при ошибке
                    self.api_key = self.key_manager.switch_to_next_key()
                    if not self.api_key:
                        logger.error("No more API keys available")
                        return None
                    continue
                    
                logger.info(f"Успешно загружено основное изображение, получен URL: {image_url}")
                
                # Шаг 2: Отправляем запрос на удаление фона с заменой на новый
                logger.info(f"Шаг 2: Отправка запроса на удаление фона с заменой на: '{bg_value}'")
                
                # URL для API удаления фона
                remove_bg_url = "https://api.lightxeditor.com/external/api/v1/remove-background"
                
                # Данные для запроса согласно документации API
                data = {
                    "imageUrl": image_url,
                    "background": bg_value  # Цвет фона или URL изображения фона
                }
                
                # Заголовки для аутентификации
                headers = {
                    "Content-Type": "application/json",
                    "x-api-key": self.api_key
                }
                
                logger.info(f"URL запроса: {remove_bg_url}")
                logger.info(f"Заголовки запроса: Content-Type и x-api-key (скрыт)")
                logger.info(f"Тело запроса: {data}")
                
                # Отправляем запрос
                response = requests.post(remove_bg_url, headers=headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                logger.info(f"Получен ответ API со статусом: {response.status_code}")
                
                # Проверяем ответ
                if response.status_code != 200:
                    # Проверка на ошибку исчерпания кредитов API
                    if "API_CREDITS_CONSUMED" in response.text:
                        logger.error(f"API credits consumed for key {self.api_key[:8]}...")
                        # Помечаем ключ как исчерпавший кредиты (блокируем на длительное время)
                        self.key_manager.mark_request_error(403, self.api_key)  # Используем код 403 для долгой блокировки
                        # Переключаемся на другой ключ
                        self.api_key = self.key_manager.switch_to_next_key()
                        if self.api_key:
                            logger.info(f"Switching to next key: {self.api_key[:8]}...")
                            retries += 1
                            continue
                        else:
                            logger.error("No more API keys available")
                            return None
                    
                    # Если ключ нужно заменить по другим причинам
                    if needs_key_switch:
                        logger.warning(f"Смена API ключа из-за ошибки {response.status_code}")
                        self.api_key = new_key
                        retries += 1
                        continue
                        
                    logger.error(f"Failed to request background removal: {response.status_code} - {response.text}")
                    retries += 1
                    continue
                    
                logger.info(f"Запрос успешно отправлен, получен ответ статус {response.status_code}")
                
                # Анализируем ответ
                result = response.json()
                
                if result.get("statusCode") != 2000 or "body" not in result:
                    # Проверка на ошибку исчерпания кредитов API в JSON ответе
                    if "API_CREDITS_CONSUMED" in str(result):
                        logger.error(f"API credits consumed for key {self.api_key[:8]}... (from JSON response)")
                        # Помечаем ключ как исчерпавший кредиты
                        self.key_manager.mark_request_error(403, self.api_key)  # Используем код 403 для долгой блокировки
                        # Переключаемся на другой ключ
                        self.api_key = self.key_manager.switch_to_next_key()
                        if self.api_key:
                            logger.info(f"Switching to next key: {self.api_key[:8]}...")
                            retries += 1
                            continue
                        else:
                            logger.error("No more API keys available")
                            return None
                    
                    logger.error(f"Invalid response from remove-background API: {result}")
                    retries += 1
                    continue
                    
                # Получаем ID заказа
                order_id = result["body"].get("orderId")
                if not order_id:
                    logger.error("Missing order ID in response")
                    retries += 1
                    continue
                    
                logger.info(f"Получен ID заказа: {order_id}")
                
                # Шаг 3: Ожидаем результат
                logger.info(f"Шаг 3: Ожидание обработки изображения...")
                
                # Увеличиваем количество попыток и интервал ожидания
                output_url = self.wait_for_result(order_id, max_retries=20, retry_interval=3)
                if not output_url:
                    logger.error("Failed to get output URL after waiting")
                    retries += 1
                    continue
                    
                logger.info(f"Обработка завершена, получен URL результата: {output_url}")
                
                # Шаг 4: Загружаем результат
                logger.info(f"Шаг 4: Загрузка обработанного изображения")
                response = requests.get(output_url)
                if response.status_code != 200:
                    logger.error(f"Failed to download image with new background: {response.status_code}")
                    retries += 1
                    continue
                    
                logger.info(f"Успешно загружено обработанное изображение, размер: {len(response.content)} байт")
                return response.content
                
            except Exception as e:
                logger.error(f"Error changing background (attempt {retries+1}/{max_retries+1}): {e}")
                # Более подробное логирование ошибки
                import traceback
                logger.error(f"Stack trace: {traceback.format_exc()}")
                retries += 1
                
                # Пытаемся сменить ключ при ошибке
                if retries <= max_retries:
                    self.api_key = self.key_manager.switch_to_next_key()
                    if not self.api_key:
                        logger.error("Failed to get next API key")
                        return None
                        
                    logger.info(f"Switching to next key after error: {self.api_key[:8]}...")
        
        # Если все попытки исчерпаны
        logger.error(f"All {max_retries+1} attempts failed in change_background")
        return None
    

    def generate_portrait(self, image_data, style_prompt):
        """
        Генерирует портрет в заданном стиле
        
        Args:
            image_data (bytes): Исходная фотография
            style_prompt (str): Текстовое описание стиля
            
        Returns:
            bytes: Сгенерированный портрет или None, если ошибка
        """
        try:
            # Переводим описание стиля с русского на английский
            original_prompt = style_prompt
            translated_prompt = self.translate_with_deepl(style_prompt)
            logger.info(f"Translated style prompt: '{original_prompt}' -> '{translated_prompt}'")
            
            # Загружаем изображение
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload image for portrait generation")
                return None
            
            # Используем sketch2image API для генерации портрета
            data = {
                "imageUrl": image_url,
                "textPrompt": translated_prompt,
                "strength": 0.7  # Значение от 0 до 1, степень влияния текстового промпта
            }
            
            # Проверяем заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            # Отправляем запрос
            logger.info(f"Requesting portrait generation with style: {style_prompt}")
            response = requests.post(self.sketch2image_url, headers=headers, json=data)
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request portrait generation: {response.status_code} - {response.text}")
                return None
                
            # Анализируем ответ
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from portrait generation API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            # Ждем результат
            output_url = self.wait_for_result(order_id, max_retries=15, retry_interval=3)
            if not output_url:
                return None
                
            # Загружаем результат
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download generated portrait: {response.status_code}")
                return None
                
            return response.content
            
        except Exception as e:
            logger.error(f"Error generating portrait: {e}")
            return None
            
    def ai_replace(self, image_data, text_prompt=None, mask_data=None, max_retries=3):
        """
        Заменяет элемент на изображении с помощью текстового запроса (API Replace)
        
        Args:
            image_data (bytes): Исходная фотография
            text_prompt (str, optional): Текстовое описание для замены объекта
            mask_data (bytes, optional): Изображение маски (белый цвет для области замены)
            max_retries (int): Максимальное количество попыток с разными ключами
            
        Returns:
            bytes: Обработанная фотография или None, если ошибка
        """
        retries = 0
        while retries <= max_retries:
            # Проверяем текущий ключ и обновляем заголовки
            current_key = self.key_manager.get_current_key()
            if current_key != self.api_key:
                self.api_key = current_key
                # Безопасное отображение ключа для логов
                key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                logger.info(f"Обновлен API ключ для AI Replace: {key_display}")
                
            # Проверка наличия API ключа LightX перед отправкой запроса
            if not self.api_key:
                logger.error("CRITICAL ERROR: API ключ LightX недоступен!")
                if retries < max_retries:
                    # Пытаемся получить следующий ключ
                    self.api_key = self.key_manager.switch_to_next_key()
                    if self.api_key:
                        logger.info(f"Переключение на следующий ключ (попытка {retries+1}/{max_retries+1})")
                        retries += 1
                        continue
                # Если ключи закончились или это последняя попытка
                return None
                
            try:
                # Проверка обязательного параметра
                if not text_prompt or not text_prompt.strip():
                    logger.error("Text prompt is required for AI Replace API")
                    return None
                
                # Переводим текстовый запрос с русского на английский
                original_prompt = text_prompt
                translated_prompt = self.translate_with_deepl(text_prompt)
                logger.info(f"Translated AI Replace prompt: '{original_prompt}' -> '{translated_prompt}'")
                    
                # Добавляем инструкции для сохранения черт лица
                preserve_instructions = "preserve exact facial features, do not change faces, maintain facial expression, keep face intact, only modify what is specified in the prompt, preserve personal identity"
                
                # Комбинируем основной запрос с инструкциями сохранения
                enhanced_prompt = f"{translated_prompt}, {preserve_instructions}"
                logger.info(f"Enhanced AI Replace prompt: {enhanced_prompt}")
                
                # Проверка наличия маски
                if not mask_data:
                    logger.warning("Mask image is required for AI Replace API according to documentation")
                    logger.warning("Generating a default mask (all white) for the image")
                    
                    try:
                        # Попытка создать простую белую маску с помощью PIL
                        from PIL import Image
                        import io
                        
                        # Создаем временный буфер и загружаем изображение
                        input_buffer = io.BytesIO(image_data)
                        with Image.open(input_buffer) as img:
                            width, height = img.size
                            # Создаем белую маску
                            mask = Image.new('L', (width, height), 255)
                            mask_buffer = io.BytesIO()
                            mask.save(mask_buffer, format='JPEG')
                            mask_buffer.seek(0)
                            mask_data = mask_buffer.read()
                            logger.info(f"Created default white mask with size {width}x{height}")
                    except Exception as e:
                        logger.error(f"Failed to create default mask: {e}")
                        retries += 1
                        continue
                    
                # Загружаем основное изображение
                logger.info(f"Uploading main image for AI Replace, size: {len(image_data)} bytes (попытка {retries+1}/{max_retries+1})")
                image_url = self.upload_image(image_data)
                if not image_url:
                    logger.error("Failed to upload main image for AI Replace")
                    retries += 1
                    # Пытаемся сменить ключ при ошибке
                    self.api_key = self.key_manager.switch_to_next_key()
                    if not self.api_key:
                        logger.error("No more API keys available")
                        return None
                    continue
                
                # Загружаем маску (обязательный параметр)
                logger.info(f"Uploading mask image for AI Replace, size: {len(mask_data)} bytes")
                mask_url = self.upload_image(mask_data)
                if not mask_url:
                    logger.error("Failed to upload mask image for AI Replace - mask is required")
                    retries += 1
                    # Пытаемся сменить ключ при ошибке
                    self.api_key = self.key_manager.switch_to_next_key()
                    if not self.api_key:
                        logger.error("No more API keys available")
                        return None
                    continue
                
                # Подготовка данных запроса
                data = {
                    "imageUrl": image_url,
                    "maskedImageUrl": mask_url,
                    "textPrompt": enhanced_prompt.strip()  # Используем улучшенный промпт с инструкциями сохранения лица
                }
                
                # Подготовка заголовков
                headers = {
                    "Content-Type": "application/json",
                    "x-api-key": self.api_key
                }
                
                # Отправка запроса к API Replace
                logger.info(f"Sending request to AI Replace API with data: {json.dumps(data)}")
                response = requests.post(self.replace_url, headers=headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                # Вывод подробной информации о запросе для отладки
                logger.info(f"Request URL: {self.replace_url}")
                logger.info(f"Request Headers: Content-Type и x-api-key (скрыт)")
                logger.info(f"Request Data: {data}")
                logger.info(f"Response status code: {response.status_code}")
                
                # Проверка статуса ответа
                if response.status_code != 200:
                    # Проверка на ошибку исчерпания кредитов API
                    if "API_CREDITS_CONSUMED" in response.text:
                        logger.error(f"API credits consumed for key {self.api_key[:8]}...")
                        # Помечаем ключ как исчерпавший кредиты (блокируем на длительное время)
                        self.key_manager.mark_request_error(403, self.api_key)  # Используем код 403 для долгой блокировки
                        # Переключаемся на другой ключ
                        self.api_key = self.key_manager.switch_to_next_key()
                        if self.api_key:
                            logger.info(f"Switching to next key: {self.api_key[:8]}...")
                            retries += 1
                            continue
                        else:
                            logger.error("No more API keys available")
                            return None
                    
                    # Если ключ нужно заменить по другим причинам
                    if needs_key_switch:
                        logger.warning(f"Смена API ключа из-за ошибки {response.status_code}")
                        self.api_key = new_key
                        retries += 1
                        continue
                        
                    logger.error(f"Failed to request AI Replace: {response.status_code} - {response.text}")
                    retries += 1
                    continue
                
                # Анализ ответа
                result = response.json()
                logger.info(f"AI Replace API response status: {result.get('statusCode')}")
                
                if result.get("statusCode") != 2000 or "body" not in result:
                    # Проверка на ошибку исчерпания кредитов API в JSON ответе
                    if "API_CREDITS_CONSUMED" in str(result):
                        logger.error(f"API credits consumed for key {self.api_key[:8]}... (from JSON response)")
                        # Помечаем ключ как исчерпавший кредиты
                        self.key_manager.mark_request_error(403, self.api_key)  # Используем код 403 для долгой блокировки
                        # Переключаемся на другой ключ
                        self.api_key = self.key_manager.switch_to_next_key()
                        if self.api_key:
                            logger.info(f"Switching to next key: {self.api_key[:8]}...")
                            retries += 1
                            continue
                        else:
                            logger.error("No more API keys available")
                            return None
                    
                    logger.error(f"Invalid response from AI Replace API: {result}")
                    retries += 1
                    continue
                
                # Получение идентификатора заказа
                order_id = result["body"].get("orderId")
                if not order_id:
                    logger.error("Missing order ID in AI Replace API response")
                    retries += 1
                    continue
                
                logger.info(f"AI Replace order created with ID: {order_id}")
                
                # Ожидание результата обработки
                output_url = self.wait_for_result(order_id, max_retries=10, retry_interval=2)
                if not output_url:
                    logger.error(f"Failed to get result for order {order_id}")
                    retries += 1
                    continue
                
                # Загрузка обработанного изображения
                logger.info(f"Downloading result image from: {output_url}")
                download_response = requests.get(output_url)
                
                if download_response.status_code != 200:
                    logger.error(f"Failed to download AI Replace result: {download_response.status_code}")
                    retries += 1
                    continue
                
                logger.info(f"Successfully completed AI Replace, result size: {len(download_response.content)} bytes")
                return download_response.content
                
            except Exception as e:
                logger.error(f"Error in AI Replace (attempt {retries+1}/{max_retries+1}): {e}")
                import traceback
                logger.error(traceback.format_exc())
                retries += 1
                
                # Пытаемся сменить ключ при ошибке
                if retries <= max_retries:
                    self.api_key = self.key_manager.switch_to_next_key()
                    if not self.api_key:
                        logger.error("Failed to get next API key")
                        return None
                        
                    logger.info(f"Switching to next key after error: {self.api_key[:8]}...")
                    
        # Если все попытки исчерпаны
        logger.error(f"All {max_retries+1} attempts failed in ai_replace")
        return None
            
    def change_emotions(self, image_data, emotion):
        """
        Изменяет выражение лица на фотографии
        
        Args:
            image_data (bytes): Исходная фотография
            emotion (str): Название эмоции (smile, sad, angry, etc.)
            
        Returns:
            bytes: Фотография с измененной эмоцией или None, если ошибка
        """
        try:
            # Переводим название эмоции с русского на английский
            original_emotion = emotion
            translated_emotion = self.translate_with_deepl(emotion)
            logger.info(f"Translated emotion: '{original_emotion}' -> '{translated_emotion}'")
            
            # Загружаем изображение
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload image for emotion change")
                return None
                
            # Создаем запрос для изменения эмоций
            data = {
                "imageUrl": image_url,
                "emotion": translated_emotion
            }
            
            # Проверяем заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            # Отправляем запрос
            logger.info(f"Requesting emotion change to: {emotion}")
            response = requests.post(self.emotion_url, headers=headers, json=data)
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request emotion change: {response.status_code} - {response.text}")
                return None
                
            # Анализируем ответ
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from emotion transfer API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            # Ждем результат
            output_url = self.wait_for_result(order_id)
            if not output_url:
                return None
                
            # Загружаем результат
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download image with changed emotion: {response.status_code}")
                return None
                
            return response.content
            
        except Exception as e:
            logger.error(f"Error changing emotion: {e}")
            return None
            
    def generate_image_from_text_v2(self, prompt, image_data=None, max_retries=3):
        """
        Генерирует изображение по текстовому описанию (альтернативная версия)
        
        Args:
            prompt (str): Текстовое описание для генерации
            image_data (bytes, optional): Опорное изображение или None
            max_retries (int): Максимальное количество попыток с разными ключами
            
        Returns:
            bytes: Сгенерированное изображение или None, если ошибка
        """
        retries = 0
        while retries <= max_retries:
            try:
                # Проверяем текущий ключ и обновляем заголовки
                current_key = self.key_manager.get_current_key()
                if current_key != self.api_key:
                    self.api_key = current_key
                    # Безопасное отображение ключа для логов
                    key_display = self.api_key[:8] + "..." if self.api_key and len(self.api_key) > 8 else str(self.api_key)
                    logger.info(f"Обновлен API ключ для генерации изображения: {key_display}")
                
                # Проверка наличия API ключа LightX перед отправкой запроса
                if not self.api_key:
                    logger.error("CRITICAL ERROR: API ключ LightX недоступен!")
                    # Пытаемся получить следующий ключ
                    next_key = self.key_manager.switch_to_next_key()
                    if next_key:
                        self.api_key = next_key
                        logger.info(f"Переключение на следующий ключ (попытка {retries+1}/{max_retries+1})")
                        retries += 1
                        continue
                    return None
                
                # Переводим текстовый запрос с русского на английский
                original_prompt = prompt
                translated_prompt = self.translate_with_deepl(prompt)
                logger.info(f"Translated text generation prompt: '{original_prompt}' -> '{translated_prompt}'")
                
                # Добавляем инструкции для качественного результата
                quality_instructions = "high quality, photorealistic, detailed texture, 4k resolution, perfect lighting"
                
                # Если запрос содержит фразы о человеке, добавляем инструкции для лица
                if any(word in original_prompt.lower() for word in ["человек", "портрет", "лицо"]) or \
                any(word in translated_prompt.lower() for word in ["person", "portrait", "face"]):
                    face_instructions = "natural facial features, realistic face proportions, professional portrait quality"
                    enhanced_prompt = f"{translated_prompt}, {face_instructions}, {quality_instructions}"
                else:
                    enhanced_prompt = f"{translated_prompt}, {quality_instructions}"
                
                # Создаем запрос для генерации по тексту с улучшенным промптом
                data = {
                    "textPrompt": enhanced_prompt,
                    "negativePrompt": "low quality, blurry, distorted, bad anatomy, disfigured, ugly",
                    "steps": 30,
                    "width": 768,
                    "height": 768
                }
                
                # Добавляем опорное изображение, если оно предоставлено
                if image_data:
                    # Загружаем изображение
                    logger.info(f"Uploading reference image for text-to-image generation (попытка {retries+1}/{max_retries+1})")
                    image_url = self.upload_image(image_data)
                    if not image_url:
                        logger.error("Failed to upload reference image")
                        # Пытаемся сменить ключ при ошибке
                        next_key = self.key_manager.switch_to_next_key()
                        if next_key:
                            self.api_key = next_key
                            logger.info(f"Switching to next key: {self.api_key[:8]}...")
                            retries += 1
                            continue
                        return None
                    
                    data["referenceImageUrl"] = image_url
                    data["referenceWeight"] = 0.5
                    logger.info(f"Reference image uploaded successfully: {image_url}")
                
                # Проверяем заголовки для аутентификации
                headers = {
                    "Content-Type": "application/json",
                    "x-api-key": self.api_key
                }
                
                # Отправляем запрос
                logger.info(f"Requesting text-to-image generation with prompt: {prompt} (попытка {retries+1}/{max_retries+1})")
                logger.info(f"Enhanced prompt: {enhanced_prompt}")
                response = requests.post(self.text2image_url, headers=headers, json=data)
                
                # Обработка ответа через менеджер ключей
                needs_key_switch, new_key = self.key_manager.handle_response(response)
                
                # Проверяем ответ
                if response.status_code != 200:
                    # Проверка на ошибку исчерпания кредитов API
                    if "API_CREDITS_CONSUMED" in response.text:
                        logger.error(f"API credits consumed for key {self.api_key[:8]}...")
                        # Помечаем ключ как исчерпавший кредиты (блокируем на длительное время)
                        self.key_manager.mark_request_error(403, self.api_key)  # Используем код 403 для долгой блокировки
                        # Переключаемся на другой ключ
                        next_key = self.key_manager.switch_to_next_key()
                        if next_key:
                            self.api_key = next_key
                            logger.info(f"Switching to next key: {self.api_key[:8]}...")
                            retries += 1
                            continue
                        return None
                    
                    # Если ключ нужно заменить по другим причинам
                    if needs_key_switch:
                        logger.warning(f"Смена API ключа из-за ошибки {response.status_code}")
                        self.api_key = new_key
                        retries += 1
                        continue
                    
                    logger.error(f"Failed to request text-to-image generation: {response.status_code} - {response.text}")
                    retries += 1
                    continue
                
                # Анализируем ответ
                result = response.json()
                if result.get("statusCode") != 2000 or "body" not in result:
                    # Проверка на ошибку исчерпания кредитов API в JSON ответе
                    if "API_CREDITS_CONSUMED" in str(result):
                        logger.error(f"API credits consumed for key {self.api_key[:8]}... (from JSON response)")
                        # Помечаем ключ как исчерпавший кредиты (блокируем на длительное время)
                        self.key_manager.mark_request_error(403, self.api_key)  
                        # Переключаемся на другой ключ
                        next_key = self.key_manager.switch_to_next_key()
                        if next_key:
                            self.api_key = next_key
                            logger.info(f"Switching to next key: {self.api_key[:8]}...")
                            retries += 1
                            continue
                        return None
                    
                    logger.error(f"Invalid response from text-to-image API: {result}")
                    retries += 1
                    continue
                
                # Получаем ID заказа
                order_id = result["body"].get("orderId")
                if not order_id:
                    logger.error("Missing order ID in response")
                    retries += 1
                    continue
                
                logger.info(f"Text-to-image order created with ID: {order_id}")
                
                # Ждем результат обработки
                output_url = self.wait_for_result(order_id, max_retries=15, retry_interval=2)
                if not output_url:
                    logger.error(f"Failed to get result for order {order_id}")
                    retries += 1
                    continue
                
                # Загружаем результат
                logger.info(f"Downloading result from: {output_url}")
                download_response = requests.get(output_url)
                
                if download_response.status_code != 200:
                    logger.error(f"Failed to download generated image: {download_response.status_code}")
                    retries += 1
                    continue
                
                logger.info(f"Text-to-image generation successful. Result size: {len(download_response.content)} bytes")
                return download_response.content
                
            except Exception as e:
                logger.error(f"Error in generate_image_from_text_v2 (attempt {retries+1}/{max_retries+1}): {e}")
                logger.error(traceback.format_exc())  # Выводим полный стек вызовов
                retries += 1
                
                # Пытаемся сменить ключ при ошибке
                if retries <= max_retries:
                    next_key = self.key_manager.switch_to_next_key()
                    if next_key:
                        self.api_key = next_key
                        logger.info(f"Switching to next key after error: {self.api_key[:8]}...")
                        continue
                
                return None
        
        # Если все попытки исчерпаны
        logger.error(f"All {max_retries+1} attempts failed in generate_image_from_text_v2")
        return None