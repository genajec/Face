import os
import sys
from dotenv import load_dotenv
from flask import Flask, redirect, url_for

# Загружаем переменные окружения из .env файла
load_dotenv()

from flask import Flask
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_login import LoginManager
from db import db

# create the app
app = Flask(__name__, 
            static_folder='static',
            template_folder='templates')

# Устанавливаем секретные ключи для сессий и CSRF
# Устанавливаем секретный ключ напрямую, чтобы избежать проблем с сессиями
app.config['SECRET_KEY'] = "faceform_secure_secret_key_for_production_environment"
app.secret_key = "faceform_secure_secret_key_for_production_environment"

# Логируем для отладки
print(f"App Secret Key установлен напрямую: {app.secret_key[:10]}...", file=sys.stderr)

# Настройка кодировки для JSON
app.config['JSON_AS_ASCII'] = False

print(f"App Secret Key: {app.secret_key}", file=sys.stderr)

# Настройки сессии для улучшения сохранения авторизации
from flask_session import Session

app.config['SESSION_TYPE'] = 'filesystem'
app.config['PERMANENT_SESSION_LIFETIME'] = 60 * 60 * 24 * 30  # 30 дней
app.config['SESSION_PERMANENT'] = True
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_FILE_DIR'] = os.path.join(os.getcwd(), 'flask_session')  # Директория для хранения сессий
app.config['SESSION_FILE_THRESHOLD'] = 500  # Максимальное количество сессий
app.config['SESSION_KEY_PREFIX'] = 'faceform_'  # Префикс для ключей сессии
app.config['SESSION_COOKIE_SECURE'] = True  # Только HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True  # Недоступен для JavaScript
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'  # Защита от CSRF
app.config['REMEMBER_COOKIE_DURATION'] = 60 * 60 * 24 * 30  # 30 дней для "запомнить меня"
app.config['REMEMBER_COOKIE_SECURE'] = True
app.config['REMEMBER_COOKIE_HTTPONLY'] = True
app.config['REMEMBER_COOKIE_SAMESITE'] = 'Lax'

# Инициализация Flask-Session
sess = Session(app)

# Подключаем SessionMiddleware для лучшей работы с сессиями
from session_middleware import SessionMiddleware
session_middleware = SessionMiddleware(app)

# Устанавливаем настройки для Flask-WTF
app.config['WTF_CSRF_ENABLED'] = True 
app.config['WTF_CSRF_SECRET_KEY'] = app.config['SECRET_KEY']
app.config['WTF_CSRF_TIME_LIMIT'] = 3600  # 1 час вместо 30 минут по умолчанию

# Прокси-фикс для корректных URL (учитывает, что запросы идут через SSL-терминирующий прокси)
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1, x_prefix=1)

# Добавим заголовки безопасности
@app.after_request
def add_security_headers(response):
    # Защита от кликджекинга
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    # Защита от XSS атак
    response.headers['X-XSS-Protection'] = '1; mode=block'
    # Запрет на определение типа контента браузером
    response.headers['X-Content-Type-Options'] = 'nosniff'
    # Усиленная защита от CSRF
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://code.jquery.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: https:; font-src 'self' https://cdn.jsdelivr.net data:;"
    # Использовать только HTTPS
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response

# configure the database
database_url = os.environ.get("DATABASE_URL")
if not database_url:
    print("DATABASE_URL переменная окружения не установлена, но мы создали новую БД.", file=sys.stderr)
    # Используем автоматически созданную базу данных PostgreSQL
    # Собираем строку подключения из отдельных переменных
    pguser = os.environ.get("PGUSER")
    pgpassword = os.environ.get("PGPASSWORD")
    pghost = os.environ.get("PGHOST")
    pgport = os.environ.get("PGPORT")
    pgdatabase = os.environ.get("PGDATABASE")
    
    if pguser and pgpassword and pghost and pgport and pgdatabase:
        database_url = f"postgresql://{pguser}:{pgpassword}@{pghost}:{pgport}/{pgdatabase}"
        print(f"База данных создана с использованием отдельных переменных PG*", file=sys.stderr)
    
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
print(f"SQLALCHEMY_DATABASE_URI: {database_url}", file=sys.stderr)

app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Настройки для Stripe
# Получаем ключи из переменных окружения
stripe_public_key = os.environ.get("STRIPE_PUBLIC_KEY")
stripe_secret_key = os.environ.get("STRIPE_SECRET_KEY")
stripe_test_public_key = os.environ.get("STRIPE_TEST_PUBLIC_KEY", stripe_public_key)
stripe_test_secret_key = os.environ.get("STRIPE_TEST_SECRET_KEY", stripe_secret_key)

# Логируем статус загрузки ключей (только показываем, загружен ли ключ, не выводя сам ключ)
print(f"STRIPE_PUBLIC_KEY: {'Loaded' if stripe_public_key else 'Not loaded'}", file=sys.stderr)
print(f"STRIPE_SECRET_KEY: {'Loaded' if stripe_secret_key else 'Not loaded'}", file=sys.stderr)

# Если ключи не загружены из переменных окружения, устанавливаем их явно из .env файла
if not stripe_public_key:
    stripe_public_key = "pk_test_51RFWPbIXP9qWqMx9jUPze8X6mvkTwL0yi1qwkENB3c3cgxfq7dgqDG9NW367wz9q9I8u96IbjfVC6Mb1N1g3m3LT00j8y2YL84"
    stripe_test_public_key = stripe_public_key
    print(f"STRIPE_PUBLIC_KEY установлен явно: {stripe_public_key[:8]}...", file=sys.stderr)

if not stripe_secret_key:
    stripe_secret_key = "sk_test_51RFWPbIXP9qWqMx9w2YoZngd6scIJLNeq5iA430UStr6z5LYbkSjpDKdhhwkWuQvKBmfzDttXRgjQXNL81vmngnV00Onnf0Xxr"
    stripe_test_secret_key = stripe_secret_key
    print(f"STRIPE_SECRET_KEY установлен явно: {stripe_secret_key[:8]}...", file=sys.stderr)

app.config["STRIPE_PUBLIC_KEY"] = stripe_public_key
app.config["STRIPE_SECRET_KEY"] = stripe_secret_key
app.config["STRIPE_TEST_PUBLIC_KEY"] = stripe_test_public_key
app.config["STRIPE_TEST_SECRET_KEY"] = stripe_test_secret_key

# initialize the app with the extension
db.init_app(app)

# Настройка Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'

# Загрузка конфигураций из config.py
try:
    from config import PREMIUM_MESSAGES, FACE_SHAPE_CRITERIA, HAIRSTYLE_RECOMMENDATIONS
except ImportError:
    PREMIUM_MESSAGES = {}
    FACE_SHAPE_CRITERIA = {}
    HAIRSTYLE_RECOMMENDATIONS = {}

# Импортируем модели
import models

with app.app_context():
    # Проверяем, существуют ли таблицы, перед созданием
    from sqlalchemy import inspect
    inspector = inspect(db.engine)
    
    # Проверяем существование всех необходимых таблиц
    needed_tables = ['user', 'credit', 'transaction']
    existing_tables = inspector.get_table_names()
    
    # Логируем существующие таблицы
    print(f"Существующие таблицы: {existing_tables}", file=sys.stderr)
    
    # Создаем только те таблицы, которых еще нет
    db.create_all()
    
# Регистрация Blueprints
from auth import auth as auth_blueprint
app.register_blueprint(auth_blueprint, url_prefix='/auth')

from routes.face_analysis import face_analysis as face_analysis_blueprint
app.register_blueprint(face_analysis_blueprint)

# Импортируем остальные blueprints
from payments import payments as payments_blueprint
app.register_blueprint(payments_blueprint, url_prefix='/payments', name='payments_main')

from routes.api import api_bp as api_blueprint
app.register_blueprint(api_blueprint)

# Импортируем и регистрируем Google Auth blueprint
try:
    from google_auth import google_auth as google_auth_blueprint
    app.register_blueprint(google_auth_blueprint)
    print("Google Auth blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Google Auth blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Google Auth blueprint: {str(e)}", file=sys.stderr)

# Регистрируем blueprint для расширенных функций
try:
    from routes.advanced_features import advanced_features as advanced_features_blueprint
    app.register_blueprint(advanced_features_blueprint, name='advanced_features_main')
    print("Advanced Features blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Advanced Features blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Advanced Features blueprint: {str(e)}", file=sys.stderr)

# Основной blueprint для страниц будет импортирован из main.py

# Импортируем модуль для локализации
from translations import translator, t

# Добавляем контекстный процессор для локализации
@app.context_processor
def inject_globals():
    """
    Глобальный контекстный процессор для передачи переменных в шаблоны.
    Добавляет функцию t() для локализации и текущий язык.
    """
    return {
        't': t,
        'current_lang': translator.get_current_lang(),
        'available_languages': translator.get_languages()
    }

# Регистрируем blueprint для переключения языка
try:
    from routes.language import language as language_blueprint
    app.register_blueprint(language_blueprint, url_prefix='/language')
    print("Language blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Language blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Language blueprint: {str(e)}", file=sys.stderr)

# Регистрируем blueprint для скачивания архивов
try:
    from routes.download import download_bp
    app.register_blueprint(download_bp)
    print("Download blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download blueprint: {str(e)}", file=sys.stderr)

# Регистрируем blueprint для страницы загрузки файлов проекта
try:
    from routes.faceform_download import download_page_bp
    app.register_blueprint(download_page_bp)
    print("Download Page blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download Page blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download Page blueprint: {str(e)}", file=sys.stderr)

# Регистрируем blueprint для скачивания основных файлов
try:
    from routes.download_essential import download_essential_bp
    app.register_blueprint(download_essential_bp)
    print("Download Essential blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download Essential blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download Essential blueprint: {str(e)}", file=sys.stderr)

# Регистрируем blueprint для скачивания отдельных файлов
try:
    from routes.download_file import download_file_bp
    app.register_blueprint(download_file_bp)
    print("Download File blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download File blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download File blueprint: {str(e)}", file=sys.stderr)
    
# Регистрируем blueprint для просмотра и скачивания всех файлов проекта
try:
    from routes.download_files import download_files_bp
    app.register_blueprint(download_files_bp, name='download_files_browser')
    print("Download Files browser blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download Files browser blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download Files browser blueprint: {str(e)}", file=sys.stderr)
    
# Регистрируем blueprint для скачивания всех файлов сразу
try:
    from routes.download_all_files import download_all_files_bp
    app.register_blueprint(download_all_files_bp)
    print("Download All Files blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download All Files blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download All Files blueprint: {str(e)}", file=sys.stderr)
    
# Регистрируем blueprint для генерации скрипта скачивания
try:
    from routes.generate_download_script import generate_script_bp
    app.register_blueprint(generate_script_bp)
    print("Generate Download Script blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Generate Download Script blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Generate Download Script blueprint: {str(e)}", file=sys.stderr)

# Регистрируем blueprint платежей и расширенных функций уже выполнена выше
# Закомментировано для избежания двойной регистрации
"""
try:
    from routes.payments import payments_bp
    app.register_blueprint(payments_bp)
    print("Blueprint 'payments' уже зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Blueprint 'payments': {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Blueprint 'payments': {str(e)}", file=sys.stderr)

# Регистрируем blueprint для дополнительных функций
try:
    from routes.advanced_features import advanced_features_bp
    app.register_blueprint(advanced_features_bp)
    print("Blueprint 'advanced_features' уже зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Blueprint 'advanced_features': {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Blueprint 'advanced_features': {str(e)}", file=sys.stderr)
"""

# Регистрируем blueprint для прямого скачивания файлов (с уникальным именем)
try:
    from download_files import download_files_bp as download_files_direct_bp
    app.register_blueprint(download_files_direct_bp, name='download_files_direct')
    print("Download Files Direct blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download Files Direct blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download Files Direct blueprint: {str(e)}", file=sys.stderr)

# Регистрация Download Deploy blueprint (с уникальным именем)
try:
    from download_deploy import download_deploy_bp
    app.register_blueprint(download_deploy_bp, name='download_deploy_direct')
    print("Download Deploy blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download Deploy blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download Deploy blueprint: {str(e)}", file=sys.stderr)

# Регистрация Download Full VPS blueprint для полного архива
try:
    from routes.download_full_vps import download_full_vps_bp
    app.register_blueprint(download_full_vps_bp)
    print("Download Full VPS blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Download Full VPS blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download Full VPS blueprint: {str(e)}", file=sys.stderr)

# Регистрация Direct Download blueprint для прямого скачивания установочных файлов
try:
    from routes.direct_download import direct_download_bp
    app.register_blueprint(direct_download_bp)
    print("Direct Download blueprint успешно зарегистрирован", file=sys.stderr)
except ImportError as e:
    print(f"Не удалось импортировать Direct Download blueprint: {str(e)}", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Direct Download blueprint: {str(e)}", file=sys.stderr)