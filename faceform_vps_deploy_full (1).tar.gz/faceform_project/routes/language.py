from flask import Blueprint, redirect, request, url_for, session
from translations import translator

language = Blueprint('language', __name__)

@language.route('/change-language/<lang_code>')
def change_language(lang_code):
    """
    Изменяет текущий язык и перенаправляет на предыдущую страницу.
    
    Args:
        lang_code (str): Код языка ('ru', 'en', и т.д.)
    
    Returns:
        Response: Перенаправление на предыдущую страницу или на главную
    """
    # Устанавливаем язык, если он доступен
    translator.set_lang(lang_code)
    
    # Получаем URL, с которого пришел запрос
    referrer = request.referrer
    
    # Если referer есть и это URL нашего сайта, возвращаемся на эту страницу
    if referrer:
        return redirect(referrer)
    
    # Иначе перенаправляем на главную
    return redirect(url_for('main.index'))