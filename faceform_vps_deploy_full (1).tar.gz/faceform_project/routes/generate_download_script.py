import os
from flask import Blueprint, render_template, current_app, send_file, make_response
import io
import urllib.parse

generate_script_bp = Blueprint('generate_script', __name__)

@generate_script_bp.route('/generate_download_script')
def generate_download_script():
    """
    Генерирует bash-скрипт для скачивания всех файлов проекта
    с сохранением структуры директорий
    """
    # Получаем корневую директорию проекта
    project_root = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    
    # Исключаем определенные директории
    excluded_dirs = [
        '__pycache__', 
        '.git', 
        '.config', 
        '.replit', 
        'venv', 
        '.venv', 
        'node_modules', 
        'tmp', 
        'faceform_archives', 
        'flask_session',
        'attached_assets',
        'extracted_analyzer',
        'extracted_frames',
        'frames'
    ]
    
    # Исключаем определенные расширения файлов
    excluded_extensions = [
        '.pyc', 
        '.pyo', 
        '.pyd', 
        '.git',
        '.env',
        '.tar.gz',
        '.zip'
    ]
    
    # Скрипт для создания директорий и скачивания файлов
    script_lines = [
        '#!/bin/bash',
        '# Скрипт для скачивания всех файлов проекта с сохранением структуры директорий',
        '',
        '# Создаем директорию для проекта',
        'mkdir -p faceform_project',
        'cd faceform_project',
        ''
    ]
    
    # Базовый URL приложения
    base_url = "https://80fef676-87ec-4689-8029-081606e2dedf-00-1s6n0ujkkb87q.kirk.replit.dev"
    
    # Собираем файлы и директории рекурсивно
    file_count = 0
    for root, dirs, files in os.walk(project_root):
        # Исключаем нежелательные директории
        dirs[:] = [d for d in dirs if d not in excluded_dirs and not d.startswith('.')]
        
        for file in files:
            # Пропускаем файлы с нежелательными расширениями
            if any(file.endswith(ext) for ext in excluded_extensions) or file.startswith('.'):
                continue
            
            file_path = os.path.join(root, file)
            rel_path = os.path.relpath(file_path, project_root)
            
            # Создаём директорию для файла, если она не существует
            dir_path = os.path.dirname(rel_path)
            if dir_path:
                script_lines.append(f'mkdir -p "{dir_path}"')
            
            # URL для скачивания файла
            encoded_path = urllib.parse.quote(rel_path)
            download_url = f"{base_url}/download_individual_file/{encoded_path}"
            
            # Добавляем команду для скачивания файла
            script_lines.append(f'wget -q -O "{rel_path}" "{download_url}" || echo "Failed to download {rel_path}"')
            
            file_count += 1
    
    # Добавляем информацию об окончании скачивания
    script_lines.append('')
    script_lines.append('echo "Скачивание завершено. Всего скачано файлов: ' + str(file_count) + '"')
    script_lines.append('cd ..')
    
    # Создаем скрипт в памяти
    script_content = '\n'.join(script_lines)
    
    # Создаем файл в памяти
    mem_file = io.BytesIO()
    mem_file.write(script_content.encode('utf-8'))
    mem_file.seek(0)
    
    # Отправляем скрипт пользователю
    response = make_response(send_file(
        mem_file,
        mimetype='text/plain',
        as_attachment=True,
        download_name='download_faceform.sh'
    ))
    
    # Устанавливаем HTTP-заголовки для корректного скачивания
    response.headers['Content-Disposition'] = 'attachment; filename=download_faceform.sh'
    
    return response

@generate_script_bp.route('/download_individual_file/<path:file_path>')
def download_individual_file(file_path):
    """
    Маршрут для скачивания отдельного файла
    
    Args:
        file_path (str): Относительный путь к файлу
    """
    try:
        # Получаем корневую директорию проекта
        project_root = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        
        # Полный путь к файлу
        full_path = os.path.join(project_root, file_path)
        
        # Проверяем, существует ли файл
        if not os.path.isfile(full_path):
            return f"Файл не найден: {file_path}", 404
        
        # Отправляем файл пользователю
        return send_file(full_path, as_attachment=True)
    
    except Exception as e:
        return f"Ошибка при скачивании файла: {str(e)}", 500