"""
Маршрут для скачивания полного архива проекта для VPS
"""
import os
import tempfile
import tarfile
import shutil
from flask import Blueprint, send_file, current_app, render_template
import subprocess

download_full_vps_bp = Blueprint('download_full_vps', __name__)

@download_full_vps_bp.route('/download/vps')
def download_vps_page():
    """
    Страница для скачивания архива проекта для VPS
    """
    return render_template('download_vps.html')

@download_full_vps_bp.route('/download/archive')
def download_archive_page():
    """
    Новая страница для прямого скачивания архива проекта для VPS
    """
    return render_template('download_archive.html')

@download_full_vps_bp.route('/download/full_vps_archive')
@download_full_vps_bp.route('/download/vps/archive')
def download_full_vps_archive():
    """
    Маршрут для скачивания полного архива проекта для VPS
    """
    base_dir = os.getcwd()
    archive_path = os.path.join(tempfile.gettempdir(), 'faceform_vps_deploy_full.tar.gz')
    
    # Всегда создаём новый архив
    if os.path.exists(archive_path):
        os.remove(archive_path)
    
    # Создаем архив
    temp_dir = tempfile.mkdtemp()
    try:
        print(f"Создание полного архива проекта для VPS в {archive_path}")
        
        # Копируем установочные скрипты напрямую в корень архива
        
        # Копируем/создаем установочный скрипт
        setup_script_content = '''#!/bin/bash
#
# Скрипт установки FaceForm на VPS Ubuntu
# Домен: faceform.vps.webdock.cloud
# IP: 92.113.145.171
#

set -e

# Цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Конфигурация
APP_NAME="faceform"
APP_USER="faceform"
APP_DIR="/home/$APP_USER/faceform_app"
DOMAIN="faceform.vps.webdock.cloud"
IP_ADDRESS="92.113.145.171"

# Текущая директория
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Функции
echo_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

echo_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

echo_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Проверка системы
echo_status "Проверка системы..."
if ! command -v python3 &> /dev/null; then
    echo_warning "Python 3 не установлен"
    if [ "$(whoami)" == "root" ]; then
        echo_status "Установка Python 3..."
        apt-get update && apt-get install -y python3 python3-pip python3-venv
    else
        echo_warning "Для установки Python 3 требуются права суперпользователя"
        echo_warning "Выполните: sudo apt-get update && sudo apt-get install -y python3 python3-pip python3-venv"
        exit 1
    fi
fi

# Создание директорий
echo_status "Создание директорий..."
mkdir -p "$APP_DIR"
mkdir -p "$APP_DIR/logs"
mkdir -p "$APP_DIR/flask_session"
mkdir -p "$APP_DIR/uploads"
mkdir -p "$APP_DIR/static"
mkdir -p "$APP_DIR/templates"

# Копирование файлов проекта
echo_status "Копирование файлов проекта..."
if [ "$SCRIPT_DIR" != "$APP_DIR" ]; then
    cp -r "$SCRIPT_DIR/faceform_project/"* "$APP_DIR/"
    echo_status "Файлы скопированы в $APP_DIR"
fi

# Создание виртуального окружения
echo_status "Создание виртуального окружения..."
cd "$APP_DIR"
python3 -m venv venv
source venv/bin/activate

# Установка зависимостей
echo_status "Установка зависимостей..."
pip install --upgrade pip
pip install -r requirements.txt
pip install gunicorn psycopg2-binary

# Проверка наличия PostgreSQL
if ! command -v psql &> /dev/null; then
    echo_warning "PostgreSQL не установлен"
    if [ "$(whoami)" == "root" ]; then
        echo_status "Установка PostgreSQL..."
        apt-get update && apt-get install -y postgresql postgresql-contrib libpq-dev
        systemctl enable postgresql
        systemctl start postgresql
    else
        echo_warning "Для установки PostgreSQL требуются права суперпользователя"
        echo_warning "Выполните: sudo apt-get update && sudo apt-get install -y postgresql postgresql-contrib libpq-dev"
        echo_warning "sudo systemctl enable postgresql && sudo systemctl start postgresql"
    fi
fi

# Создание файла .env
echo_status "Создание файла .env..."
if [ -f "$APP_DIR/.env.example" ]; then
    cp "$APP_DIR/.env.example" "$APP_DIR/.env"
else
    cat > "$APP_DIR/.env" << EOF
# Основные настройки
FLASK_ENV=production
FLASK_DEBUG=0
FLASK_SECRET_KEY=faceform_secure_secret_key_for_production_environment
SESSION_SECRET=faceform_secure_session_secret

# Настройки базы данных
DATABASE_URL=postgresql://faceform:faceform_password@localhost/faceform

# API ключи LightX
LIGHTX_API_KEYS=af1fde54...,d4bd48c9...,4d2c3274...,a271d490...,eeee6d2b...

# Домен и порты
HOST=$DOMAIN
PORT=5000
EOF
fi

# Настройка базы данных PostgreSQL
if [ "$(whoami)" == "root" ]; then
    echo_status "Настройка базы данных PostgreSQL..."
    su - postgres -c "psql -c \"CREATE USER faceform WITH PASSWORD 'faceform_password';\""
    su - postgres -c "psql -c \"CREATE DATABASE faceform OWNER faceform;\""
    echo_status "База данных PostgreSQL настроена"
else
    echo_warning "Для настройки PostgreSQL требуются права суперпользователя"
    echo_warning "Выполните следующие команды под пользователем postgres:"
    echo_warning "sudo -u postgres psql -c \"CREATE USER faceform WITH PASSWORD 'faceform_password';\""
    echo_warning "sudo -u postgres psql -c \"CREATE DATABASE faceform OWNER faceform';\""
fi

# Настройка Gunicorn
echo_status "Настройка Gunicorn..."
cat > "$APP_DIR/gunicorn_config.py" << EOF
bind = "0.0.0.0:5000"
workers = 4
timeout = 120
accesslog = "logs/access.log"
errorlog = "logs/error.log"
capture_output = True
EOF

# Создание скрипта запуска
echo_status "Создание скрипта запуска..."
cat > "$APP_DIR/start.sh" << EOF
#!/bin/bash
cd "$APP_DIR"
source venv/bin/activate
export FLASK_APP=main.py
export FLASK_ENV=production
gunicorn --config gunicorn_config.py main:app
EOF
chmod +x "$APP_DIR/start.sh"

# Создание службы systemd
if [ "$(whoami)" == "root" ]; then
    echo_status "Создание службы systemd..."
    cat > /etc/systemd/system/faceform.service << EOF
[Unit]
Description=FaceForm Application
After=network.target postgresql.service

[Service]
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin"
ExecStart=$APP_DIR/start.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable faceform
    systemctl start faceform
    echo_status "Служба systemd настроена и запущена"
else
    echo_warning "Для создания службы systemd требуются права суперпользователя"
    echo_warning "Создайте файл systemd вручную после установки с привилегиями root"
fi

# Настройка Nginx
if [ "$(whoami)" == "root" ]; then
    echo_status "Настройка Nginx..."
    if ! command -v nginx &> /dev/null; then
        echo_status "Установка Nginx..."
        apt-get update && apt-get install -y nginx
    fi

    cat > /etc/nginx/sites-available/faceform << EOF
server {
    listen 80;
    server_name $DOMAIN $IP_ADDRESS;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_buffering off;
        client_max_body_size 100M;
    }

    location /static {
        alias $APP_DIR/static;
        expires 30d;
    }

    location /uploads {
        alias $APP_DIR/uploads;
        expires 30d;
    }

    error_log /var/log/nginx/faceform.error.log;
    access_log /var/log/nginx/faceform.access.log;
}
EOF

    ln -sf /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/
    systemctl restart nginx
    echo_status "Nginx настроен"
else
    echo_warning "Для настройки Nginx требуются права суперпользователя"
    echo_warning "Настройте Nginx вручную после установки с привилегиями root"
fi

# Создание администратора
echo_status "Создание администратора..."
cd "$APP_DIR"
source venv/bin/activate
python create_admin.py --username admin --email admin@$DOMAIN --password faceform_admin2025

echo_status "Установка FaceForm завершена!"
echo_status "Сайт доступен по адресу: http://$DOMAIN и http://$IP_ADDRESS"
echo_status "Логин администратора: admin@$DOMAIN"
echo_status "Пароль администратора: faceform_admin2025"

# Если не root, показываем инструкции по запуску вручную
if [ "$(whoami)" != "root" ]; then
    echo_warning "Так как установка выполнена без прав суперпользователя, запустите приложение вручную:"
    echo_warning "cd $APP_DIR && ./start.sh"
    echo_warning "Приложение будет доступно по адресу: http://$IP_ADDRESS:5000"
fi
'''
        
        # Копируем создание администратора
        admin_script_content = '''"""
Скрипт для создания администратора в базе данных
"""
import os
import sys
import random
import string
from werkzeug.security import generate_password_hash
import psycopg2
from psycopg2 import sql

def generate_password(length=12):
    """
    Генерирует случайный пароль указанной длины
    
    Args:
        length (int): Длина пароля
        
    Returns:
        str: Сгенерированный пароль
    """
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(random.choice(chars) for _ in range(length))

def create_admin_user(db_url=None, email=None, username=None, password=None):
    """
    Создает администратора в базе данных
    
    Args:
        db_url (str, optional): URL базы данных
        email (str, optional): Email администратора
        username (str, optional): Имя пользователя администратора
        password (str, optional): Пароль администратора
        
    Returns:
        dict: Информация о созданном пользователе
    """
    # Используем переданные значения или значения по умолчанию
    db_url = db_url or os.environ.get('DATABASE_URL')
    email = email or 'admin@faceform.vps.webdock.cloud'
    username = username or 'admin'
    password = password or generate_password()
    
    if not db_url:
        print("ОШИБКА: Не указан URL базы данных", file=sys.stderr)
        return None
    
    try:
        # Подключаемся к базе данных
        conn = psycopg2.connect(db_url)
        cursor = conn.cursor()
        
        # Проверяем, существует ли пользователь с таким email или username
        cursor.execute("SELECT id FROM \"user\" WHERE email = %s OR username = %s", (email, username))
        existing_user = cursor.fetchone()
        
        if existing_user:
            # Обновляем существующего пользователя, делая его администратором
            cursor.execute(
                "UPDATE \"user\" SET is_admin = TRUE, password_hash = %s WHERE id = %s",
                (generate_password_hash(password), existing_user[0])
            )
            user_id = existing_user[0]
            print(f"Пользователь с id {user_id} обновлен и получил права администратора")
        else:
            # Создаем нового пользователя-администратора
            cursor.execute(
                """
                INSERT INTO \"user\" (username, email, password_hash, is_admin)
                VALUES (%s, %s, %s, TRUE)
                RETURNING id
                """,
                (username, email, generate_password_hash(password))
            )
            user_id = cursor.fetchone()[0]
            print(f"Создан новый пользователь-администратор с id {user_id}")
        
        # Проверяем, есть ли у пользователя кредиты, если нет - добавляем
        cursor.execute("SELECT id FROM credit WHERE user_id = %s", (user_id,))
        existing_credit = cursor.fetchone()
        
        if not existing_credit:
            cursor.execute(
                "INSERT INTO credit (user_id, amount) VALUES (%s, %s)",
                (user_id, 1000)  # Даем администратору 1000 кредитов
            )
            print(f"Добавлено 1000 кредитов пользователю с id {user_id}")
        else:
            # Обновляем количество кредитов
            cursor.execute(
                "UPDATE credit SET amount = 1000 WHERE user_id = %s",
                (user_id,)
            )
            print(f"Обновлено количество кредитов пользователя с id {user_id} до 1000")
        
        conn.commit()
        
        # Возвращаем информацию о пользователе
        return {
            'id': user_id,
            'username': username,
            'email': email,
            'password': password,
            'is_admin': True,
            'credits': 1000
        }
    
    except Exception as e:
        print(f"ОШИБКА при создании администратора: {str(e)}", file=sys.stderr)
        return None
    finally:
        if 'conn' in locals() and conn:
            conn.close()

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Создание администратора в базе данных')
    parser.add_argument('--db-url', help='URL базы данных')
    parser.add_argument('--email', help='Email администратора')
    parser.add_argument('--username', help='Имя пользователя администратора')
    parser.add_argument('--password', help='Пароль администратора')
    
    args = parser.parse_args()
    
    user_info = create_admin_user(
        db_url=args.db_url,
        email=args.email,
        username=args.username,
        password=args.password
    )
    
    if user_info:
        print("Администратор успешно создан/обновлен")
        print("======================================")
        print(f"ID: {user_info['id']}")
        print(f"Username: {user_info['username']}")
        print(f"Email: {user_info['email']}")
        print(f"Password: {user_info['password']}")
        print(f"Credits: {user_info['credits']}")
        print("======================================")
        print("Используйте эти данные для входа в систему!")
    else:
        print("Не удалось создать администратора", file=sys.stderr)
        sys.exit(1)
'''

        # Создаем директорию проекта
        project_dir = os.path.join(temp_dir, 'faceform_project')
        os.makedirs(project_dir, exist_ok=True)
        
        # Копируем только необходимые Python файлы для веб-приложения
        essential_files = [
            'main.py', 'app.py', 'db.py', 'auth.py', 'forms.py', 'models.py', 'config.py',
            'database.py', 'email_service.py', 'face_analyzer.py', 'face_attractiveness.py',
            'lightx_client.py', 'lightx_key_manager.py', 'fix_background_function.py',
            'hairstyle_recommender.py', 'hairstyle_overlay.py', 'deepl_translator.py',
            'create_admin.py'
        ]
        
        for filename in essential_files:
            src_path = os.path.join(base_dir, filename)
            if os.path.exists(src_path) and os.path.isfile(src_path):
                shutil.copy2(src_path, os.path.join(project_dir, filename))
        
        # Копируем важные файлы
        important_files = ['.env.example', 'requirements.txt', 'README.md', 'Procfile']
        for filename in important_files:
            src_path = os.path.join(base_dir, filename)
            if os.path.exists(src_path):
                shutil.copy2(src_path, os.path.join(project_dir, filename))
        
        # Копируем только нужные директории, исключаем всё остальное
        include_dirs = ['templates', 'static', 'routes', 'utils', 'translations', 'hairstyles']
        # Все остальные директории исключаем
        exclude_dirs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d)) and d not in include_dirs]
        
        for dirname in os.listdir(base_dir):
            src_dir = os.path.join(base_dir, dirname)
            if os.path.isdir(src_dir) and dirname not in exclude_dirs:
                dst_dir = os.path.join(project_dir, dirname)
                if not os.path.exists(dst_dir):
                    # Фильтруем большие файлы
                    ignore_patterns = ['__pycache__', '*.pyc', '*.pyo', '*.pyd', '*.so', '*.dylib', '*.log',
                                     '*.jpg', '*.jpeg', '*.png', '*.gif', '*.mp4', '*.avi', '*.zip', '*.tar.gz']
                    
                    # Пропускаем копирование, если директория слишком большая
                    total_size = 0
                    for dirpath, dirnames, filenames in os.walk(src_dir):
                        for f in filenames:
                            fp = os.path.join(dirpath, f)
                            if os.path.exists(fp):
                                total_size += os.path.getsize(fp)
                                
                    if total_size > 50 * 1024 * 1024:  # 50 MB
                        print(f"Пропускаем большую директорию: {dirname}")
                        continue
                        
                    shutil.copytree(src_dir, dst_dir, symlinks=False, 
                                  ignore=shutil.ignore_patterns(*ignore_patterns))
        
        # Создаем пустые директории
        empty_dirs = ['uploads', 'flask_session', 'logs']
        for dir_name in empty_dirs:
            dir_path = os.path.join(project_dir, dir_name)
            if not os.path.exists(dir_path):
                os.makedirs(dir_path, exist_ok=True)
        
        # Записываем скрипт установки напрямую
        setup_script_path = os.path.join(temp_dir, 'setup.sh')
        with open(setup_script_path, 'w') as f:
            f.write(setup_script_content)
        os.chmod(setup_script_path, 0o755)
        
        # Записываем скрипт админа в директорию проекта
        admin_script_path = os.path.join(project_dir, 'create_admin.py')
        with open(admin_script_path, 'w') as f:
            f.write(admin_script_content)
        os.chmod(admin_script_path, 0o755)

        # Проверяем и добавляем файл .env.example если его нет
        env_example_path = os.path.join(project_dir, '.env.example')
        if not os.path.exists(env_example_path):
            with open(env_example_path, 'w') as f:
                f.write('''# Основные настройки
FLASK_ENV=production
FLASK_DEBUG=0
FLASK_SECRET_KEY=faceform_secure_secret_key_for_production_environment
SESSION_SECRET=faceform_secure_session_secret

# Настройки базы данных
DATABASE_URL=postgresql://faceform:faceform_password@localhost/faceform

# API ключи LightX
LIGHTX_API_KEYS=af1fde54...,d4bd48c9...,4d2c3274...,a271d490...,eeee6d2b...

# Домен и порты
HOST=faceform.vps.webdock.cloud
PORT=5000
''')
        
        # Создаем README.txt
        readme_path = os.path.join(temp_dir, 'README.txt')
        with open(readme_path, 'w') as f:
            f.write('''# FaceForm - Полный установочный пакет для VPS faceform.vps.webdock.cloud

## Инструкция по установке

1. Загрузите этот архив на ваш VPS сервер (92.113.145.171)
2. Распакуйте архив: `tar -xzf faceform_vps_deploy_full.tar.gz`
3. Запустите скрипт установки: `sudo ./setup.sh`
4. Следуйте инструкциям на экране

После успешной установки сайт будет доступен по адресу:
- http://faceform.vps.webdock.cloud
- http://92.113.145.171

## Доступ администратора

- Логин: admin@faceform.vps.webdock.cloud
- Пароль: faceform_admin2025
- Кредиты: 1000

## Системные требования (уже соответствует VPS)

- Ubuntu 24.04.2 LTS
- Минимум 2 ГБ оперативной памяти
- Минимум 10 ГБ свободного места на диске

## Специфические настройки для данного VPS

- Домен: faceform.vps.webdock.cloud
- IPv4: 92.113.145.171
- IPv6: 2a0f:0f01:0206:1ac::0
- Пользователь: faceform

## Если возникли проблемы

1. Проверьте лог-файлы:
   - /var/log/faceform/error.log
   - /var/log/nginx/faceform_error.log

2. Проверьте статус сервиса:
   `sudo systemctl status faceform`

3. Перезапустите сервисы:
   `sudo systemctl restart faceform nginx`
''')
        
        # Создаем финальный архив
        with tarfile.open(archive_path, 'w:gz') as tar:
            # Сначала добавляем файлы из корня temp_dir
            for item in os.listdir(temp_dir):
                if item != 'faceform_project':  # Директорию проекта добавим отдельно
                    item_path = os.path.join(temp_dir, item)
                    tar.add(item_path, arcname=item)
            
            # Теперь добавляем директорию проекта
            tar.add(project_dir, arcname='faceform_project')
        
        print(f"Архив успешно создан: {archive_path}")
        
    except Exception as e:
        return f"Ошибка при создании архива: {str(e)}", 500
    finally:
        # Удаляем временную директорию
        shutil.rmtree(temp_dir)
    
    # Отдаем созданный архив
    return send_file(
        archive_path,
        as_attachment=True,
        download_name='faceform_vps_deploy_full.tar.gz',
        mimetype='application/gzip'
    )