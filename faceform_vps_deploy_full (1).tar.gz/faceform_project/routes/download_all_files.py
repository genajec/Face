import os
import zipfile
import io
import logging
from flask import Blueprint, send_file, current_app, Response

# Включаем логгирование
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

download_all_files_bp = Blueprint('download_all_files', __name__)

@download_all_files_bp.route('/download_all_files')
def download_all_files():
    """
    Маршрут для скачивания всех файлов проекта в одном ZIP-архиве с сохранением структуры директорий.
    Архив создается "налету" и сразу отправляется пользователю без сохранения на диск.
    """
    try:
        logger.info("Начало создания ZIP-архива всех файлов")
        
        # Создаем ZIP-архив в памяти
        memory_file = io.BytesIO()
        
        # Исключаем определенные директории
        excluded_dirs = [
            '__pycache__', 
            '.git', 
            '.config', 
            '.replit', 
            'venv', 
            '.venv', 
            'node_modules', 
            'tmp', 
            'faceform_archives', 
            'flask_session',
            'attached_assets',
            'extracted_analyzer',
            'extracted_frames',
            'frames'
        ]
        
        # Исключаем определенные расширения файлов
        excluded_extensions = [
            '.pyc', 
            '.pyo', 
            '.pyd', 
            '.git',
            '.env',
            '.tar.gz',
            '.zip'
        ]
        
        # Получаем корневую директорию проекта (используем абсолютный путь)
        project_root = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        logger.info(f"Корневая директория проекта: {project_root}")
        
        with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
            # Собираем файлы проекта рекурсивно
            file_count = 0
            for root, dirs, files in os.walk(project_root):
                # Исключаем нежелательные директории
                dirs[:] = [d for d in dirs if d not in excluded_dirs and not d.startswith('.')]
                
                for file in files:
                    # Пропускаем файлы с нежелательными расширениями
                    if any(file.endswith(ext) for ext in excluded_extensions) or file.startswith('.'):
                        continue
                    
                    file_path = os.path.join(root, file)
                    
                    # Получаем относительный путь для сохранения структуры директорий
                    rel_path = os.path.relpath(file_path, project_root)
                    
                    # Добавляем файл в архив
                    try:
                        zf.write(file_path, rel_path)
                        file_count += 1
                        if file_count % 100 == 0:
                            logger.info(f"Добавлено файлов: {file_count}")
                    except Exception as e:
                        logger.error(f"Ошибка при добавлении файла {rel_path}: {str(e)}")
            
            logger.info(f"Всего добавлено файлов: {file_count}")
        
        # Перемещаем указатель в начало файла
        memory_file.seek(0)
        
        logger.info("ZIP-архив успешно создан и готов к отправке")
        
        # Отправляем файл пользователю
        return send_file(
            memory_file,
            mimetype='application/zip',
            as_attachment=True,
            download_name='faceform_all_files.zip'
        )
    
    except Exception as e:
        logger.error(f"Ошибка при создании ZIP-архива: {str(e)}")
        return f"Ошибка при создании архива: {str(e)}", 500