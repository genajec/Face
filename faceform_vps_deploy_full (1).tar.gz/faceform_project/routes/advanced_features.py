import os
import cv2
import base64
import json
import uuid
import logging
import time
import traceback
from io import BytesIO
from PIL import Image
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app, session
from flask_login import current_user
from auth import auth_required
from werkzeug.utils import secure_filename

from face_analyzer import FaceAnalyzer
from database import get_user_credits, deduct_user_credits, get_credit_price_for_feature
from lightx_client import LightXClient

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
debug_logger = logging.getLogger('debug.advanced_features')
debug_logger.setLevel(logging.DEBUG)

# Создание blueprint для расширенных функций
advanced_features = Blueprint('advanced_features', __name__, url_prefix='/advanced')

# Инициализируем FaceAnalyzer
face_analyzer = FaceAnalyzer()

# Импортируем функцию получения менеджера ключей
from lightx_key_manager import get_key_manager

# Принудительно создаем новый экземпляр менеджера ключей с актуальными API ключами
get_key_manager(force_new=True)

# Инициализируем клиент LightX (будет использовать новый менеджер ключей)
lightx_client = LightXClient()

# Директории для сохранения результатов
UPLOAD_FOLDER = os.path.join('static', 'uploads')
RESULTS_FOLDER = os.path.join('static', 'results')

# Создание директорий, если их нет
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

# Допустимые расширения файлов для загрузки
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    """Проверка разрешенных расширений файлов"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_uploaded_file(file):
    """Сохранение загруженного файла"""
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # Добавление уникального идентификатора к имени файла
        unique_filename = str(uuid.uuid4()) + "_" + filename
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        file.save(file_path)
        return file_path
    return None

@advanced_features.route('/background-removal', methods=['GET'])
@auth_required
def background_removal():
    """Страница с формой для удаления фона"""
    # Получаем количество доступных кредитов
    credits_available = get_user_credits(current_user.id)
    
    # Убедимся, что credits_available - это целое число, а не объект
    if not isinstance(credits_available, int):
        # Используем метод get_credits_balance из модели User
        credits_available = current_user.get_credits_balance()
    
    # Получаем стоимость услуги в кредитах
    credits_required = get_credit_price_for_feature('background_removal')
    
    return render_template('advanced_features/background_removal.html', 
                          credits_available=credits_available,
                          credits_required=credits_required)

@advanced_features.route('/process-background-removal', methods=['POST'])
@auth_required
def process_background_removal():
    """Обработка запроса на удаление фона"""
    import traceback
    
    # Настройка подробного логирования
    debug_logger = logging.getLogger('debug.background_removal')
    debug_logger.setLevel(logging.DEBUG)
    
    # Добавляем обработчик для вывода в консоль, если его еще нет
    if not debug_logger.handlers:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        debug_logger.addHandler(console_handler)
    
    debug_logger.debug("Вызов функции process_background_removal() - v2 с улучшенным логированием")
    
    # Получаем количество доступных кредитов
    credits_available = get_user_credits(current_user.id)
    debug_logger.debug(f"Доступно кредитов: {credits_available}")
    
    # Убедимся, что credits_available - это целое число, а не объект
    if not isinstance(credits_available, int):
        # Используем метод get_credits_balance из модели User
        credits_available = current_user.get_credits_balance()
        debug_logger.debug(f"Преобразованное значение кредитов: {credits_available}")
    
    # Получаем стоимость услуги в кредитах
    credits_required = get_credit_price_for_feature('background_removal')
    debug_logger.debug(f"Требуется кредитов: {credits_required}")
    
    # Проверяем наличие достаточного количества кредитов
    if credits_available < credits_required:
        debug_logger.warning(f"Недостаточно кредитов: {credits_available} < {credits_required}")
        flash('У вас недостаточно кредитов для использования этой функции.', 'danger')
        return redirect(url_for('advanced_features.background_removal'))
    
    # Получаем загруженный файл
    debug_logger.debug(f"request.files: {request.files}")
    if 'image' not in request.files:
        debug_logger.warning("Изображение не найдено в запросе")
        flash('Не выбран файл', 'danger')
        return redirect(url_for('advanced_features.background_removal'))
    
    file = request.files['image']
    debug_logger.debug(f"Имя файла: {file.filename}, тип: {file.content_type}")
    
    if file.filename == '':
        debug_logger.warning("Пустое имя файла")
        flash('Не выбран файл', 'danger')
        return redirect(url_for('advanced_features.background_removal'))
    
    # Проверяем и сохраняем файл
    debug_logger.debug("Сохраняем загруженный файл")
    file_path = save_uploaded_file(file)
    if not file_path:
        debug_logger.warning(f"Недопустимый формат файла: {file.filename}")
        flash('Недопустимый формат файла. Пожалуйста, загрузите изображение в формате JPG или PNG.', 'danger')
        return redirect(url_for('advanced_features.background_removal'))
    
    debug_logger.debug(f"Файл успешно сохранен: {file_path}")
    
    try:
        # Читаем изображение
        debug_logger.debug(f"Читаем изображение из файла: {file_path}")
        with open(file_path, 'rb') as img_file:
            image_data = img_file.read()
        debug_logger.debug(f"Прочитано {len(image_data)} байт данных изображения")
        
        # Получаем цвет фона
        bg_color = request.form.get('bg_color', '#FFFFFF')
        debug_logger.debug(f"Выбранный цвет фона: {bg_color}")
        
        # Загружаем изображение в сервис LightX
        debug_logger.debug("Загружаем изображение в LightX")
        image_url = lightx_client.upload_image(image_data)
        debug_logger.debug(f"Результат загрузки: {image_url}")
        
        if not image_url:
            debug_logger.error("Не удалось получить URL загруженного изображения")
            flash('Не удалось загрузить изображение. Пожалуйста, попробуйте снова.', 'danger')
            return redirect(url_for('advanced_features.background_removal'))
        
        # Удаляем фон
        debug_logger.debug(f"Удаляем фон с изображения {image_url}, новый цвет: {bg_color}")
        output_url = lightx_client.remove_background(image_url, bg_color)
        debug_logger.debug(f"Результат удаления фона: {output_url}")
        
        if not output_url:
            # Если не удалось получить URL, используем аварийный вариант - подготовим сообщение
            debug_logger.error("Не удалось получить URL обработанного изображения")
            flash('Сервис удаления фона временно недоступен. Пожалуйста, попробуйте позже.', 'warning')
            # Сервис недоступен, но мы всё равно вернём оригинальное изображение
            # чтобы пользователь видел что его запрос обработан
            original_image_url = '/' + file_path.replace('\\', '/')
            results = {
                'original_image': original_image_url,
                'processed_image': original_image_url,
                'error_message': 'Удаление фона временно недоступно. Пожалуйста, попробуйте позже.'
            }
            # Не списываем кредиты, так как услуга не оказана
            return render_template('advanced_features/background_removal_results.html', results=results)
        
        # Скачиваем результат
        debug_logger.debug(f"Загружаем результат с URL: {output_url}")
        result_data = lightx_client.download_image(output_url)
        
        if not result_data:
            debug_logger.error("Не удалось загрузить данные результата")
            flash('Сервис удаления фона временно недоступен. Пожалуйста, попробуйте позже.', 'warning')
            
            # Возвращаем результаты с сообщением об ошибке
            original_image_url = '/' + file_path.replace('\\', '/')
            results = {
                'original_image': original_image_url,
                'processed_image': None,
                'error_message': 'Не удалось получить результат обработки. Пожалуйста, попробуйте позже.'
            }
            # Не списываем кредиты, так как результат не получен
            return render_template('advanced_features/background_removal_results.html', 
                                  results=results, 
                                  error_message=results['error_message'])
        
        debug_logger.debug(f"Получено {len(result_data)} байт данных результата")
        
        # Сохраняем результат
        result_filename = f"bg_removed_{os.path.basename(file_path)}"
        result_path = os.path.join(RESULTS_FOLDER, result_filename)
        debug_logger.debug(f"Сохраняем результат в файл: {result_path}")
        
        with open(result_path, 'wb') as result_file:
            result_file.write(result_data)
        
        debug_logger.debug("Результат успешно сохранен")
        
        # Списываем кредиты
        debug_logger.debug(f"Списываем {credits_required} кредитов с пользователя {current_user.id}")
        deduct_user_credits(current_user.id, credits_required)
        
        # Формируем пути для отображения в шаблоне
        original_image_url = '/' + file_path.replace('\\', '/')
        result_image_url = '/' + result_path.replace('\\', '/')
        debug_logger.debug(f"Оригинальное изображение: {original_image_url}")
        debug_logger.debug(f"Обработанное изображение: {result_image_url}")
        
        # Передаем результаты в шаблон
        results = {
            'original_image': original_image_url,
            'processed_image': result_image_url
        }
        
        debug_logger.debug("Возвращаем результаты в шаблон")
        return render_template('advanced_features/background_removal_results.html', results=results)
        
    except Exception as e:
        debug_logger.error(f"Ошибка при обработке: {e}")
        debug_logger.error(traceback.format_exc())
        flash(f'Произошла ошибка при обработке изображения', 'danger')
        
        # В случае любой ошибки также показываем результат с сообщением об ошибке
        if 'file_path' in locals():
            original_image_url = '/' + file_path.replace('\\', '/')
            results = {
                'original_image': original_image_url,
                'processed_image': None,
                'error_message': 'Произошла внутренняя ошибка при обработке изображения. Пожалуйста, попробуйте позже.'
            }
            return render_template('advanced_features/background_removal_results.html', 
                                  results=results, 
                                  error_message=results['error_message'])
        else:
            return redirect(url_for('advanced_features.background_removal'))

@advanced_features.route('/text-to-image', methods=['GET'])
@auth_required
def text_to_image():
    """Страница с формой для генерации изображения по тексту"""
    # Получаем количество доступных кредитов
    credits_available = get_user_credits(current_user.id)
    
    # Убедимся, что credits_available - это целое число, а не объект
    if not isinstance(credits_available, int):
        # Используем метод get_credits_balance из модели User
        credits_available = current_user.get_credits_balance()
    
    # Получаем стоимость услуги в кредитах
    credits_required = get_credit_price_for_feature('text_to_image')
    
    return render_template('advanced_features/text_to_image.html', 
                          credits_available=credits_available,
                          credits_required=credits_required)

@advanced_features.route('/process-text-to-image', methods=['POST'])
@auth_required
def process_text_to_image():
    """Обработка запроса на генерацию изображения по тексту"""
    import traceback
    
    # Настройка подробного логирования
    debug_logger = logging.getLogger('debug.text_to_image')
    debug_logger.setLevel(logging.DEBUG)
    
    # Добавляем обработчик для вывода в консоль, если его еще нет
    if not debug_logger.handlers:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        debug_logger.addHandler(console_handler)
    
    debug_logger.debug("Вызов функции process_text_to_image() - v2 с улучшенным логированием")
    
    # Получаем количество доступных кредитов
    credits_available = get_user_credits(current_user.id)
    debug_logger.debug(f"Доступно кредитов: {credits_available}")
    
    # Убедимся, что credits_available - это целое число, а не объект
    if not isinstance(credits_available, int):
        # Используем метод get_credits_balance из модели User
        credits_available = current_user.get_credits_balance()
        debug_logger.debug(f"Преобразованное значение кредитов: {credits_available}")
    
    # Получаем стоимость услуги в кредитах
    credits_required = get_credit_price_for_feature('text_to_image')
    debug_logger.debug(f"Требуется кредитов: {credits_required}")
    
    # Проверяем наличие достаточного количества кредитов
    if credits_available < credits_required:
        debug_logger.warning(f"Недостаточно кредитов: {credits_available} < {credits_required}")
        flash('У вас недостаточно кредитов для использования этой функции.', 'danger')
        return redirect(url_for('advanced_features.text_to_image'))
    
    # Получаем текстовый запрос и параметры
    text_prompt = request.form.get('text_prompt', '')
    image_style = request.form.get('image_style', 'photo')
    image_size = request.form.get('image_size', '1024x1024')
    
    debug_logger.debug(f"Полученный текстовый запрос: '{text_prompt}'")
    debug_logger.debug(f"Выбранный стиль: '{image_style}'")
    debug_logger.debug(f"Выбранный размер: '{image_size}'")
    
    if not text_prompt or len(text_prompt) < 3:
        debug_logger.warning(f"Недопустимый запрос: '{text_prompt}', длина: {len(text_prompt)}")
        flash('Пожалуйста, введите более подробное описание (минимум 3 символа).', 'danger')
        return redirect(url_for('advanced_features.text_to_image'))
    
    # Модифицируем промпт в зависимости от выбранного стиля
    style_descriptions = {
        'photo': 'фотореалистичное изображение, высокое качество, детализированная фотография',
        'digital-art': 'цифровое искусство, яркие цвета, креативная композиция',
        'painting': 'живопись, художественный стиль, мазки кистью, текстура холста',
        '3d-render': '3D рендер, объемное изображение, реалистичное освещение, детализированные текстуры',
        'anime': 'аниме стиль, яркие цвета, стилизованные черты'
    }
    
    # Добавляем описание стиля к исходному промпту
    enhanced_prompt = f"{text_prompt}, {style_descriptions.get(image_style, '')}"
    debug_logger.debug(f"Усиленный промпт с учетом стиля: '{enhanced_prompt}'")
    
    try:
        # Генерируем изображение с учетом стиля
        debug_logger.debug(f"Отправляем запрос на генерацию изображения с усиленным промптом")
        image_data = lightx_client.generate_from_text(enhanced_prompt)
        
        if not image_data:
            debug_logger.error("Не удалось получить данные изображения от API")
            
            # Проверяем, есть ли информация о времени разблокировки ключей
            next_available_time = None
            try:
                # Получаем информацию о следующем доступном ключе
                from lightx_key_manager import get_key_manager
                key_manager = get_key_manager()
                unlock_seconds = key_manager.get_next_unlock_time()
                
                if unlock_seconds > 0:
                    # Конвертируем секунды в часы и минуты
                    hours = unlock_seconds // 3600
                    minutes = (unlock_seconds % 3600) // 60
                    next_available_time = f"{hours} ч. {minutes} мин."
            except Exception as e:
                debug_logger.error(f"Ошибка при получении информации о разблокировке ключей: {e}")
            
            # Формируем сообщение в зависимости от доступности информации о разблокировке
            if next_available_time:
                error_message = f'Исчерпан лимит запросов к API генерации изображений. Сервис будет доступен примерно через {next_available_time}.'
                flash(error_message, 'info')
            else:
                error_message = 'Сервис генерации изображений временно недоступен. Пожалуйста, попробуйте позже.'
                flash(error_message, 'warning')
            
            # Возвращаем страницу с информацией о временной недоступности
            results = {
                'prompt': text_prompt,
                'image_path': None,
                'error_message': error_message
            }
            # Не списываем кредиты, так как услуга не была оказана
            return render_template('advanced_features/text_to_image_results.html', results=results)
        
        debug_logger.debug(f"Получено {len(image_data)} байт данных изображения")
        
        # Сохраняем результат
        result_filename = f"generated_{uuid.uuid4()}.jpg"
        result_path = os.path.join(RESULTS_FOLDER, result_filename)
        debug_logger.debug(f"Сохраняем результат в файл: {result_path}")
        
        # Убедимся, что директория существует
        if not os.path.exists(RESULTS_FOLDER):
            debug_logger.debug(f"Создаем директорию для результатов: {RESULTS_FOLDER}")
            os.makedirs(RESULTS_FOLDER, exist_ok=True)
        
        with open(result_path, 'wb') as result_file:
            result_file.write(image_data)
        
        debug_logger.debug("Результат успешно сохранен")
        
        # Списываем кредиты
        debug_logger.debug(f"Списываем {credits_required} кредитов с пользователя {current_user.id}")
        deduct_user_credits(current_user.id, credits_required)
        
        # Формируем путь для отображения в шаблоне
        result_image_url = '/' + result_path.replace('\\', '/')
        debug_logger.debug(f"URL изображения для отображения: {result_image_url}")
        
        # Передаем результаты в шаблон
        results = {
            'prompt': text_prompt,
            'image_path': result_image_url
        }
        
        debug_logger.debug("Возвращаем результаты в шаблон")
        return render_template('advanced_features/text_to_image_results.html', results=results)
        
    except Exception as e:
        debug_logger.error(f"Ошибка при генерации изображения из текста: {e}")
        debug_logger.error(traceback.format_exc())
        flash(f'Произошла ошибка при генерации изображения', 'danger')
        
        # Возвращаем страницу с информацией об ошибке
        results = {
            'prompt': text_prompt,
            'image_path': None,
            'error_message': 'Произошла внутренняя ошибка при генерации изображения. Пожалуйста, попробуйте позже.'
        }
        # Не списываем кредиты, так как услуга не была оказана
        return render_template('advanced_features/text_to_image_results.html', results=results)

@advanced_features.route('/video-analysis', methods=['GET'])
@auth_required
def video_analysis():
    """Страница с формой для анализа видео"""
    # Получаем количество доступных кредитов
    credits_available = get_user_credits(current_user.id)
    
    # Убедимся, что credits_available - это целое число, а не объект
    if not isinstance(credits_available, int):
        # Используем метод get_credits_balance из модели User
        credits_available = current_user.get_credits_balance()
    
    # Получаем стоимость услуги в кредитах
    credits_required = get_credit_price_for_feature('video_analysis')
    
    return render_template('advanced_features/video_analysis.html', 
                          credits_available=credits_available,
                          credits_required=credits_required)

@advanced_features.route('/process-video-analysis', methods=['POST'])
@auth_required
def process_video_analysis():
    """Обработка запроса на анализ видео"""
    import traceback
    
    # Настройка подробного логирования
    debug_logger = logging.getLogger('debug.video_analysis')
    debug_logger.setLevel(logging.DEBUG)
    
    # Добавляем обработчик для вывода в консоль, если его еще нет
    if not debug_logger.handlers:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        debug_logger.addHandler(console_handler)
    
    debug_logger.debug("Вызов функции process_video_analysis()")
    
    # Видео анализ теперь предоставляется бесплатно
    debug_logger.debug("Функция видео анализа предоставляется бесплатно")
    
    # Получаем загруженный файл
    debug_logger.debug(f"request.files: {request.files}")
    if 'video' not in request.files:
        debug_logger.warning("Видео не найдено в запросе")
        flash('Не выбран файл', 'danger')
        return redirect(url_for('advanced_features.video_analysis'))
    
    file = request.files['video']
    debug_logger.debug(f"Имя файла: {file.filename}, тип: {file.content_type}")
    if file.filename == '':
        debug_logger.warning("Пустое имя файла")
        flash('Не выбран файл', 'danger')
        return redirect(url_for('advanced_features.video_analysis'))
    
    # Проверяем расширение файла
    if not '.' in file.filename or file.filename.rsplit('.', 1)[1].lower() not in ['mp4', 'mov']:
        debug_logger.warning(f"Недопустимый формат файла: {file.filename}")
        flash('Недопустимый формат файла. Пожалуйста, загрузите видео в формате MP4 или MOV.', 'danger')
        return redirect(url_for('advanced_features.video_analysis'))
    
    # Генерируем уникальное имя для файла
    filename = secure_filename(file.filename)
    unique_filename = str(uuid.uuid4()) + "_" + filename
    video_path = os.path.join(UPLOAD_FOLDER, unique_filename)
    debug_logger.debug(f"Путь сохранения видео: {video_path}")
    
    # Проверяем, существует ли директория
    if not os.path.exists(UPLOAD_FOLDER):
        debug_logger.debug(f"Создаем директорию {UPLOAD_FOLDER}")
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    # Сохраняем видео
    try:
        file.save(video_path)
        debug_logger.debug(f"Видео успешно сохранено в {video_path}")
    except Exception as e:
        debug_logger.error(f"Ошибка при сохранении видео: {e}")
        debug_logger.error(traceback.format_exc())
        flash(f'Ошибка при сохранении видео: {str(e)}', 'danger')
        return redirect(url_for('advanced_features.video_analysis'))
    
    try:
        # Получаем опции анализа
        analysis_options = request.form.getlist('analysis-options')
        debug_logger.debug(f"Опции анализа: {analysis_options}")
        
        # Подготавливаем параметры для обработки видео
        process_params = {
            'face_shape': 'face_shape' in analysis_options,
            'symmetry': 'symmetry' in analysis_options,
            'landmarks': 'landmarks' in analysis_options
        }
        debug_logger.debug(f"Параметры процесса: {process_params}")
        
        # Создаем директорию для кадров
        frames_folder = os.path.join('extracted_frames', str(uuid.uuid4()))
        debug_logger.debug(f"Создаем директорию для кадров: {frames_folder}")
        os.makedirs(frames_folder, exist_ok=True)
        
        # Получаем FPS и общее количество кадров
        debug_logger.debug(f"Открываем видео для анализа метаданных: {video_path}")
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            debug_logger.error(f"Не удалось открыть видеофайл: {video_path}")
            flash('Не удалось открыть видеофайл. Возможно, формат не поддерживается.', 'danger')
            return redirect(url_for('advanced_features.video_analysis'))
        
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        # Проверяем длительность видео (не более 7 секунд)
        video_duration = total_frames / fps if fps > 0 else 0
        debug_logger.debug(f"Длительность видео: {video_duration:.2f} секунд")
        
        if video_duration > 7:
            cap.release()
            debug_logger.warning(f"Видео слишком длинное: {video_duration:.2f} секунд > 7 секунд")
            flash('Длительность видео превышает 7 секунд. Пожалуйста, загрузите более короткое видео.', 'danger')
            return redirect(url_for('advanced_features.video_analysis'))
            
        debug_logger.debug(f"Метаданные видео: FPS={fps}, всего кадров={total_frames}, размер={width}x{height}")
        cap.release()
        
        # Для обработки выбираем каждый N-й кадр
        frame_step = max(1, int(fps / 2))  # Обрабатываем примерно 2 кадра в секунду
        debug_logger.debug(f"Установлен шаг обработки кадров: {frame_step}")
        
        # Обрабатываем видео с использованием улучшенного процессора с триангуляционной сеткой
        debug_logger.debug("Импортируем улучшенный модуль для обработки видео с триангуляционной сеткой")
        from video_processor_triangulation import process_video_for_web_triangulation
        
        # Убедимся, что директория результатов существует
        if not os.path.exists(RESULTS_FOLDER):
            debug_logger.debug(f"Создаем директорию результатов: {RESULTS_FOLDER}")
            os.makedirs(RESULTS_FOLDER, exist_ok=True)
        
        result_video_path = os.path.join(RESULTS_FOLDER, f"analyzed_{unique_filename}")
        debug_logger.debug(f"Путь для сохранения обработанного видео: {result_video_path}")
        
        # Читаем видео-файл в память
        with open(video_path, 'rb') as f:
            video_bytes = f.read()
        
        debug_logger.debug(f"Видео прочитано в память: {len(video_bytes)} байт")
        debug_logger.debug("Начинаем обработку видео с триангуляционной сеткой...")
        
        # Импортируем трекер прогресса
        from progress_tracker import update_progress

        # Создаем уникальный ID для отслеживания прогресса
        progress_id = unique_filename
        session['video_progress_id'] = progress_id
        # Важно, чтобы изменения в сессии были сохранены
        session.modified = True
        debug_logger.debug(f"Создан ID прогресса: {progress_id} и сохранен в сессии")
        
        # Определяем функцию прогресса для логирования и обновления UI
        def progress_update(percent, stage, remaining_time=None):
            debug_logger.debug(f"Прогресс обработки видео: {percent:.1f}%, этап: {stage}, оставшееся время: {remaining_time}")
            # Обновляем прогресс в глобальном хранилище
            update_progress(progress_id, percent, stage, remaining_time)
        
        # Получаем результаты с улучшенной триангуляционной сеткой и центральными линиями
        processed_video, analysis_results = process_video_for_web_triangulation(
            video_bytes,
            output_path=result_video_path,
            progress_callback=progress_update,
            return_analysis=True,
            ensure_vertical=True  # Обеспечиваем вертикальный формат видео
        )
        debug_logger.debug("Обработка видео завершена")
        
        # Проверяем, существует ли файл результата
        if not os.path.exists(result_video_path):
            debug_logger.error(f"Файл результата не существует: {result_video_path}")
            flash('Не удалось обработать видео. Пожалуйста, проверьте файл и попробуйте снова.', 'danger')
            return redirect(url_for('advanced_features.video_analysis'))
        
        debug_logger.debug(f"Файл результата успешно создан: {result_video_path}")
        
        # Не списываем кредиты для функции анализа видео по требованию пользователя
        debug_logger.debug(f"Видео анализ предоставляется бесплатно (кредиты не списываются)")
        
        # Формируем URL для просмотра видео
        video_url = '/' + result_video_path.replace('\\', '/')
        debug_logger.debug(f"URL для просмотра обработанного видео: {video_url}")
        
        # Получаем определенную форму лица из результатов анализа, если есть
        face_shape = None
        if analysis_results and 'face_shape' in analysis_results:
            face_shape = analysis_results.get('face_shape')
            debug_logger.debug(f"Определена форма лица: {face_shape}")
            
        # Сохраняем результаты в сессии для передачи на страницу результатов
        session['video_analysis_results'] = {
            'original_video': '/' + video_path.replace('\\', '/'),
            'processed_video': video_url,
            'options': process_params,
            'face_shape': face_shape
        }
        debug_logger.debug("Результаты сохранены в сессии")
        
        # Перенаправляем на страницу с результатами
        debug_logger.debug("Перенаправляем на страницу результатов")
        return redirect(url_for('advanced_features.video_analysis_results'))
        
    except Exception as e:
        debug_logger.error(f"Ошибка при обработке видео: {e}")
        debug_logger.error(traceback.format_exc())
        flash(f'Произошла ошибка при обработке видео: {str(e)}', 'danger')
        return redirect(url_for('advanced_features.video_analysis'))

@advanced_features.route('/video-analysis-results', methods=['GET'])
@auth_required
def video_analysis_results():
    """Страница с результатами анализа видео"""
    # Получаем результаты из сессии
    results = session.get('video_analysis_results')
    if not results:
        flash('Результаты анализа не найдены.', 'warning')
        return redirect(url_for('advanced_features.video_analysis'))
    
    return render_template('advanced_features/video_analysis_results.html', 
                          original_video_url=results.get('original_video'),
                          processed_video_url=results.get('processed_video'),
                          options=results.get('options'),
                          face_shape=results.get('face_shape'))

@advanced_features.route('/api/video-progress/<progress_id>', methods=['GET'])
@auth_required
def get_video_progress(progress_id):
    """
    API-маршрут для получения текущего прогресса обработки видео.
    Используется для обновления индикатора прогресса на клиенте.
    """
    debug_logger.debug(f"Запрос прогресса для ID: {progress_id}")
    debug_logger.debug(f"Текущий ID в сессии: {session.get('video_progress_id', 'отсутствует')}")
    
    try:
        # Проверяем, соответствует ли ID текущему ID в сессии
        session_progress_id = session.get('video_progress_id', '')
        if progress_id != session_progress_id and session_progress_id != '':
            debug_logger.debug(f"ID в запросе ({progress_id}) не соответствует ID в сессии ({session_progress_id})")
            # Если в сессии есть другой ID, используем его вместо переданного
            if session_progress_id:
                debug_logger.debug(f"Используем ID из сессии: {session_progress_id}")
                progress_id = session_progress_id
        
        # Получаем прогресс из глобального хранилища
        from progress_tracker import get_progress
        
        percent, stage, remaining_time, data = get_progress(progress_id)
        debug_logger.debug(f"Получены данные о прогрессе: {percent}%, этап: {stage}")
        
        # Проверяем, если процент равен 0 и stage "Инициализация...", 
        # значит задача не найдена или не активна
        if percent == 0.0 and stage == "Инициализация...":
            # Проверяем, была ли раньше задача с таким ID
            if progress_id == session_progress_id:
                # Удаляем ID из сессии
                session.pop('video_progress_id', None)
                session.modified = True
                debug_logger.debug(f"Задача не найдена, удаляем из сессии: {progress_id}")
                # Возвращаем статус, что задача не существует
                return jsonify({
                    'error': 'task_not_found',
                    'message': 'Задача не найдена или завершена'
                }), 404
        
        # Если процент выполнения 100% или больше 95% и не меняется долгое время, значит задача завершена
        if percent >= 100.0 or (percent > 95.0 and remaining_time is not None and remaining_time <= 0.1):
            debug_logger.debug(f"Задача завершена ({percent}%), возвращаем финальный прогресс")
            # Если задача завершена, мы можем очистить ID из сессии
            if progress_id == session_progress_id:
                session.pop('video_progress_id', None)
                session.modified = True
                debug_logger.debug(f"Задача завершена, удаляем из сессии: {progress_id}")
                
                # Принудительно устанавливаем прогресс на 100%, если он был близок к завершению
                if percent < 100.0 and percent > 95.0:
                    from progress_tracker import update_progress
                    update_progress(progress_id, 100.0, "Завершено", 0, data)
                    debug_logger.debug(f"Принудительно завершаем задачу {progress_id}, устанавливая 100%")
        
        # Формируем JSON-ответ
        response = {
            'percent': percent,
            'stage': stage,
            'remainingTime': remaining_time,
            'data': data
        }
        
        debug_logger.debug(f"Отправляем ответ о прогрессе: {response}")
        return jsonify(response)
    except Exception as e:
        debug_logger.error(f"Ошибка при получении прогресса обработки видео: {e}")
        debug_logger.error(traceback.format_exc())
        return jsonify({
            'error': 'server_error',
            'message': f'Произошла ошибка при получении прогресса: {str(e)}'
        }), 500

@advanced_features.route('/', methods=['GET'])
@auth_required
def advanced_features_home():
    """Главная страница расширенных функций"""
    # Получаем количество доступных кредитов
    credits_available = get_user_credits(current_user.id)
    
    # Убедимся, что credits_available - это целое число, а не объект
    if not isinstance(credits_available, int):
        # Используем метод get_credits_balance из модели User
        credits_available = current_user.get_credits_balance()
    
    # Получаем стоимость услуг в кредитах
    bg_removal_credits = get_credit_price_for_feature('background_removal')
    text_to_image_credits = get_credit_price_for_feature('text_to_image')
    video_analysis_credits = get_credit_price_for_feature('video_analysis')
    
    # Список доступных функций
    features = [
        {
            'name': 'Удаление фона',
            'description': 'Автоматическое удаление фона с фотографий',
            'url': url_for('advanced_features.background_removal'),
            'icon': 'image',
            'credits': bg_removal_credits,
            'image': None
        },
        {
            'name': 'Генерация изображений',
            'description': 'Создание изображений по текстовому описанию',
            'url': url_for('advanced_features.text_to_image'),
            'icon': 'text-paragraph',
            'credits': text_to_image_credits,
            'image': None
        },
        {
            'name': 'Анализ видео',
            'description': 'Анализ лица на видео с визуализацией параметров',
            'url': url_for('advanced_features.video_analysis'),
            'icon': 'camera-video',
            'credits': 0,
            'is_free': True,
            'image': None
        }
    ]
    
    return render_template('advanced_features/index.html', 
                          features=features,
                          credits_available=credits_available)
                          
@advanced_features.route('/test-routes', methods=['GET'])
@auth_required
def test_routes():
    """Тестовая страница для проверки маршрутов"""
    return render_template('advanced_features/test_routes.html')