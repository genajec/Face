from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import login_required, current_user
from auth import auth_required
import os
import io
import base64
import numpy as np
import cv2
import logging
from werkzeug.utils import secure_filename
from datetime import datetime

from app import db
from models import User, Credit, Transaction
from face_analyzer import FaceAnalyzer
from face_attractiveness import FaceAttractiveness

# Создаем Blueprint для маршрутов анализа лица
face_analysis = Blueprint('face_analysis', __name__, url_prefix='/face-analysis')

# Инициализация анализаторов
face_analyzer = FaceAnalyzer()
attractiveness_analyzer = FaceAttractiveness()

# Разрешенные расширения файлов изображений
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    """Проверяет, является ли файл допустимым изображением"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@face_analysis.route('/', methods=['GET', 'POST'])
@auth_required
def analyze_face():
    """Страница для загрузки и анализа изображения лица"""
    # Получаем количество использований для отображения в шаблоне
    from models import CreditUsage, db
    face_shape_usages = db.session.query(CreditUsage).filter_by(
        user_id=current_user.id,
        feature='face_shape_analysis'
    ).count()
    free_usages_left = max(0, 5 - face_shape_usages)
    
    if request.method == 'POST':
        # Проверка наличия файла в запросе
        if 'file' not in request.files:
            flash('Файл не выбран', 'danger')
            return redirect(request.url)
            
        file = request.files['file']
        
        # Проверка имени файла
        if file.filename == '':
            flash('Файл не выбран', 'danger')
            return redirect(request.url)
            
        # Проверка валидности файла
        if file and allowed_file(file.filename):
            # Проверяем количество использований функции анализа лица
            from models import CreditUsage, db
            face_shape_usages = db.session.query(CreditUsage).filter_by(
                user_id=current_user.id,
                feature='face_shape_analysis'
            ).count()
            
            # Если уже использовано 5 раз, проверяем баланс кредитов
            if face_shape_usages >= 5 and current_user.get_credits_balance() < 1:
                flash('Вы уже использовали 5 бесплатных анализов формы лица. Пожалуйста, пополните баланс кредитов.', 'warning')
                return redirect(url_for('payments.pricing'))
                
            # Считываем файл и анализируем
            try:
                image_data = file.read()
                
                # Вызываем метод анализа из FaceAnalyzer
                result = face_analyzer.analyze_face_shape(image_data)
                
                if not result or len(result) < 3:
                    flash('Не удалось определить форму лица. Убедитесь, что лицо хорошо видно на фотографии.', 'warning')
                    return redirect(request.url)
                    
                face_shape, visualization_image, measurements = result
                
                # Сохраняем только необходимые данные в сессии
                session['face_shape'] = face_shape
                
                # Сохраняем визуализацию во временный файл вместо сессии
                # Создаем папку для временных файлов, если она не существует
                temp_dir = os.path.join('static', 'temp')
                os.makedirs(temp_dir, exist_ok=True)
                
                # Уникальное имя файла на основе времени и ID пользователя
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                filename = f"vis_{current_user.id}_{timestamp}.jpg"
                filepath = os.path.join(temp_dir, filename)
                
                # Сохраняем изображение
                with open(filepath, 'wb') as f:
                    f.write(visualization_image)
                    
                # Сохраняем путь к изображению вместо самого изображения
                session['visualization_path'] = os.path.join('temp', filename)
                
                # Сохраняем измерения (они небольшие по размеру)
                session['measurements'] = {
                    'width_to_length_ratio': float(measurements['width_to_length_ratio']),
                    'forehead_to_jawline_ratio': float(measurements['forehead_to_jawline_ratio']),
                    'cheekbone_to_jawline_ratio': float(measurements['cheekbone_to_jawline_ratio'])
                }
                
                # Получаем рекомендации по прическам для данной формы лица
                recommendations = get_face_shape_recommendations(face_shape)
                session['recommendations'] = recommendations
                
                # Проверяем, нужно ли списывать кредит
                from models import CreditUsage, db
                face_shape_usages = db.session.query(CreditUsage).filter_by(
                    user_id=current_user.id,
                    feature='face_shape_analysis'
                ).count()
                
                # Если использовано 5 или более раз, списываем кредит
                if face_shape_usages >= 5:
                    current_user.deduct_credits(1, 'Анализ формы лица')
                    message = 'Ваши данные были успешно отправлены и обработаны. С вашего счета списан 1 кредит.'
                else:
                    # Просто записываем использование функции без списания кредитов
                    usage = CreditUsage(
                        user_id=current_user.id,
                        amount=0,
                        feature='face_shape_analysis',
                        description='Бесплатный анализ формы лица'
                    )
                    db.session.add(usage)
                    db.session.commit()
                    message = f'Ваши данные были успешно отправлены и обработаны. У вас осталось {5 - (face_shape_usages + 1)} бесплатных использований.'
                
                # Добавляем уведомление об успешной отправке и обработке данных
                flash(message, 'success')
                
                return redirect(url_for('face_analysis.result'))
                
            except Exception as e:
                flash(f'Ошибка при анализе изображения: {str(e)}', 'danger')
                return redirect(request.url)
        else:
            flash('Недопустимый формат файла. Разрешены только PNG, JPG, JPEG и GIF', 'warning')
            return redirect(request.url)
    
    # Отображаем форму загрузки для метода GET
    return render_template('face_analysis/upload.html', free_usages_left=free_usages_left)

@face_analysis.route('/result')
@auth_required
def result():
    """Страница отображения результатов анализа лица"""
    # Проверяем, есть ли данные анализа в сессии
    if 'face_shape' not in session or 'visualization_path' not in session:
        flash('Данные анализа отсутствуют. Пожалуйста, загрузите изображение для анализа.', 'warning')
        return redirect(url_for('face_analysis.analyze_face'))
        
    # Получаем данные из сессии
    face_shape = session.get('face_shape')
    visualization_path = session.get('visualization_path')
    measurements = session.get('measurements')
    recommendations = session.get('recommendations')
    
    # Константы для отображения информации о форме лица
    FACE_SHAPE_CRITERIA = {
        "OVAL": {"description": "Овальная", "ratio": "примерно 1.5:1"},
        "ROUND": {"description": "Круглая", "ratio": "примерно 1:1"},
        "SQUARE": {"description": "Квадратная", "ratio": "примерно 1:1, с широкой челюстью"},
        "HEART": {"description": "Сердцевидная", "ratio": "шире у лба"},
        "OBLONG": {"description": "Продолговатая", "ratio": "более 1.5:1"},
        "DIAMOND": {"description": "Ромбовидная", "ratio": "шире в скулах"},
        "TRIANGLE": {"description": "Треугольная", "ratio": "шире в челюсти"}
    }
    
    return render_template(
        'face_analysis/result.html',
        face_shape=face_shape,
        visualization_path=visualization_path,
        measurements=measurements,
        recommendations=recommendations,
        FACE_SHAPE_CRITERIA=FACE_SHAPE_CRITERIA
    )

@face_analysis.route('/beauty-check', methods=['GET', 'POST'])
@auth_required
def beauty_check_new():
    """Страница для анализа привлекательности лица по математическим параметрам"""
    if request.method == 'POST':
        # Проверка наличия файла в запросе
        if 'file' not in request.files:
            flash('Файл не выбран', 'danger')
            return redirect(request.url)
            
        file = request.files['file']
        
        # Проверка имени файла
        if file.filename == '':
            flash('Файл не выбран', 'danger')
            return redirect(request.url)
            
        # Проверка валидности файла
        if file and allowed_file(file.filename):
            # Проверка баланса кредитов (1 кредит за анализ привлекательности)
            if current_user.get_credits_balance() < 1:
                flash('Недостаточно кредитов для анализа привлекательности. Пожалуйста, пополните баланс.', 'warning')
                return redirect(url_for('payments.pricing'))
                
            # Считываем файл и анализируем
            try:
                # Добавляем подробное логирование
                logger = logging.getLogger(__name__)
                logger.setLevel(logging.DEBUG)
                
                logger.debug("Начинаем обработку изображения для анализа привлекательности")
                image_data = file.read()
                logger.debug(f"Изображение успешно прочитано, размер данных: {len(image_data)} байт")
                
                # Проверка инициализации анализатора
                logger.debug(f"Тип анализатора: {type(attractiveness_analyzer)}")
                
                # Вызываем метод анализа привлекательности
                logger.debug("Вызываем метод analyze_attractiveness")
                try:
                    score, comment, visualization = attractiveness_analyzer.analyze_attractiveness(image_data)
                    logger.debug(f"Результат анализа: score={score}, comment={comment}, visualization type={type(visualization)}")
                except Exception as analyze_error:
                    logger.error(f"Ошибка внутри analyze_attractiveness: {str(analyze_error)}")
                    raise analyze_error
                
                if score is None:
                    logger.warning(f"Не удалось проанализировать привлекательность: {comment}")
                    flash(f'Не удалось проанализировать привлекательность лица: {comment}', 'warning')
                    return redirect(request.url)
                
                # Сохраняем визуализацию во временный файл вместо base64 в сессии
                logger.debug("Сохраняем визуализацию во временный файл")
                try:
                    # Создаем папку для временных файлов, если она не существует
                    temp_dir = os.path.join('static', 'temp')
                    os.makedirs(temp_dir, exist_ok=True)
                    
                    # Уникальное имя файла на основе времени и ID пользователя
                    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                    filename = f"beauty_{current_user.id}_{timestamp}.jpg"
                    filepath = os.path.join(temp_dir, filename)
                    
                    # Сохраняем изображение
                    cv2.imwrite(filepath, visualization)
                    logger.debug(f"Изображение сохранено в файл: {filepath}")
                except Exception as vis_error:
                    logger.error(f"Ошибка при сохранении изображения: {str(vis_error)}")
                    raise vis_error
                
                # Сохраняем в сессии только текстовые данные
                logger.debug("Сохраняем результаты в сессии")
                session['beauty_result_new'] = {
                    'score': score,
                    'comment': comment,
                    'visualization_path': os.path.join('temp', filename)
                }
                
                # Списываем 1 кредит за анализ привлекательности
                logger.debug("Списываем кредиты за анализ")
                current_user.deduct_credits(1, 'Анализ привлекательности лица')
                
                # Добавляем уведомление об успешной обработке данных
                flash('Ваши данные были успешно отправлены и обработаны. Результат анализа привлекательности готов.', 'success')
                
                logger.debug("Перенаправляем на страницу результатов")
                return redirect(url_for('face_analysis.beauty_result_new'))
                
            except Exception as e:
                flash(f'Ошибка при анализе привлекательности: {str(e)}', 'danger')
                return redirect(request.url)
        else:
            flash('Недопустимый формат файла. Разрешены только PNG, JPG, JPEG и GIF', 'warning')
            return redirect(request.url)
    
    # Отображаем форму загрузки для метода GET
    return render_template('face_analysis/beauty_upload.html')

@face_analysis.route('/beauty-check/result')
@auth_required
def beauty_result_new():
    """Страница отображения результатов анализа привлекательности лица"""
    # Проверяем, есть ли данные анализа в сессии
    if 'beauty_result_new' not in session:
        flash('Данные анализа привлекательности отсутствуют. Пожалуйста, загрузите изображение для анализа.', 'warning')
        return redirect(url_for('face_analysis.beauty_check_new'))
        
    # Получаем данные из сессии
    beauty_result = session.get('beauty_result_new')
    
    return render_template(
        'face_analysis/beauty_result.html',
        beauty_result=beauty_result
    )

@face_analysis.route('/try-hairstyle', methods=['GET', 'POST'])
@auth_required
def try_hairstyle():
    """Страница для примерки виртуальных причесок"""
    if request.method == 'POST':
        # Проверка наличия файла в запросе
        if 'file' not in request.files:
            flash('Файл не выбран', 'danger')
            return redirect(request.url)
            
        file = request.files['file']
        
        # Проверка имени файла
        if file.filename == '':
            flash('Файл не выбран', 'danger')
            return redirect(request.url)
            
        # Проверка валидности файла
        if file and allowed_file(file.filename):
            # Проверка баланса кредитов (примерка причесок стоит 2 кредита)
            if current_user.get_credits_balance() < 2:
                flash('Недостаточно кредитов для примерки причесок. Требуется 2 кредита. Пожалуйста, пополните баланс.', 'warning')
                return redirect(url_for('payments.pricing'))
            
            # Считываем файл и получаем данные о поле (gender)
            try:
                image_data = file.read()
                gender = request.form.get('gender', '')
                
                if not gender:
                    flash('Пожалуйста, укажите пол для более точного подбора причесок', 'warning')
                    return redirect(request.url)
                
                # Вызываем метод анализа из FaceAnalyzer для определения формы лица
                result = face_analyzer.analyze_face_shape(image_data)
                
                if not result or len(result) < 3:
                    flash('Не удалось определить форму лица. Убедитесь, что лицо хорошо видно на фотографии.', 'warning')
                    return redirect(request.url)
                    
                face_shape, visualization_image, measurements = result
                
                # Получаем список рекомендуемых причесок для данной формы лица с учетом пола
                hairstyles = face_analyzer.get_hairstyle_names(face_shape, gender)
                
                if not hairstyles:
                    flash('Не удалось получить список рекомендуемых причесок для вашей формы лица', 'warning')
                    return redirect(request.url)
                
                # Сохраняем данные во временных файлах
                temp_dir = os.path.join('static', 'temp')
                os.makedirs(temp_dir, exist_ok=True)
                
                # Уникальное имя файла на основе времени и ID пользователя
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                filename = f"base_{current_user.id}_{timestamp}.jpg"
                filepath = os.path.join(temp_dir, filename)
                
                # Сохраняем оригинальное изображение
                with open(filepath, 'wb') as f:
                    f.write(image_data)
                
                # Сохраняем необходимые данные в сессии
                session['hairstyle_face_shape'] = face_shape
                session['hairstyle_gender'] = gender
                
                # Явно обрабатываем названия причесок для корректного отображения кириллицы
                processed_hairstyles = []
                for style in hairstyles:
                    if isinstance(style, str):
                        processed_hairstyles.append(style)
                    else:
                        processed_hairstyles.append(str(style, 'utf-8') if isinstance(style, bytes) else str(style))
                
                session['hairstyle_options'] = processed_hairstyles
                session['hairstyle_original_image'] = os.path.join('temp', filename)
                
                # Списываем 2 кредита за примерку причесок
                current_user.deduct_credits(2, 'Примерка виртуальных причесок')
                
                # Добавляем уведомление об успешной отправке и обработке данных
                flash('Ваши данные были успешно отправлены и обработаны. Выберите прическу для примерки.', 'success')
                
                return redirect(url_for('face_analysis.hairstyle_selection'))
                
            except Exception as e:
                flash(f'Ошибка при обработке изображения: {str(e)}', 'danger')
                return redirect(request.url)
        else:
            flash('Недопустимый формат файла. Разрешены только PNG, JPG, JPEG и GIF', 'warning')
            return redirect(request.url)
    
    # Отображаем форму загрузки для метода GET
    return render_template('face_analysis/try_hairstyle.html')
    
@face_analysis.route('/hairstyle-selection', methods=['GET', 'POST'])
@auth_required
def hairstyle_selection():
    """Страница выбора прически для примерки"""
    # Проверяем, есть ли данные для примерки причесок в сессии
    if 'hairstyle_face_shape' not in session or 'hairstyle_original_image' not in session:
        flash('Данные для примерки причесок отсутствуют. Пожалуйста, загрузите изображение.', 'warning')
        return redirect(url_for('face_analysis.try_hairstyle'))
    
    if request.method == 'POST':
        # Обработка выбора прически
        try:
            hairstyle_index = int(request.form.get('hairstyle_index', 0))
            hair_color = request.form.get('hair_color', '').strip()
            face_shape = session.get('hairstyle_face_shape')
            gender = session.get('hairstyle_gender')
            
            # Открываем оригинальное изображение
            image_path = os.path.join('static', session.get('hairstyle_original_image'))
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            # Применяем выбранную прическу с указанием цвета волос
            result_image = face_analyzer.apply_hairstyle(
                image_data, 
                face_shape=face_shape, 
                hairstyle_index=hairstyle_index,
                hair_color=hair_color if hair_color else None
            )
            
            if not result_image:
                flash('Не удалось применить выбранную прическу.', 'warning')
                return redirect(url_for('face_analysis.hairstyle_selection'))
            
            # Сохраняем результат во временном файле
            temp_dir = os.path.join('static', 'temp')
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            result_filename = f"hairstyle_{current_user.id}_{timestamp}.jpg"
            result_filepath = os.path.join(temp_dir, result_filename)
            
            with open(result_filepath, 'wb') as f:
                f.write(result_image)
            
            # Сохраняем путь к изображению с примененной прической
            session['hairstyle_result_image'] = os.path.join('temp', result_filename)
            session['hairstyle_selected_index'] = hairstyle_index
            
            # Добавляем уведомление об успешной обработке данных
            flash('Ваши данные были успешно отправлены и обработаны. Прическа успешно применена.', 'success')
            
            return redirect(url_for('face_analysis.hairstyle_result'))
        
        except Exception as e:
            flash(f'Ошибка при применении прически: {str(e)}', 'danger')
            return redirect(url_for('face_analysis.hairstyle_selection'))
    
    # Данные для отображения на странице
    face_shape = session.get('hairstyle_face_shape')
    original_image = session.get('hairstyle_original_image')
    hairstyle_options = session.get('hairstyle_options', [])
    
    # Отображаем страницу выбора прически
    return render_template(
        'face_analysis/hairstyle_selection.html',
        face_shape=face_shape,
        original_image=original_image,
        hairstyle_options=hairstyle_options
    )

@face_analysis.route('/hairstyle-result')
@auth_required
def hairstyle_result():
    """Страница отображения результата примерки прически"""
    # Проверяем, есть ли данные с результатом примерки в сессии
    if 'hairstyle_result_image' not in session:
        flash('Данные примерки прически отсутствуют. Пожалуйста, выберите прическу.', 'warning')
        return redirect(url_for('face_analysis.hairstyle_selection'))
    
    # Получаем данные из сессии
    original_image = session.get('hairstyle_original_image')
    result_image = session.get('hairstyle_result_image')
    face_shape = session.get('hairstyle_face_shape')
    selected_index = session.get('hairstyle_selected_index', 0)
    hairstyle_options = session.get('hairstyle_options', [])
    
    # Определяем название выбранной прически
    selected_hairstyle = hairstyle_options[selected_index] if selected_index < len(hairstyle_options) else 'Выбранная прическа'
    
    return render_template(
        'face_analysis/hairstyle_result.html',
        original_image=original_image,
        result_image=result_image,
        face_shape=face_shape,
        selected_hairstyle=selected_hairstyle
    )

def get_face_shape_recommendations(face_shape):
    """Возвращает рекомендации по прическам для указанной формы лица"""
    recommendations = {
        "OVAL": [
            "Практически любая прическа подойдет для овальной формы лица",
            "Идеально: слоистые стрижки средней длины",
            "Длинные волнистые волосы с объемом",
            "Короткие стрижки, например, пикси или боб",
            "Можно экспериментировать с челкой любого вида"
        ],
        "ROUND": [
            "Стрижки с объемом на макушке для визуального удлинения лица",
            "Многослойные стрижки ниже подбородка",
            "Длинная косая челка для создания асимметрии",
            "Избегайте коротких стрижек, которые открывают щеки",
            "Прически с пробором посередине лучше не выбирать"
        ],
        "SQUARE": [
            "Мягкие волны или кудри для смягчения острых углов",
            "Длинная многослойная стрижка с боковым пробором",
            "Длинная челка, скошенная набок",
            "Избегайте прямых волос до подбородка, которые подчеркнут углы",
            "Хорошо подойдут взъерошенные стрижки средней длины"
        ],
        "HEART": [
            "Стрижки средней длины с объемом внизу",
            "Длинная косая челка для баланса широкого лба",
            "Волосы до подбородка, чтобы создать объем в нижней части лица",
            "Мягкие волны вокруг лица",
            "Избегайте слишком коротких стрижек, обнажающих уши"
        ],
        "OBLONG": [
            "Многослойные стрижки с объемом по бокам",
            "Волнистые или кудрявые волосы для создания ширины",
            "Прямая густая челка для визуального укорачивания лица",
            "Избегайте длинных прямых волос без слоев",
            "Хорошо подойдут пышные короткие стрижки"
        ],
        "DIAMOND": [
            "Средние и длинные многослойные стрижки",
            "Прически с объемом на уровне ушей для баланса широких скул",
            "Мягкая челка, обрамляющая лицо",
            "Хорошо подойдут волны и кудри средней интенсивности",
            "Избегайте объема на макушке и слишком коротких стрижек"
        ],
        "TRIANGLE": [
            "Прически с объемом на уровне лба для баланса с широкой челюстью",
            "Многослойные стрижки с укладкой наружу от лица",
            "Мягкая челка для создания объема в верхней части лица",
            "Избегайте прямых волос без объема и слишком длинных прямых причесок",
            "Хорошо подойдут кудри и волны с объемом в верхней части головы"
        ]
    }
    
    # Возвращаем рекомендации для указанной формы лица или общие рекомендации
    return recommendations.get(face_shape, [
        "Проконсультируйтесь с профессиональным стилистом для подбора оптимальной прически",
        "Учитывайте не только форму лица, но и тип волос, образ жизни и стиль",
        "Экспериментируйте с разной длиной и текстурой волос",
        "Используйте примерку причесок в нашем приложении для визуализации"
    ])
    
@face_analysis.route('/beauty-analysis', methods=['GET', 'POST'])
@auth_required
def beauty_analysis_new():
    """Страница для анализа привлекательности лица"""
    if request.method == 'POST':
        # Проверка наличия файла в запросе
        if 'file' not in request.files:
            flash('Файл не выбран', 'danger')
            return redirect(request.url)
            
        file = request.files['file']
        
        # Проверка имени файла
        if file.filename == '':
            flash('Файл не выбран', 'danger')
            return redirect(request.url)
            
        # Проверка валидности файла
        if file and allowed_file(file.filename):
            # Проверка баланса кредитов (анализ привлекательности стоит 2 кредита)
            if current_user.get_credits_balance() < 2:
                flash('Недостаточно кредитов для анализа привлекательности. Требуется 2 кредита. Пожалуйста, пополните баланс.', 'warning')
                return redirect(url_for('payments.pricing'))
            
            # Считываем файл и анализируем
            try:
                image_data = file.read()
                
                # Вызываем метод анализа привлекательности
                result = attractiveness_analyzer.analyze_attractiveness(image_data)
                
                if not result or len(result) < 3:
                    flash('Не удалось проанализировать привлекательность лица. Убедитесь, что лицо хорошо видно на фотографии.', 'warning')
                    return redirect(request.url)
                    
                score, comment, visualization = result
                
                # Сохраняем результаты во временных файлах
                temp_dir = os.path.join('static', 'temp')
                os.makedirs(temp_dir, exist_ok=True)
                
                # Уникальное имя файла для оригинала
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                original_filename = f"original_{current_user.id}_{timestamp}.jpg"
                original_filepath = os.path.join(temp_dir, original_filename)
                
                # Сохраняем оригинальное изображение
                with open(original_filepath, 'wb') as f:
                    f.write(image_data)
                    
                # Уникальное имя файла для визуализации
                result_filename = f"beauty_{current_user.id}_{timestamp}.jpg"
                result_filepath = os.path.join(temp_dir, result_filename)
                
                # Сохраняем визуализацию
                import cv2
                _, encoded_img = cv2.imencode('.jpg', visualization)
                with open(result_filepath, 'wb') as f:
                    f.write(encoded_img.tobytes())
                
                # Сохраняем пути к изображениям и результаты в сессии
                session['beauty_original_image_new'] = os.path.join('temp', original_filename)
                session['beauty_result_image_new'] = os.path.join('temp', result_filename)
                session['beauty_score_new'] = float(score)
                # Явно обрабатываем комментарий как UTF-8 для корректного отображения кириллицы
                if isinstance(comment, str):
                    session['beauty_comment_new'] = comment
                else:
                    session['beauty_comment_new'] = str(comment, 'utf-8') if isinstance(comment, bytes) else str(comment)
                
                # Списываем 2 кредита за анализ привлекательности
                current_user.deduct_credits(2, 'Анализ привлекательности лица')
                
                # Добавляем уведомление об успешной обработке
                flash('Ваши данные были успешно отправлены и обработаны. Результат анализа привлекательности готов.', 'success')
                
                return redirect(url_for('face_analysis.beauty_result_analysis'))
                
            except Exception as e:
                flash(f'Ошибка при анализе привлекательности: {str(e)}', 'danger')
                return redirect(request.url)
        else:
            flash('Недопустимый формат файла. Разрешены только PNG, JPG, JPEG и GIF', 'warning')
            return redirect(request.url)
    
    # Отображаем форму загрузки для метода GET
    return render_template('face_analysis/beauty_upload.html')
    
@face_analysis.route('/beauty-analysis/result')
@auth_required
def beauty_result_analysis():
    """Страница отображения результатов анализа привлекательности лица"""
    # Проверяем, есть ли данные анализа в сессии
    if 'beauty_score_new' not in session or 'beauty_result_image_new' not in session:
        flash('Данные анализа привлекательности отсутствуют. Пожалуйста, загрузите изображение для анализа.', 'warning')
        return redirect(url_for('face_analysis.beauty_analysis_new'))
    
    # Получаем данные из сессии
    original_image = session.get('beauty_original_image_new')
    result_image = session.get('beauty_result_image_new')
    score = session.get('beauty_score_new')
    comment = session.get('beauty_comment_new')
    
    return render_template(
        'face_analysis/beauty_result.html',
        original_image=original_image,
        result_image=result_image,
        score=score,
        comment=comment
    )