from flask import Blueprint, render_template

download_page_bp = Blueprint('download_page', __name__)

@download_page_bp.route('/download_page')
def download_page():
    """
    Отображает страницу для скачивания полного архива проекта.
    """
    return render_template('download_page.html')