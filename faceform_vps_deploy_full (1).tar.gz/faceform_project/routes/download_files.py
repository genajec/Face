import os
from flask import Blueprint, send_file, render_template, current_app, abort

download_files_bp = Blueprint('download_files', __name__)

@download_files_bp.route('/download_individual_file/<path:file_path>')
def download_individual_file(file_path):
    """
    Маршрут для скачивания отдельного файла проекта
    """
    # Обезопасим путь к файлу
    file_path = file_path.strip('/')
    
    # Полный путь к файлу
    full_path = os.path.join(current_app.root_path, file_path)
    
    # Проверяем, что файл существует и находится в допустимой директории
    if not os.path.exists(full_path) or not os.path.isfile(full_path):
        abort(404)
    
    # Проверяем, что файл находится в директории проекта
    if not os.path.abspath(full_path).startswith(os.path.abspath(current_app.root_path)):
        abort(403)
    
    try:
        return send_file(full_path, as_attachment=True, download_name=os.path.basename(file_path))
    except Exception as e:
        current_app.logger.error(f"Ошибка при скачивании файла {file_path}: {str(e)}")
        abort(500)

@download_files_bp.route('/view_all_files')
def view_all_files():
    """
    Маршрут для просмотра и скачивания всех файлов проекта
    """
    # Функция для сканирования директории и получения списка файлов
    def scan_directory(directory, base_path=""):
        result = []
        
        try:
            # Исключаем определенные директории
            excluded_dirs = ['__pycache__', '.git', '.config', '.replit', 'venv', '.venv', 'node_modules', 'tmp', 
                            'faceform_archives', 'flask_session']
            
            # Исключаем определенные расширения файлов
            excluded_extensions = ['.pyc', '.pyo', '.pyd', '.zip', '.tar.gz', '.env']
            
            for item in os.listdir(directory):
                # Пропускаем скрытые файлы и директории
                if item.startswith('.'):
                    continue
                
                # Пропускаем исключенные директории
                if item in excluded_dirs:
                    continue
                
                full_path = os.path.join(directory, item)
                rel_path = os.path.join(base_path, item)
                
                if os.path.isfile(full_path):
                    # Пропускаем файлы с исключенными расширениями
                    if any(item.endswith(ext) for ext in excluded_extensions):
                        continue
                    
                    # Добавляем информацию о файле
                    file_size = os.path.getsize(full_path)
                    size_str = format_size(file_size)
                    
                    result.append({
                        'path': rel_path,
                        'name': item,
                        'is_dir': False,
                        'size': size_str
                    })
                elif os.path.isdir(full_path):
                    # Для директории сначала добавляем саму директорию
                    result.append({
                        'path': rel_path,
                        'name': item,
                        'is_dir': True,
                        'size': '-'
                    })
                    
                    # Затем рекурсивно сканируем поддиректории
                    result.extend(scan_directory(full_path, rel_path))
        
        except Exception as e:
            current_app.logger.error(f"Ошибка при сканировании директории {directory}: {str(e)}")
        
        return result
    
    # Форматирование размера файла
    def format_size(size_bytes):
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.1f} MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"
    
    # Получаем список всех файлов в проекте
    project_root = current_app.root_path
    all_files = scan_directory(project_root)
    
    # Сортируем: сначала директории, затем файлы, в алфавитном порядке
    all_files.sort(key=lambda x: (not x['is_dir'], x['path']))
    
    # Группируем файлы по директориям для лучшего отображения
    files_by_directory = {}
    for file_info in all_files:
        dir_name = os.path.dirname(file_info['path'])
        if dir_name == '':
            dir_name = '/'
        
        if dir_name not in files_by_directory:
            files_by_directory[dir_name] = []
        
        files_by_directory[dir_name].append(file_info)
    
    return render_template('download_files.html', 
                          files_by_directory=files_by_directory,
                          title="Скачать файлы проекта")