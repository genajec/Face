"""
Маршрут для прямого скачивания установочных файлов для VPS
"""
import os
from flask import Blueprint, send_file, current_app, render_template

direct_download_bp = Blueprint('direct_download', __name__)

@direct_download_bp.route('/get_vps_install')
def download_vps_install():
    """
    Маршрут для скачивания установочного скрипта для VPS
    """
    script_path = os.path.join(os.getcwd(), 'create_vps_setup.sh')
    if os.path.exists(script_path):
        return send_file(
            script_path,
            as_attachment=True,
            download_name='setup_faceform_vps.sh',
            mimetype='text/x-sh'
        )
    else:
        return "Установочный скрипт не найден", 404

@direct_download_bp.route('/get_admin_script')
def download_admin_script():
    """
    Маршрут для скачивания скрипта создания администратора
    """
    script_path = os.path.join(os.getcwd(), 'create_admin.py')
    if os.path.exists(script_path):
        return send_file(
            script_path,
            as_attachment=True,
            download_name='create_admin.py',
            mimetype='text/x-python'
        )
    else:
        return "Скрипт создания администратора не найден", 404

@direct_download_bp.route('/direct/download')
def direct_download_page():
    """
    Страница для прямого скачивания установочных файлов
    """
    return render_template('direct_download.html')