import logging
import traceback
from flask import Blueprint, jsonify
from flask_login import current_user, login_required
from models import User

api_bp = Blueprint('api', __name__, url_prefix='/api')
logger = logging.getLogger('api')

@api_bp.route('/credits', methods=['GET'])
@login_required
def get_credits():
    """
    API-маршрут для получения текущего количества кредитов пользователя.
    Используется для обновления счетчика кредитов без перезагрузки страницы.
    """
    try:
        # Проверяем аутентификацию пользователя
        if not current_user.is_authenticated:
            logger.warning("Попытка получить кредиты неаутентифицированным пользователем")
            return jsonify({'success': False, 'error': 'Пользователь не авторизован'}), 401
            
        logger.debug(f"Получение баланса кредитов для пользователя {current_user.id}")
        
        # Получаем или создаем кредиты пользователя
        try:
            credit_record = current_user.get_or_create_credit()
            
            # Получаем баланс кредитов
            credits = current_user.get_credits_balance()
            logger.debug(f"Баланс кредитов пользователя {current_user.id}: {credits}")
            
            # Безопасная обработка даты обновления
            last_updated = None
            if hasattr(credit_record, 'last_updated') and credit_record.last_updated:
                try:
                    last_updated = credit_record.last_updated.strftime('%Y-%m-%d %H:%M:%S')
                except:
                    last_updated = None
            
            return jsonify({
                'success': True, 
                'credits': credits,
                'last_updated': last_updated
            })
        except Exception as inner_e:
            # Обрабатываем ошибки при получении кредитов, возвращаем резервное значение
            logger.warning(f"Ошибка при получении кредитов, возвращаем резервное значение: {inner_e}")
            return jsonify({
                'success': True,
                'credits': 0,
                'last_updated': None,
                'note': 'Значение кредитов недоступно, используется резервное значение'
            })
            
    except Exception as e:
        logger.error(f"Ошибка при получении кредитов: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        # Возвращаем 200 OK с сообщением об ошибке, чтобы избежать красных ошибок в консоли
        return jsonify({'success': False, 'error': str(e), 'credits': 0}), 200