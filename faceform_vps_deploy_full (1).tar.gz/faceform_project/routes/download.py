import os
import sys
from flask import Blueprint, send_file, current_app, send_from_directory

download_bp = Blueprint('download', __name__)

@download_bp.route('/download_file/<filename>')
def download_file(filename):
    """
    Маршрут для скачивания архивов проекта.
    Разрешает скачивание только tar.gz файлов из директории faceform_archives.
    """
    if not filename.endswith('.tar.gz'):
        return "Недопустимый тип файла", 400
    
    archives_dir = os.path.expanduser('~/faceform_archives')
    return send_from_directory(archives_dir, filename)

@download_bp.route('/download_full_project')
def download_full_project():
    """
    Маршрут для скачивания полного архива проекта (исходные файлы).
    """
    archives_dir = os.path.expanduser('~/faceform_archives')
    os.makedirs(archives_dir, exist_ok=True)
    
    # Имя файла для полного архива проекта
    project_archive_path = os.path.join(archives_dir, 'faceform_full_project.tar.gz')
    
    try:
        # Создаем архив с основными файлами сайта
        import tarfile
        import datetime
        import io
        import time
        
        # Удаляем существующий архив, если он есть
        if os.path.exists(project_archive_path):
            os.remove(project_archive_path)
        
        # Создаем новый архив
        with tarfile.open(project_archive_path, "w:gz") as tar:
            # Добавляем только самые важные файлы из проекта
            project_root = current_app.root_path
            
            # Список основных файлов для включения в архив
            essential_files = [
                'main.py', 
                'app.py', 
                'config.py', 
                'database.py',
                'face_analyzer.py',
                'routes/download.py',
                'routes/__init__.py',
                'models.py',
                'README.md',
                'utils/__init__.py'
            ]
            
            # Список важных директорий (только основные файлы)
            important_dirs = {
                'templates': 5,  # Максимальное количество файлов
                'static/css': 3,
                'static/js': 3
            }
            
            # Добавляем основные файлы
            for file_path in essential_files:
                full_path = os.path.join(project_root, file_path)
                if os.path.exists(full_path) and os.path.isfile(full_path):
                    try:
                        tar.add(full_path, arcname=os.path.join("faceform_project", file_path))
                        current_app.logger.info(f"Добавлен файл: {file_path}")
                    except Exception as e:
                        current_app.logger.warning(f"Не удалось добавить {file_path}: {str(e)}")
            
            # Добавляем файлы из важных директорий
            for dir_path, max_files in important_dirs.items():
                full_dir_path = os.path.join(project_root, dir_path)
                if os.path.exists(full_dir_path) and os.path.isdir(full_dir_path):
                    try:
                        file_count = 0
                        for filename in os.listdir(full_dir_path):
                            if file_count >= max_files:
                                break
                                
                            file_path = os.path.join(full_dir_path, filename)
                            if os.path.isfile(file_path):
                                rel_path = os.path.join(dir_path, filename)
                                tar.add(file_path, arcname=os.path.join("faceform_project", rel_path))
                                file_count += 1
                                current_app.logger.info(f"Добавлен файл: {rel_path}")
                    except Exception as e:
                        current_app.logger.warning(f"Не удалось добавить файлы из {dir_path}: {str(e)}")
            
            # Добавляем README в архив
            readme_content = f"""# FaceForm - Полный архив проекта

Создан: {datetime.datetime.now()}

Этот архив содержит основные файлы проекта FaceForm (неполный архив из-за ограничений сервера).
Для получения полной версии проекта, пожалуйста, загрузите код с GitHub.

Для запуска проекта:
1. Установите необходимые зависимости: pip install -r requirements.txt
2. Настройте переменные окружения согласно .env.example
3. Настройте базу данных PostgreSQL
4. Запустите сервер: python main.py или gunicorn main:app

Примечание: этот архив не содержит переменные окружения и базу данных.
Для полного переноса проекта используйте скрипт export_db_and_env.py.
"""
            readme_info = tarfile.TarInfo(name="faceform_project/README.txt")
            readme_bytes = readme_content.encode('utf-8')
            readme_info.size = len(readme_bytes)
            readme_info.mtime = int(time.time())
            tar.addfile(readme_info, io.BytesIO(readme_bytes))
        
        current_app.logger.info(f"Архив проекта успешно создан: {project_archive_path}")
        
        return send_file(
            project_archive_path,
            as_attachment=True,
            download_name='faceform_full_project.tar.gz'
        )
        
    except Exception as e:
        current_app.logger.error(f"Ошибка при создании архива проекта: {str(e)}")
        return f"Ошибка при создании архива проекта: {str(e)}", 500

@download_bp.route('/download_export')
def download_export():
    """
    Маршрут для скачивания архива с экспортом базы данных и переменных окружения.
    """
    archives_dir = os.path.expanduser('~/faceform_archives')
    os.makedirs(archives_dir, exist_ok=True)
    
    # Имя файла для архива с экспортом
    export_archive_path = os.path.join(archives_dir, 'faceform_export.tar.gz')
    
    # Удаляем существующий архив, если он есть
    if os.path.exists(export_archive_path):
        os.remove(export_archive_path)
    
    try:
        # Импортируем необходимые модули
        import tarfile
        import io
        import json
        import datetime
        import psycopg2
        import time
        
        # Получаем переменные окружения
        env_vars = {}
        
        # Обязательные переменные для базы данных
        database_vars = [
            "DATABASE_URL", "PGHOST", "PGPORT", "PGUSER", 
            "PGPASSWORD", "PGDATABASE"
        ]
        
        # Другие важные переменные
        other_vars = [
            "FLASK_SECRET_KEY", "SESSION_SECRET", "STRIPE_PUBLIC_KEY", 
            "STRIPE_SECRET_KEY", "GOOGLE_OAUTH_CLIENT_ID", 
            "GOOGLE_OAUTH_CLIENT_SECRET", "LIGHTX_API_KEY"
        ]
        
        # Добавляем переменные из os.environ
        for var in database_vars + other_vars:
            if var in os.environ:
                env_vars[var] = os.environ[var]
        
        # Создаем архив с экспортом
        with tarfile.open(export_archive_path, "w:gz") as tar:
            # 1. Экспорт базы данных
            try:
                # Подключаемся к базе данных
                conn = None
                if "DATABASE_URL" in env_vars:
                    conn = psycopg2.connect(env_vars["DATABASE_URL"])
                
                if conn:
                    with conn:
                        with conn.cursor() as cursor:
                            # Получаем список всех таблиц
                            cursor.execute("""
                                SELECT tablename FROM pg_tables 
                                WHERE schemaname = 'public'
                            """)
                            tables = [row[0] for row in cursor.fetchall()]
                            
                            # Создаем файл SQL
                            sql_content = f"-- FaceForm Database Export\n-- Generated: {datetime.datetime.now()}\n\n"
                            
                            # Для каждой таблицы получаем CREATE TABLE и INSERT statements
                            for table in tables:
                                # Получаем структуру таблицы
                                cursor.execute(f"""
                                    SELECT column_name, data_type, 
                                        CASE WHEN character_maximum_length IS NOT NULL 
                                            THEN '(' || character_maximum_length || ')' 
                                            ELSE '' 
                                        END as length,
                                        is_nullable
                                    FROM information_schema.columns
                                    WHERE table_name = %s
                                    ORDER BY ordinal_position
                                """, (table,))
                                
                                columns = cursor.fetchall()
                                
                                # Создаем CREATE TABLE
                                create_table = f"CREATE TABLE IF NOT EXISTS {table} (\n"
                                for i, (col_name, data_type, length, is_nullable) in enumerate(columns):
                                    create_table += f"    {col_name} {data_type}{length}"
                                    if is_nullable == "NO":
                                        create_table += " NOT NULL"
                                    if i < len(columns) - 1:
                                        create_table += ","
                                    create_table += "\n"
                                create_table += ");\n\n"
                                
                                sql_content += create_table
                                
                                # Получаем данные
                                try:
                                    cursor.execute(f"SELECT * FROM {table}")
                                    rows = cursor.fetchall()
                                    
                                    if rows:
                                        # Получаем имена колонок
                                        col_names = [desc[0] for desc in cursor.description]
                                        
                                        # Создаем INSERT для каждой строки
                                        for row in rows:
                                            values = []
                                            for val in row:
                                                if val is None:
                                                    values.append("NULL")
                                                elif isinstance(val, (int, float)):
                                                    values.append(str(val))
                                                else:
                                                    val_str = str(val).replace("'", "''")
                                                    values.append(f"'{val_str}'")
                                            
                                            sql_content += f"INSERT INTO {table} ({', '.join(col_names)}) VALUES ({', '.join(values)});\n"
                                        
                                        sql_content += "\n"
                                except Exception as e:
                                    current_app.logger.error(f"Ошибка при получении данных таблицы {table}: {str(e)}")
                    
                    # Добавляем SQL в архив
                    db_info = tarfile.TarInfo(name="database_export.sql")
                    db_bytes = sql_content.encode('utf-8')
                    db_info.size = len(db_bytes)
                    tar.addfile(db_info, io.BytesIO(db_bytes))
                else:
                    # Создаем пустой SQL файл если не удалось подключиться
                    db_content = f"""-- FaceForm Database Export (Empty)
-- Generated: {datetime.datetime.now()}

-- Не удалось подключиться к базе данных.
-- Пожалуйста, проверьте ваше соединение и DATABASE_URL.
"""
                    db_info = tarfile.TarInfo(name="database_export.sql")
                    db_bytes = db_content.encode('utf-8')
                    db_info.size = len(db_bytes)
                    tar.addfile(db_info, io.BytesIO(db_bytes))
            
            except Exception as e:
                current_app.logger.error(f"Ошибка при экспорте базы данных: {str(e)}")
                # Создаем файл с ошибкой
                db_content = f"""-- FaceForm Database Export (Error)
-- Generated: {datetime.datetime.now()}

-- Ошибка при экспорте базы данных: {str(e)}
-- Пожалуйста, проверьте ваше соединение и DATABASE_URL.
"""
                db_info = tarfile.TarInfo(name="database_export.sql")
                db_bytes = db_content.encode('utf-8')
                db_info.size = len(db_bytes)
                tar.addfile(db_info, io.BytesIO(db_bytes))
            
            # 2. Экспорт переменных окружения в .env файл
            env_content = f"# FaceForm Environment Variables\n# Generated: {datetime.datetime.now()}\n\n"
            for key, value in env_vars.items():
                env_content += f"{key}={value}\n"
                
            env_info = tarfile.TarInfo(name=".env")
            env_bytes = env_content.encode('utf-8')
            env_info.size = len(env_bytes)
            tar.addfile(env_info, io.BytesIO(env_bytes))
            
            # 3. Экспорт переменных окружения в JSON
            env_json_info = tarfile.TarInfo(name="env_vars.json")
            env_json_content = json.dumps(env_vars, indent=2)
            env_json_bytes = env_json_content.encode('utf-8')
            env_json_info.size = len(env_json_bytes)
            tar.addfile(env_json_info, io.BytesIO(env_json_bytes))
            
            # 4. Добавляем README
            readme_content = f"""# FaceForm Project Export

Generated: {datetime.datetime.now()}

This archive contains:
1. database_export.sql - SQL dump of the database
2. .env - Environment variables file
3. env_vars.json - Environment variables in JSON format

Instructions for import:
1. Create a new PostgreSQL database
2. Import the database_export.sql file into your new database
3. Configure the environment variables in your new project

See IMPORT_GUIDE.md for detailed instructions.
"""
            
            readme_info = tarfile.TarInfo(name="README.txt")
            readme_bytes = readme_content.encode('utf-8')
            readme_info.size = len(readme_bytes)
            tar.addfile(readme_info, io.BytesIO(readme_bytes))
            
            # 5. Добавляем инструкцию по импорту
            guide_content = """# FaceForm Import Guide

This guide will help you to import the FaceForm project to a new environment.

## 1. Database Import

### 1.1. Create a new PostgreSQL database

```bash
# Login to PostgreSQL
sudo -u postgres psql

# Create a new database
CREATE DATABASE faceform;

# Create a new user (optional)
CREATE USER faceform_user WITH PASSWORD 'your_password';

# Grant privileges
GRANT ALL PRIVILEGES ON DATABASE faceform TO faceform_user;
```

### 1.2. Import the database dump

```bash
# Option 1: Using psql
psql -U faceform_user -d faceform -f database_export.sql

# Option 2: Using pg_restore
pg_restore -U faceform_user -d faceform database_export.sql
```

## 2. Environment Variables Setup

Copy the .env file to the root directory of your project:

```bash
cp .env /path/to/your/project/
```

Make sure to update the `DATABASE_URL` and other database-related variables to match your new database configuration.
"""

            guide_info = tarfile.TarInfo(name="IMPORT_GUIDE.md")
            guide_bytes = guide_content.encode('utf-8')
            guide_info.size = len(guide_bytes)
            tar.addfile(guide_info, io.BytesIO(guide_bytes))
        
        current_app.logger.info(f"Архив экспорта успешно создан: {export_archive_path}")
        
        return send_file(
            export_archive_path,
            as_attachment=True,
            download_name='faceform_export.tar.gz'
        )
    except Exception as e:
        current_app.logger.error(f"Ошибка при создании архива экспорта: {str(e)}")
        return f"Ошибка при создании архива экспорта: {str(e)}", 500