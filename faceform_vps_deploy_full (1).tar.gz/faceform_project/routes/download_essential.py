import os
from flask import Blueprint, send_from_directory, current_app, send_file

download_essential_bp = Blueprint('download_essential', __name__)

@download_essential_bp.route('/download_essential')
def download_essential():
    """
    Маршрут для скачивания архива с основными файлами проекта (меньшего размера).
    """
    project_archive = os.path.join(current_app.root_path, 'faceform_essential.tar.gz')
    
    if os.path.exists(project_archive):
        return send_file(
            project_archive,
            as_attachment=True,
            download_name='faceform_essential.tar.gz'
        )
    else:
        return "Архив с основными файлами не найден", 404