import os
from flask import Blueprint, send_file, current_app, abort

download_file_bp = Blueprint('download_file', __name__)

@download_file_bp.route('/download_file/<path:file_path>')
def download_single_file(file_path):
    """
    Маршрут для скачивания отдельных файлов проекта.
    """
    # Проверяем, что путь не содержит попыток выхода за рамки корневой директории
    normalized_path = os.path.normpath(file_path)
    if normalized_path.startswith('..') or normalized_path.startswith('/'):
        return abort(403, "Запрещенный путь к файлу")
    
    # Создаем полный путь к файлу
    full_path = os.path.join(current_app.root_path, normalized_path)
    
    # Проверяем существование файла
    if not os.path.isfile(full_path):
        return abort(404, "Файл не найден")
    
    # Отправляем файл
    return send_file(full_path, as_attachment=False)