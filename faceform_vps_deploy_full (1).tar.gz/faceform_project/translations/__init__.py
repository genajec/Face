import json
import os
from flask import request, session

class Translation:
    """
    Класс для управления переводами сайта на разные языки.
    Загружает JSON-файлы с переводами и предоставляет доступ к ним.
    """
    def __init__(self, translations_dir='translations'):
        self.translations_dir = translations_dir
        self.translations = {}
        self.available_langs = []
        self.default_lang = 'ru'
        self._load_translations()
    
    def _load_translations(self):
        """Загружает все доступные переводы из директории translations"""
        for filename in os.listdir(self.translations_dir):
            if filename.endswith('.json'):
                lang_code = filename.split('.')[0]
                file_path = os.path.join(self.translations_dir, filename)
                
                with open(file_path, 'r', encoding='utf-8') as f:
                    self.translations[lang_code] = json.load(f)
                    self.available_langs.append(lang_code)
    
    def get_current_lang(self):
        """Возвращает текущий язык из сессии или языка браузера, или язык по умолчанию"""
        if 'lang' in session:
            return session['lang']
        
        # Определяем предпочтительный язык из заголовка Accept-Language
        if request.accept_languages:
            for lang in request.accept_languages.values():
                if lang[:2] in self.available_langs:
                    return lang[:2]
        
        return self.default_lang
    
    def set_lang(self, lang_code):
        """Устанавливает язык в сессии"""
        if lang_code in self.available_langs:
            session['lang'] = lang_code
            return True
        return False
    
    def get_text(self, key_path, lang=None):
        """
        Получает текст по ключу для указанного языка.
        
        Args:
            key_path (str): Путь к ключу в формате 'section.subsection.key'
            lang (str, optional): Код языка. Если не указан, используется текущий язык.
            
        Returns:
            str: Переведенный текст или ключ, если перевод не найден
        """
        if lang is None:
            lang = self.get_current_lang()
        
        if lang not in self.translations:
            lang = self.default_lang
        
        # Разбиваем путь ключа на части
        keys = key_path.split('.')
        
        # Получаем перевод, двигаясь по дереву JSON
        translation = self.translations[lang]
        try:
            for key in keys:
                translation = translation[key]
            
            return translation
        except (KeyError, TypeError):
            # Если ключ не найден, возвращаем сам ключ
            return key_path
    
    def get_languages(self):
        """Возвращает список доступных языков"""
        return self.available_langs


# Создаем глобальный экземпляр для использования во всем приложении
translator = Translation()

# Функция для удобного доступа к переводам из шаблонов
def t(key_path):
    """Функция-обертка для получения перевода из шаблонов"""
    return translator.get_text(key_path)