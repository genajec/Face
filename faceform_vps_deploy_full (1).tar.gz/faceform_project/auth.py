from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import re
import secrets
import logging
from functools import wraps
from app import db, login_manager
from models import User, Credit, Transaction
from forms import LoginForm, RegisterForm, ResetPasswordForm, ConfirmResetPasswordForm

# Декоратор для перенаправления неавторизованных пользователей на страницу регистрации
def auth_required(func):
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if not current_user.is_authenticated:
            # Сохраняем URL, чтобы вернуться к нему после авторизации
            next_url = request.url
            flash('Пожалуйста, зарегистрируйтесь или войдите, чтобы продолжить', 'info')
            return redirect(url_for('auth.register', next=next_url))
        return func(*args, **kwargs)
    return decorated_view

# Настройка логирования
logger = logging.getLogger(__name__)

auth = Blueprint('auth', __name__)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
        
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            # Авторизуем пользователя
            login_user(user, remember=form.remember.data)
            
            # Устанавливаем сессию как постоянную
            session.permanent = True
            
            # Добавляем идентификатор пользователя в сессию для дополнительной надежности
            session['user_id'] = user.id
            logger.info(f"Пользователь {user.id} авторизован с постоянной сессией")
            
            next_page = request.args.get('next')
            return redirect(next_page or url_for('main.dashboard'))
        else:
            flash('Проверьте email и пароль', 'danger')
    
    return render_template('auth/login.html', form=form)

@auth.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
        
    form = RegisterForm()
    if form.validate_on_submit():
        # Проверяем, существует ли пользователь с таким email или именем пользователя
        # но игнорируем ошибки валидации, так как они уже обрабатываются в форме
        # и данный участок кода может вызывать ложные срабатывания
        
        # Создаем нового пользователя
        user = User(
            email=form.email.data,
            username=form.username.data
        )
        user.set_password(form.password.data)
        
        # Сохраняем пользователя в базе данных
        db.session.add(user)
        db.session.commit()
        
        # Создаем запись для кредитов
        credit = Credit(user_id=user.id, balance=0)
        db.session.add(credit)
        db.session.commit()
        
        # Вход в систему после регистрации с постоянной сессией
        login_user(user, remember=True)
        
        # Устанавливаем сессию как постоянную
        session.permanent = True
        
        # Добавляем идентификатор пользователя в сессию для дополнительной надежности
        session['user_id'] = user.id
        logger.info(f"Новый пользователь {user.id} авторизован с постоянной сессией")
        
        flash('Регистрация успешна! Добро пожаловать.', 'success')
        return redirect(url_for('main.dashboard'))
    
    return render_template('auth/register.html', form=form)

@auth.route('/logout')
@login_required
def logout():
    # Получаем id текущего пользователя перед выходом
    user_id = current_user.id if current_user.is_authenticated else None
    
    # Выходим из системы
    logout_user()
    
    # Очищаем сессию
    if 'user_id' in session:
        session.pop('user_id')
    if 'user_email' in session:
        session.pop('user_email')
    if 'is_google_auth' in session:
        session.pop('is_google_auth')
    if 'next' in session:
        session.pop('next')
    
    # Сбрасываем все cookie для полного выхода
    flash('Вы успешно вышли из системы.', 'success')
    
    # Логирование выхода
    if user_id:
        logger.info(f"Пользователь {user_id} вышел из системы")
    
    response = redirect(url_for('main.index'))
    
    # Устанавливаем срок действия cookie сессии в прошлое,
    # чтобы браузер удалил его
    response.delete_cookie('session')
    response.delete_cookie('remember_token')
    
    return response

@auth.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    form = ResetPasswordForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            # Импортируем сервис отправки писем
            from email_service import send_password_reset_email
            
            # Отправляем email для сброса пароля
            if send_password_reset_email(user):
                flash('Инструкции по сбросу пароля отправлены на ваш email. Проверьте вашу почту.', 'success')
                logger.info(f"Запрос на сброс пароля для пользователя {user.id} ({user.email}) отправлен")
            else:
                flash('Произошла ошибка при отправке письма. Пожалуйста, попробуйте позже.', 'danger')
                logger.error(f"Ошибка при отправке письма для сброса пароля пользователю {user.id} ({user.email})")
            
            # В любом случае перенаправляем на страницу входа, чтобы не раскрывать существование аккаунта
            return redirect(url_for('auth.login'))
        else:
            # Не сообщаем пользователю, что такого email нет в базе, для безопасности
            flash('Если указанный email зарегистрирован в системе, на него будут отправлены инструкции по сбросу пароля', 'info')
            logger.warning(f"Попытка сброса пароля для несуществующего email: {form.email.data}")
            return redirect(url_for('auth.login'))
    
    return render_template('auth/reset_password.html', form=form)

@auth.route('/confirm-reset/<token>', methods=['GET', 'POST'])
def confirm_reset(token):
    # Импортируем функцию проверки токена
    from email_service import verify_reset_token
    
    # Проверяем токен
    user = verify_reset_token(token)
    if not user:
        flash('Недействительная или истекшая ссылка для сброса пароля', 'danger')
        logger.warning(f"Попытка использования недействительного токена сброса пароля: {token}")
        return redirect(url_for('auth.reset_password'))
    
    form = ConfirmResetPasswordForm()
    if form.validate_on_submit():
        # Устанавливаем новый пароль
        user.set_password(form.password.data)
        
        # Очищаем токен сброса после использования
        user.reset_token = None
        user.reset_token_expires = None
        
        db.session.commit()
        logger.info(f"Пароль успешно сброшен для пользователя {user.id} ({user.email})")
        
        flash('Ваш пароль был успешно изменен! Теперь вы можете войти в систему.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/confirm_reset.html', form=form)

def create_user_from_payment(email, payment_id=None, transaction=None):
    """
    Утилитарная функция для создания пользователя после оплаты.
    Может быть вызвана как из веб-интерфейса, так и из вебхука.
    
    Args:
        email (str): Email пользователя
        payment_id (str, optional): ID платежа в Stripe
        transaction (Transaction, optional): Объект транзакции
        
    Returns:
        tuple: (User, str) - созданный пользователь и временный пароль
    """
    logger.info(f"Создание пользователя из платежа: email={email}, payment_id={payment_id}")
    
    if not email:
        logger.error("Email не указан при создании пользователя из платежа")
        return None, None
    
    # Проверяем, существует ли пользователь с таким email
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        logger.info(f"Пользователь с email {email} уже существует (id={existing_user.id})")
        
        # Если есть транзакция, привязываем её к пользователю
        if transaction and transaction.user_id is None:
            transaction.user_id = existing_user.id
            db.session.commit()
            logger.info(f"Транзакция {transaction.id} привязана к пользователю {existing_user.id}")
        
        return existing_user, None
    
    # Генерируем надежный временный пароль
    temp_password = secrets.token_urlsafe(12)
    
    # Формируем имя пользователя из email
    base_username = email.split('@')[0]
    username = base_username
    
    # Проверяем уникальность имени пользователя
    counter = 1
    while User.query.filter_by(username=username).first():
        username = f"{base_username}{counter}"
        counter += 1
    
    # Создаем нового пользователя
    user = User(
        email=email,
        username=username
    )
    user.set_password(temp_password)
    
    # Сохраняем пользователя
    db.session.add(user)
    db.session.commit()
    logger.info(f"Создан новый пользователь: id={user.id}, email={email}")
    
    # Создаем запись кредитов для пользователя
    credit = Credit(user_id=user.id, balance=0)
    db.session.add(credit)
    db.session.commit()
    logger.info(f"Создана запись кредитов для пользователя {user.id}")
    
    # Если есть транзакция, привязываем её к пользователю
    if transaction and transaction.user_id is None:
        transaction.user_id = user.id
        db.session.commit()
        logger.info(f"Транзакция {transaction.id} привязана к пользователю {user.id}")
    
    return user, temp_password

@auth.route('/create-from-payment', methods=['GET', 'POST'])
def create_from_payment():
    """
    Маршрут для создания учетной записи после оплаты.
    Используется в процессе Stripe Checkout.
    """
    email = request.args.get('email')
    payment_id = request.args.get('payment_id')
    
    if not email or not payment_id:
        flash('Недостаточно данных для создания учетной записи', 'danger')
        logger.error(f"Попытка создания пользователя без email или payment_id: {email=}, {payment_id=}")
        return redirect(url_for('main.index'))
    
    # Находим транзакцию если есть payment_id
    transaction = None
    if payment_id:
        transaction = Transaction.query.filter_by(payment_id=payment_id).first()
        if not transaction:
            logger.warning(f"Транзакция с payment_id={payment_id} не найдена")
    
    # Создаем пользователя или получаем существующего
    user, temp_password = create_user_from_payment(email, payment_id, transaction)
    
    if not user:
        flash('Не удалось создать учетную запись', 'danger')
        return redirect(url_for('main.index'))
    
    # Если пользователь уже существовал
    if not temp_password:
        login_user(user, remember=True)
        
        # Устанавливаем сессию как постоянную
        session.permanent = True
        
        # Добавляем идентификатор пользователя в сессию для дополнительной надежности
        session['user_id'] = user.id
        logger.info(f"Существующий пользователь {user.id} авторизован из формы оплаты с постоянной сессией")
        
        flash('Вы вошли в существующий аккаунт', 'info')
        
        # Если есть payment_id, перенаправляем на страницу успешной оплаты
        if payment_id:
            return redirect(url_for('payments.checkout_success', payment_id=payment_id))
        return redirect(url_for('main.dashboard'))
    
    # Если создан новый пользователь
    login_user(user, remember=True)
    
    # Устанавливаем сессию как постоянную
    session.permanent = True
    
    # Добавляем идентификатор пользователя в сессию для дополнительной надежности
    session['user_id'] = user.id
    logger.info(f"Новый пользователь {user.id} авторизован из формы оплаты с постоянной сессией")
    
    # Сохраняем временный пароль в сессии для показа пользователю
    # В реальном приложении лучше отправить по email
    session['temp_password'] = temp_password
    
    flash('Учетная запись успешно создана! Ваш временный пароль будет показан после завершения оплаты.', 'success')
    
    # Если есть payment_id, перенаправляем на страницу успешной оплаты
    if payment_id:
        return redirect(url_for('payments.checkout_success', payment_id=payment_id))
    return redirect(url_for('main.dashboard'))