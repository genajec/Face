from db import db
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=True)
    telegram_id = db.Column(db.BigInteger, unique=True, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    verified = db.Column(db.Boolean, default=False)
    last_login = db.Column(db.DateTime, nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    is_temporary = db.Column(db.Boolean, default=False)
    
    # Поля для сброса пароля
    reset_token = db.Column(db.String(100), nullable=True)
    reset_token_expires = db.Column(db.DateTime, nullable=True)
    
    # Поля для Google авторизации
    is_google_auth = db.Column(db.Boolean, default=False)  # Указывает, что пользователь использует Google авторизацию
    email_verified = db.Column(db.Boolean, default=False)  # Email верифицирован через Google
    profile_picture = db.Column(db.String(255), nullable=True)  # URL фото профиля из Google
    
    # Связь с кредитами
    credits = db.relationship('Credit', backref='user', lazy=True)
    
    # Связь с транзакциями
    transactions = db.relationship('Transaction', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_credits_balance(self):
        """Получить текущий баланс кредитов пользователя"""
        try:
            if not self.credits:
                return 0
            return self.credits[0].balance if self.credits else 0
        except Exception as e:
            # Логирование ошибки
            import logging
            logger = logging.getLogger('models')
            logger.error(f"Ошибка при получении баланса кредитов для пользователя {self.id}: {e}")
            
            # Резервный вариант - попробовать получить баланс напрямую из БД
            try:
                from db import db
                from sqlalchemy import text
                # Используем SQL-запрос напрямую
                sql = text("SELECT balance FROM credit WHERE user_id = :user_id LIMIT 1")
                result = db.session.execute(sql, {"user_id": self.id}).fetchone()
                if result:
                    return result[0]
            except Exception as db_error:
                logger.error(f"Ошибка при прямом запросе баланса кредитов: {db_error}")
            
            # Если все попытки не удались, возвращаем 0
            return 0
        
    def get_or_create_credit(self):
        """Получить существующую запись кредитов или создать новую"""
        from db import db
        try:
            credit = Credit.query.filter_by(user_id=self.id).first()
            if not credit:
                credit = Credit(user_id=self.id, balance=0)
                db.session.add(credit)
                db.session.commit()
            return credit
        except Exception as e:
            # Логирование ошибки
            import logging
            logger = logging.getLogger('models')
            logger.error(f"Ошибка при получении/создании кредитов для пользователя {self.id}: {e}")
            
            # Повторная попытка создать запись в случае ошибки
            try:
                # Откатываем предыдущую транзакцию, если она была
                db.session.rollback()
                # Повторная попытка получить запись
                credit = Credit.query.filter_by(user_id=self.id).first()
                if credit:
                    return credit
                
                # Создаем новую запись
                credit = Credit(user_id=self.id, balance=0) 
                db.session.add(credit)
                db.session.commit()
                return credit
            except Exception as retry_e:
                logger.error(f"Повторная ошибка при создании кредитов: {retry_e}")
                # Возвращаем объект-заглушку с базовыми свойствами
                class FallbackCredit:
                    def __init__(self):
                        self.balance = 0
                        self.last_updated = None
                    
                    def deduct_credits(self, amount):
                        """Заглушка для метода списания кредитов"""
                        return False  # Всегда возвращаем False, так как нет реальных кредитов
                return FallbackCredit()
        
    def is_administrator(self):
        """Проверить, является ли пользователь администратором"""
        try:
            return bool(self.is_admin)
        except:
            return False
    
    def deduct_credits(self, amount, service_name=None):
        """Списать кредиты с баланса пользователя и создать запись транзакции
        
        Args:
            amount (int): Количество кредитов для списания
            service_name (str, optional): Название услуги для транзакции
            
        Returns:
            bool: True если списание успешно, False если недостаточно кредитов
        """
        from db import db
        
        # Получаем или создаем запись кредитов
        credit = self.get_or_create_credit()
        
        # Проверяем достаточно ли кредитов
        if credit.balance < amount:
            return False
            
        # Списываем кредиты
        credit.deduct_credits(amount)
        
        # Создаем запись о транзакции
        if service_name:
            transaction = Transaction(
                user_id=self.id,
                amount=0,  # Бесплатная транзакция для использования услуги
                credits=-amount,  # Отрицательное значение для списания
                payment_status='completed',
                payment_method='service_usage',
                package_id=service_name
            )
            db.session.add(transaction)
            
        db.session.commit()
        return True


class Credit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    balance = db.Column(db.Integer, default=0)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
    
    def add_credits(self, amount):
        """Добавить кредиты пользователю"""
        self.balance += amount
        self.last_updated = datetime.utcnow()
        return self.balance
    
    def deduct_credits(self, amount):
        """Списать кредиты с баланса пользователя"""
        if self.balance >= amount:
            self.balance -= amount
            self.last_updated = datetime.utcnow()
            return True
        return False


class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)  # Сумма в USD
    credits = db.Column(db.Integer, nullable=False)  # Количество кредитов
    payment_id = db.Column(db.String(255), unique=True, nullable=True)  # ID платежа в Stripe
    payment_status = db.Column(db.String(50), default='pending')  # Статус платежа
    payment_method = db.Column(db.String(50), default='stripe')  # Метод оплаты
    package_id = db.Column(db.String(50), nullable=True)  # ID выбранного пакета
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def update_status(self, status):
        """Обновить статус платежа"""
        self.payment_status = status
        self.updated_at = datetime.utcnow()
        return True


# Определим словарь пакетов кредитов аналогично тому, что в телеграм боте
CREDIT_PACKAGES = {
    "basic": {
        "id": "basic",
        "description": "Базовый",
        "description_en": "Basic",
        "credits": 10,
        "price": 0.40,
        "features": ["Доступ ко всем функциям", "Без ограничения по времени"]
    },
    "standard": {
        "id": "standard",
        "description": "Стандарт",
        "description_en": "Standard",
        "credits": 20,
        "price": 1.70,
        "features": ["Доступ ко всем функциям", "Без ограничения по времени", "Приоритетная обработка"]
    },
    "premium": {
        "id": "premium",
        "description": "Премиум",
        "description_en": "Premium",
        "credits": 40,
        "price": 3.20,
        "features": ["Доступ ко всем функциям", "Без ограничения по времени", "Приоритетная обработка", "Расширенные отчеты", "Поддержка в приоритетном режиме"]
    }
}

# Цены услуг в кредитах
SERVICE_COSTS = {
    "face_shape": 1,               # Анализ формы лица (после 5 бесплатных использований)
    "face_shape_analysis": 1,      # Анализ формы лица через Web API (после 5 бесплатных использований)
    "hairstyle": 2,                # Примерка причесок
    "virtual_hairstyle": 2,        # Примерка причесок через Web API
    "symmetry": 2,                 # Проверка симметрии (устаревшая функция)
    "background": 0.5,             # Изменение фона
    "background_removal": 0.5,     # Удаление фона
    "beauty": 1,                   # Анализ привлекательности
    "beauty_analysis": 1,          # Анализ привлекательности через Web API
    "text_to_image": 1,            # Генерация изображения по тексту
    "ai_replace": 1,               # Замена объектов на изображении с помощью AI
    "video": 5,                    # Анализ видео
    "video_analysis": 5            # Анализ видео (веб-версия)
}

# Модель для отслеживания использования кредитов
class CreditUsage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Integer, nullable=False)  # Количество использованных кредитов
    feature = db.Column(db.String(100), nullable=True)  # Название функции (face_shape_analysis, beauty_analysis и т.д.)
    description = db.Column(db.String(255), nullable=True)  # Описание операции
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Связь с пользователем
    user = db.relationship('User', backref=db.backref('credit_usages', lazy=True))