import os
import logging
import secrets
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from flask import current_app, url_for
from models import User, db

# Настройка логирования
logger = logging.getLogger(__name__)

def send_email(to_email, subject, html_content=None, text_content=None):
    """
    Отправляет email с помощью встроенной библиотеки SMTP Python
    
    Args:
        to_email (str): Email получателя
        subject (str): Тема письма
        html_content (str): HTML содержимое (опционально)
        text_content (str): Текстовое содержимое (опционально)
        
    Returns:
        bool: True если письмо отправлено успешно, False в случае ошибки
    """
    # Получаем настройки SMTP из переменных окружения
    smtp_server = os.environ.get('SMTP_SERVER', 'smtp.gmail.com')
    smtp_port = int(os.environ.get('SMTP_PORT', 587))
    smtp_username = os.environ.get('SMTP_USERNAME')
    smtp_password = os.environ.get('SMTP_PASSWORD')
    smtp_sender = os.environ.get('SMTP_SENDER', 'no-reply@faceform.ai')
    
    if not smtp_username or not smtp_password:
        logger.warning("Настройки SMTP не заданы. Отправка письма невозможна.")
        return False
    
    try:
        # Создание MIMEMultipart объекта
        message = MIMEMultipart("alternative")
        message["Subject"] = subject
        message["From"] = smtp_sender
        message["To"] = to_email
        
        # Добавление текстового и HTML контента
        if text_content:
            part1 = MIMEText(text_content, "plain")
            message.attach(part1)
            
        if html_content:
            part2 = MIMEText(html_content, "html")
            message.attach(part2)
        
        # Настройка SMTP-сервера
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()  # Безопасное соединение
        server.login(smtp_username, smtp_password)
        
        # Отправка письма
        server.send_message(message)
        server.quit()
        
        logger.info(f"Письмо успешно отправлено на {to_email}")
        return True
        
    except Exception as e:
        logger.error(f"Исключение при отправке письма: {str(e)}")
        return False

def generate_reset_token(user, expires_in=3600):
    """
    Генерирует токен для сброса пароля и сохраняет его в базе данных
    
    Args:
        user (User): Объект пользователя
        expires_in (int): Время действия токена в секундах (по умолчанию 1 час)
        
    Returns:
        str: Сгенерированный токен или None в случае ошибки
    """
    if not user:
        return None
    
    # Генерируем случайный токен
    token = secrets.token_urlsafe(32)
    
    # Устанавливаем время истечения
    expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
    
    # Сохраняем токен и время истечения в базе данных
    try:
        user.reset_token = token
        user.reset_token_expires = expires_at
        db.session.commit()
        logger.info(f"Создан токен сброса пароля для пользователя {user.id}")
        return token
    except Exception as e:
        logger.error(f"Ошибка при создании токена сброса пароля: {str(e)}")
        db.session.rollback()
        return None

def verify_reset_token(token):
    """
    Проверяет токен сброса пароля
    
    Args:
        token (str): Токен для проверки
        
    Returns:
        User: Объект пользователя, которому принадлежит токен, или None если токен недействителен
    """
    if not token:
        return None
    
    # Ищем пользователя с указанным токеном
    user = User.query.filter_by(reset_token=token).first()
    
    # Проверяем наличие пользователя и срок действия токена
    if user and user.reset_token_expires:
        if user.reset_token_expires > datetime.utcnow():
            return user
        else:
            logger.warning(f"Попытка использования истекшего токена для пользователя {user.id}")
    
    return None

def send_password_reset_email(user):
    """
    Отправляет email для сброса пароля
    
    Args:
        user (User): Объект пользователя
        
    Returns:
        bool: True если письмо отправлено успешно, False в случае ошибки
    """
    if not user or not user.email:
        logger.error("Невозможно отправить email для сброса пароля: пользователь или email не указаны")
        return False
    
    # Генерируем токен
    token = generate_reset_token(user)
    if not token:
        logger.error(f"Не удалось сгенерировать токен для пользователя {user.id}")
        return False
    
    # Формируем URL для сброса пароля 
    # Используем _external=True для абсолютного URL-адреса
    reset_url = url_for('auth.confirm_reset', token=token, _external=True)
    
    # Тема письма
    subject = "Сброс пароля для FaceForm"
    
    # Содержимое письма в HTML формате
    html_content = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
            .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ background-color: #4A6FA5; color: white; padding: 10px; text-align: center; }}
            .content {{ padding: 20px; }}
            .button {{ display: inline-block; background-color: #4A6FA5; color: white; text-decoration: none; padding: 10px 20px; margin: 20px 0; border-radius: 5px; }}
            .footer {{ margin-top: 30px; font-size: 12px; color: #777; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>FaceForm</h1>
            </div>
            <div class="content">
                <h2>Сброс пароля</h2>
                <p>Здравствуйте, {user.username or user.email.split('@')[0]}!</p>
                <p>Мы получили запрос на сброс пароля для вашей учетной записи FaceForm.</p>
                <p>Для сброса пароля нажмите на кнопку ниже:</p>
                <p><a href="{reset_url}" class="button">Сбросить пароль</a></p>
                <p>Если кнопка не работает, скопируйте и вставьте следующую ссылку в адресную строку браузера:</p>
                <p>{reset_url}</p>
                <p>Ссылка действительна в течение 1 часа.</p>
                <p>Если вы не запрашивали сброс пароля, проигнорируйте это письмо.</p>
            </div>
            <div class="footer">
                <p>© 2025 FaceForm. Все права защищены.</p>
                <p>Это автоматическое письмо, пожалуйста, не отвечайте на него.</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    # Отправляем письмо
    return send_email(user.email, subject, html_content=html_content)