import os
import sys
from dotenv import load_dotenv

# Загружаем переменные окружения из .env файла
# Важно сделать это до импорта app, чтобы переменные были доступны
load_dotenv()

# Выводим для отладки
print(f"SESSION_SECRET: {os.environ.get('SESSION_SECRET')}", file=sys.stderr)
print(f"FLASK_SECRET_KEY: {os.environ.get('FLASK_SECRET_KEY')}", file=sys.stderr)
print(f"STRIPE_PUBLIC_KEY: {'*' * 4 + os.environ.get('STRIPE_PUBLIC_KEY', '')[-4:] if os.environ.get('STRIPE_PUBLIC_KEY') else 'Not set'}", file=sys.stderr)
print(f"STRIPE_SECRET_KEY: {'*' * 4 + os.environ.get('STRIPE_SECRET_KEY', '')[-4:] if os.environ.get('STRIPE_SECRET_KEY') else 'Not set'}", file=sys.stderr)

from flask import render_template, redirect, url_for, flash, Blueprint, request
from flask_login import login_required, current_user

from app import app
from auth import auth
from payments import payments
from routes.advanced_features import advanced_features

# Blueprint'ы уже зарегистрированы в app.py, за исключением payments
# Регистрируем payments
try:
    app.register_blueprint(payments, url_prefix='/payments')
except ValueError as e:
    # Если blueprint уже зарегистрирован, просто логируем это
    print(f"Blueprint 'payments' уже зарегистрирован: {str(e)}", file=sys.stderr)
    
# Регистрируем blueprint для расширенных функций
try:
    app.register_blueprint(advanced_features)
except ValueError as e:
    # Если blueprint уже зарегистрирован, просто логируем это
    print(f"Blueprint 'advanced_features' уже зарегистрирован: {str(e)}", file=sys.stderr)

# Создаем Blueprint для основных страниц
main = Blueprint('main', __name__)

@main.route('/')
def index():
    """Главная страница"""
    return render_template('index.html')

@main.route('/dashboard')
@login_required
def dashboard():
    """Личный кабинет пользователя"""
    return render_template('dashboard.html')
    
@main.route('/admin')
@login_required
def admin_dashboard():
    """Административная панель"""
    if not current_user.is_administrator():
        flash('У вас нет доступа к панели администратора', 'danger')
        return redirect(url_for('main.dashboard'))
    
    # Получаем данные для статистики
    from models import User, Transaction, Credit
    from datetime import datetime, timedelta
    
    # Статистика пользователей
    users_count = User.query.count()
    active_users = User.query.filter(User.last_login > datetime.utcnow() - timedelta(days=30)).count()
    
    # Статистика транзакций
    transactions_count = Transaction.query.count()
    completed_transactions = Transaction.query.filter_by(payment_status='completed').count()
    pending_transactions = Transaction.query.filter_by(payment_status='pending').count()
    
    # Статистика дохода
    completed_transactions_data = Transaction.query.filter_by(payment_status='completed').all()
    total_revenue = sum(t.amount for t in completed_transactions_data)
    
    monthly_transactions = Transaction.query.filter(
        Transaction.payment_status == 'completed',
        Transaction.created_at > datetime.utcnow() - timedelta(days=30)
    ).all()
    monthly_revenue = sum(t.amount for t in monthly_transactions)
    
    # Список пользователей для управления
    users = User.query.order_by(User.id.desc()).limit(10).all()
    
    # Проверка конфигурации webhook
    webhook_configured = bool(os.environ.get('STRIPE_WEBHOOK_SECRET'))
    
    return render_template(
        'admin/dashboard.html',
        users=users,
        webhook_configured=webhook_configured,
        stats={
            'users_count': users_count,
            'active_users': active_users,
            'transactions_count': transactions_count,
            'completed_transactions': completed_transactions,
            'pending_transactions': pending_transactions,
            'total_revenue': f"{total_revenue:.2f}",
            'monthly_revenue': f"{monthly_revenue:.2f}",
        }
    )

@main.route('/services')
def services():
    """Страница с услугами"""
    return render_template('services.html')

@main.route('/about')
def about():
    """О нас"""
    return render_template('about.html')

@main.route('/download_project')
def download_project():
    """Страница для скачивания файлов проекта"""
    return render_template('download_project.html')

# Регистрируем Blueprint для основных страниц
app.register_blueprint(main)

# Регистрируем Blueprint для скачивания отдельных файлов
try:
    from routes.download_files import download_files_bp
    app.register_blueprint(download_files_bp)
    print("Download Files blueprint успешно зарегистрирован", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download Files blueprint: {str(e)}", file=sys.stderr)
    
# Регистрируем Blueprint для скачивания архива деплоя
try:
    from download_deploy import download_deploy_bp
    app.register_blueprint(download_deploy_bp)
    print("Download Deploy blueprint успешно зарегистрирован", file=sys.stderr)
except Exception as e:
    print(f"Ошибка при регистрации Download Deploy blueprint: {str(e)}", file=sys.stderr)

# Обработчик ошибки 404
@app.errorhandler(404)
def page_not_found(e):
    return render_template('errors/404.html'), 404

# Обработчик ошибки 500
@app.errorhandler(500)
def internal_server_error(e):
    return render_template('errors/500.html'), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=True)