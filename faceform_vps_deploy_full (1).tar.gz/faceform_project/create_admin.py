"""
Скрипт для создания администратора в базе данных
"""
import os
import sys
import random
import string
from werkzeug.security import generate_password_hash
import psycopg2
from psycopg2 import sql

def generate_password(length=12):
    """
    Генерирует случайный пароль указанной длины
    
    Args:
        length (int): Длина пароля
        
    Returns:
        str: Сгенерированный пароль
    """
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(random.choice(chars) for _ in range(length))

def create_admin_user(db_url=None, email=None, username=None, password=None):
    """
    Создает администратора в базе данных
    
    Args:
        db_url (str, optional): URL базы данных
        email (str, optional): Email администратора
        username (str, optional): Имя пользователя администратора
        password (str, optional): Пароль администратора
        
    Returns:
        dict: Информация о созданном пользователе
    """
    # Используем переданные значения или значения по умолчанию
    db_url = db_url or os.environ.get('DATABASE_URL')
    email = email or 'admin@faceform.vps.webdock.cloud'
    username = username or 'admin'
    password = password or generate_password()
    
    if not db_url:
        print("ОШИБКА: Не указан URL базы данных", file=sys.stderr)
        return None
    
    try:
        # Подключаемся к базе данных
        conn = psycopg2.connect(db_url)
        cursor = conn.cursor()
        
        # Проверяем, существует ли пользователь с таким email или username
        cursor.execute("SELECT id FROM "user" WHERE email = %s OR username = %s", (email, username))
        existing_user = cursor.fetchone()
        
        if existing_user:
            # Обновляем существующего пользователя, делая его администратором
            cursor.execute(
                "UPDATE "user" SET is_admin = TRUE, password_hash = %s WHERE id = %s",
                (generate_password_hash(password), existing_user[0])
            )
            user_id = existing_user[0]
            print(f"Пользователь с id {user_id} обновлен и получил права администратора")
        else:
            # Создаем нового пользователя-администратора
            cursor.execute(
                """
                INSERT INTO "user" (username, email, password_hash, is_admin)
                VALUES (%s, %s, %s, TRUE)
                RETURNING id
                """,
                (username, email, generate_password_hash(password))
            )
            user_id = cursor.fetchone()[0]
            print(f"Создан новый пользователь-администратор с id {user_id}")
        
        # Проверяем, есть ли у пользователя кредиты, если нет - добавляем
        cursor.execute("SELECT id FROM credit WHERE user_id = %s", (user_id,))
        existing_credit = cursor.fetchone()
        
        if not existing_credit:
            cursor.execute(
                "INSERT INTO credit (user_id, amount) VALUES (%s, %s)",
                (user_id, 1000)  # Даем администратору 1000 кредитов
            )
            print(f"Добавлено 1000 кредитов пользователю с id {user_id}")
        else:
            # Обновляем количество кредитов
            cursor.execute(
                "UPDATE credit SET amount = 1000 WHERE user_id = %s",
                (user_id,)
            )
            print(f"Обновлено количество кредитов пользователя с id {user_id} до 1000")
        
        conn.commit()
        
        # Возвращаем информацию о пользователе
        return {
            'id': user_id,
            'username': username,
            'email': email,
            'password': password,
            'is_admin': True,
            'credits': 1000
        }
    
    except Exception as e:
        print(f"ОШИБКА при создании администратора: {str(e)}", file=sys.stderr)
        return None
    finally:
        if 'conn' in locals() and conn:
            conn.close()

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Создание администратора в базе данных')
    parser.add_argument('--db-url', help='URL базы данных')
    parser.add_argument('--email', help='Email администратора')
    parser.add_argument('--username', help='Имя пользователя администратора')
    parser.add_argument('--password', help='Пароль администратора')
    
    args = parser.parse_args()
    
    user_info = create_admin_user(
        db_url=args.db_url,
        email=args.email,
        username=args.username,
        password=args.password
    )
    
    if user_info:
        print("Администратор успешно создан/обновлен")
        print("======================================")
        print(f"ID: {user_info['id']}")
        print(f"Username: {user_info['username']}")
        print(f"Email: {user_info['email']}")
        print(f"Password: {user_info['password']}")
        print(f"Credits: {user_info['credits']}")
        print("======================================")
        print("Используйте эти данные для входа в систему!")
    else:
        print("Не удалось создать администратора", file=sys.stderr)
        sys.exit(1)
