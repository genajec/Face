# FaceForm - Полный установочный пакет для VPS faceform.vps.webdock.cloud

## Инструкция по установке

1. Загрузите этот архив на ваш VPS сервер (92.113.145.171)
2. Распакуйте архив: `tar -xzf faceform_vps_deploy_full.tar.gz`
3. Запустите скрипт установки: `sudo ./setup.sh`
4. Следуйте инструкциям на экране

После успешной установки сайт будет доступен по адресу:
- http://faceform.vps.webdock.cloud
- http://92.113.145.171

## Доступ администратора

- Логин: admin@faceform.vps.webdock.cloud
- Пароль: faceform_admin2025
- Кредиты: 1000

## Системные требования (уже соответствует VPS)

- Ubuntu 24.04.2 LTS
- Минимум 2 ГБ оперативной памяти
- Минимум 10 ГБ свободного места на диске

## Специфические настройки для данного VPS

- Домен: faceform.vps.webdock.cloud
- IPv4: 92.113.145.171
- IPv6: 2a0f:0f01:0206:1ac::0
- Пользователь: faceform

## Если возникли проблемы

1. Проверьте лог-файлы:
   - /var/log/faceform/error.log
   - /var/log/nginx/faceform_error.log

2. Проверьте статус сервиса:
   `sudo systemctl status faceform`

3. Перезапустите сервисы:
   `sudo systemctl restart faceform nginx`
