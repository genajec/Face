#!/bin/bash
#
# Скрипт установки FaceForm на VPS Ubuntu
# Домен: faceform.vps.webdock.cloud
# IP: 92.113.145.171
#

set -e

# Цвета для вывода
GREEN='[0;32m'
RED='[0;31m'
YELLOW='[1;33m'
NC='[0m' # No Color

# Конфигурация
APP_NAME="faceform"
APP_USER="faceform"
APP_DIR="/home/$APP_USER/faceform_app"
DOMAIN="faceform.vps.webdock.cloud"
IP_ADDRESS="92.113.145.171"

# Текущая директория
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Функции
echo_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

echo_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

echo_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Проверка системы
echo_status "Проверка системы..."
if ! command -v python3 &> /dev/null; then
    echo_warning "Python 3 не установлен"
    if [ "$(whoami)" == "root" ]; then
        echo_status "Установка Python 3..."
        apt-get update && apt-get install -y python3 python3-pip python3-venv
    else
        echo_warning "Для установки Python 3 требуются права суперпользователя"
        echo_warning "Выполните: sudo apt-get update && sudo apt-get install -y python3 python3-pip python3-venv"
        exit 1
    fi
fi

# Создание директорий
echo_status "Создание директорий..."
mkdir -p "$APP_DIR"
mkdir -p "$APP_DIR/logs"
mkdir -p "$APP_DIR/flask_session"
mkdir -p "$APP_DIR/uploads"
mkdir -p "$APP_DIR/static"
mkdir -p "$APP_DIR/templates"

# Копирование файлов проекта
echo_status "Копирование файлов проекта..."
if [ "$SCRIPT_DIR" != "$APP_DIR" ]; then
    cp -r "$SCRIPT_DIR/faceform_project/"* "$APP_DIR/"
    echo_status "Файлы скопированы в $APP_DIR"
fi

# Создание виртуального окружения
echo_status "Создание виртуального окружения..."
cd "$APP_DIR"
python3 -m venv venv
source venv/bin/activate

# Установка зависимостей
echo_status "Установка зависимостей..."
pip install --upgrade pip
pip install -r requirements.txt
pip install gunicorn psycopg2-binary

# Проверка наличия PostgreSQL
if ! command -v psql &> /dev/null; then
    echo_warning "PostgreSQL не установлен"
    if [ "$(whoami)" == "root" ]; then
        echo_status "Установка PostgreSQL..."
        apt-get update && apt-get install -y postgresql postgresql-contrib libpq-dev
        systemctl enable postgresql
        systemctl start postgresql
    else
        echo_warning "Для установки PostgreSQL требуются права суперпользователя"
        echo_warning "Выполните: sudo apt-get update && sudo apt-get install -y postgresql postgresql-contrib libpq-dev"
        echo_warning "sudo systemctl enable postgresql && sudo systemctl start postgresql"
    fi
fi

# Создание файла .env
echo_status "Создание файла .env..."
if [ -f "$APP_DIR/.env.example" ]; then
    cp "$APP_DIR/.env.example" "$APP_DIR/.env"
else
    cat > "$APP_DIR/.env" << EOF
# Основные настройки
FLASK_ENV=production
FLASK_DEBUG=0
FLASK_SECRET_KEY=faceform_secure_secret_key_for_production_environment
SESSION_SECRET=faceform_secure_session_secret

# Настройки базы данных
DATABASE_URL=postgresql://faceform:faceform_password@localhost/faceform

# API ключи LightX
LIGHTX_API_KEYS=af1fde54...,d4bd48c9...,4d2c3274...,a271d490...,eeee6d2b...

# Домен и порты
HOST=$DOMAIN
PORT=5000
EOF
fi

# Настройка базы данных PostgreSQL
if [ "$(whoami)" == "root" ]; then
    echo_status "Настройка базы данных PostgreSQL..."
    su - postgres -c "psql -c "CREATE USER faceform WITH PASSWORD 'faceform_password';""
    su - postgres -c "psql -c "CREATE DATABASE faceform OWNER faceform;""
    echo_status "База данных PostgreSQL настроена"
else
    echo_warning "Для настройки PostgreSQL требуются права суперпользователя"
    echo_warning "Выполните следующие команды под пользователем postgres:"
    echo_warning "sudo -u postgres psql -c "CREATE USER faceform WITH PASSWORD 'faceform_password';""
    echo_warning "sudo -u postgres psql -c "CREATE DATABASE faceform OWNER faceform';""
fi

# Настройка Gunicorn
echo_status "Настройка Gunicorn..."
cat > "$APP_DIR/gunicorn_config.py" << EOF
bind = "0.0.0.0:5000"
workers = 4
timeout = 120
accesslog = "logs/access.log"
errorlog = "logs/error.log"
capture_output = True
EOF

# Создание скрипта запуска
echo_status "Создание скрипта запуска..."
cat > "$APP_DIR/start.sh" << EOF
#!/bin/bash
cd "$APP_DIR"
source venv/bin/activate
export FLASK_APP=main.py
export FLASK_ENV=production
gunicorn --config gunicorn_config.py main:app
EOF
chmod +x "$APP_DIR/start.sh"

# Создание службы systemd
if [ "$(whoami)" == "root" ]; then
    echo_status "Создание службы systemd..."
    cat > /etc/systemd/system/faceform.service << EOF
[Unit]
Description=FaceForm Application
After=network.target postgresql.service

[Service]
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin"
ExecStart=$APP_DIR/start.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable faceform
    systemctl start faceform
    echo_status "Служба systemd настроена и запущена"
else
    echo_warning "Для создания службы systemd требуются права суперпользователя"
    echo_warning "Создайте файл systemd вручную после установки с привилегиями root"
fi

# Настройка Nginx
if [ "$(whoami)" == "root" ]; then
    echo_status "Настройка Nginx..."
    if ! command -v nginx &> /dev/null; then
        echo_status "Установка Nginx..."
        apt-get update && apt-get install -y nginx
    fi

    cat > /etc/nginx/sites-available/faceform << EOF
server {
    listen 80;
    server_name $DOMAIN $IP_ADDRESS;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_buffering off;
        client_max_body_size 100M;
    }

    location /static {
        alias $APP_DIR/static;
        expires 30d;
    }

    location /uploads {
        alias $APP_DIR/uploads;
        expires 30d;
    }

    error_log /var/log/nginx/faceform.error.log;
    access_log /var/log/nginx/faceform.access.log;
}
EOF

    ln -sf /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/
    systemctl restart nginx
    echo_status "Nginx настроен"
else
    echo_warning "Для настройки Nginx требуются права суперпользователя"
    echo_warning "Настройте Nginx вручную после установки с привилегиями root"
fi

# Создание администратора
echo_status "Создание администратора..."
cd "$APP_DIR"
source venv/bin/activate
python create_admin.py --username admin --email admin@$DOMAIN --password faceform_admin2025

echo_status "Установка FaceForm завершена!"
echo_status "Сайт доступен по адресу: http://$DOMAIN и http://$IP_ADDRESS"
echo_status "Логин администратора: admin@$DOMAIN"
echo_status "Пароль администратора: faceform_admin2025"

# Если не root, показываем инструкции по запуску вручную
if [ "$(whoami)" != "root" ]; then
    echo_warning "Так как установка выполнена без прав суперпользователя, запустите приложение вручную:"
    echo_warning "cd $APP_DIR && ./start.sh"
    echo_warning "Приложение будет доступно по адресу: http://$IP_ADDRESS:5000"
fi
